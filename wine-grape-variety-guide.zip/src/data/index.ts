import { redGrapes } from "./reds";
import { whiteGrapes } from "./whites";
import type { Grape } from "./types";

export * from "./types";

/* ------------------------------------------------------------------ */
/* Popularity tiers — what people actually look up, in rough order      */
/* ------------------------------------------------------------------ */
export type Tier = 1 | 2 | 3;

const POPULARITY: string[] = [
  // Tier 1 — the essentials (the ones on every restaurant list)
  "cabernet-sauvignon",
  "chardonnay",
  "pinot-noir",
  "sauvignon-blanc",
  "merlot",
  "pinot-grigio",
  "syrah",
  "riesling",
  "malbec",
  "moscato",
  "zinfandel",
  "sangiovese",
  // Tier 2 — well worth knowing
  "tempranillo",
  "grenache",
  "cabernet-franc",
  "nebbiolo",
  "gamay",
  "chenin-blanc",
  "viognier",
  "gewurztraminer",
  "albarino",
  "gruner-veltliner",
  // Tier 3 — deeper cuts
  "barbera",
  "carmenere",
  "mourvedre",
  "semillon",
  "vermentino",
  "torrontes",
  "aglianico",
  "assyrtiko",
];

const TIER_1_COUNT = 12;
const TIER_2_COUNT = 10;

export const popularityRank = (id: string) => {
  const i = POPULARITY.indexOf(id);
  return i === -1 ? 999 : i;
};

export const tierOf = (g: Grape): Tier => {
  const r = popularityRank(g.id);
  if (r < TIER_1_COUNT) return 1;
  if (r < TIER_1_COUNT + TIER_2_COUNT) return 2;
  return 3;
};

export const TIER_META: Record<Tier, { title: string; blurb: string }> = {
  1: { title: "The Essentials", blurb: "The twelve varieties you'll meet on nearly every wine list. Start here." },
  2: { title: "Well Worth Knowing", blurb: "Classic regional heroes — the next step once the essentials feel familiar." },
  3: { title: "Deeper Cuts", blurb: "Indigenous and under-the-radar grapes for when you're feeling adventurous." },
};

/* ------------------------------------------------------------------ */

export const allGrapes: Grape[] = [...redGrapes, ...whiteGrapes].sort(
  (a, b) => popularityRank(a.id) - popularityRank(b.id)
);

export const grapeById = (id: string) => allGrapes.find((g) => g.id === id);

export const byTier = (tier: Tier) => allGrapes.filter((g) => tierOf(g) === tier);

export const ALL_STYLES = Array.from(new Set(allGrapes.flatMap((g) => g.styles))).sort();

export const stats = {
  total: allGrapes.length,
  reds: redGrapes.length,
  whites: whiteGrapes.length,
  regions: allGrapes.reduce((n, g) => n + g.regions.length, 0),
};
