export type GrapeColor = "red" | "white";
export type GlassShape = "bordeaux" | "burgundy" | "white" | "flute";

export interface TasteProfile {
  /** 1 bone dry → 5 sweet */
  sweetness: number;
  /** 1 light → 5 full */
  body: number;
  /** 1 low → 5 high */
  tannin: number;
  /** 1 low → 5 high */
  acidity: number;
  /** 1 low → 5 high */
  alcohol: number;
  abv: string;
}

export interface Handling {
  serveTempF: [number, number];
  glass: string;
  glassShape: GlassShape;
  /** minutes; 0 = serve straight away */
  decantMinutes: number;
  decantLabel: string;
  cellar: string;
}

export interface RegionNote {
  name: string;
  notes: string;
}

export interface Grape {
  id: string;
  name: string;
  pronunciation: string;
  color: GrapeColor;
  /** hex — typical colour of the wine in glass */
  wineColor: string;
  wineColorDeep: string;
  origin: string;
  climate: string;
  tagline: string;
  description: string;
  primaryFlavors: string[];
  /** Winemaking-derived aromas: oak, lees, malolactic, carbonic etc. */
  secondaryFlavors?: string[];
  /** Age-derived aromas that develop in bottle. */
  tertiaryFlavors?: string[];
  profile: TasteProfile;
  handling: Handling;
  pairings: string[];
  regions: RegionNote[];
  synonyms: string[];
  styles: string[];
  funFact: string;
}

/* ---------- label helpers (Wine Folly style 5-point scales) ---------- */

export const sweetnessLabel = (v: number) =>
  ["", "Bone Dry", "Dry", "Off-Dry", "Medium Sweet", "Sweet"][v] ?? "";

export const bodyLabel = (v: number) =>
  ["", "Light", "Medium-Light", "Medium", "Medium-Full", "Full"][v] ?? "";

export const levelLabel = (v: number) =>
  ["", "Low", "Medium-Low", "Medium", "Medium-High", "High"][v] ?? "";

/* Short forms that fit a quarter-width phone column without truncating */
export const sweetnessShort = (v: number) =>
  ["", "Bone Dry", "Dry", "Off-Dry", "Med-Sweet", "Sweet"][v] ?? "";

export const bodyShort = (v: number) =>
  ["", "Light", "Med-Light", "Medium", "Med-Full", "Full"][v] ?? "";

export const levelShort = (v: number) =>
  ["", "Low", "Med-Low", "Medium", "Med-High", "High"][v] ?? "";

export const alcoholLabel = (v: number) =>
  ["", "Low · <10%", "Med-Low · 10–11.5%", "Medium · 11.5–13.5%", "Med-High · 13.5–15%", "High · 15%+"][v] ?? "";

/* ---------- temperature helpers ---------- */

export const fToC = (f: number) => Math.round(((f - 32) * 5) / 9);

export const formatTempRange = (range: [number, number], unit: "F" | "C") =>
  unit === "F"
    ? `${range[0]}–${range[1]}°F`
    : `${fToC(range[0])}–${fToC(range[1])}°C`;

/** Where a serving temp sits on a 35–70°F serving thermometer, in % */
export const tempPosition = (f: number) => ((f - 35) / (70 - 35)) * 100;

export const tempVerdict = (range: [number, number]) => {
  const mid = (range[0] + range[1]) / 2;
  if (mid <= 42) return "Ice cold — straight from the fridge";
  if (mid <= 48) return "Well chilled";
  if (mid <= 54) return "Cool — a light chill";
  if (mid <= 60) return "Cellar temperature";
  return "Just below room temperature";
};

/* ---------- similarity ---------- */

export function similarGrapes(grape: Grape, all: Grape[], count = 3): Grape[] {
  const dist = (a: TasteProfile, b: TasteProfile) =>
    Math.abs(a.sweetness - b.sweetness) * 1.4 +
    Math.abs(a.body - b.body) +
    Math.abs(a.tannin - b.tannin) +
    Math.abs(a.acidity - b.acidity) +
    Math.abs(a.alcohol - b.alcohol) * 0.7;
  return all
    .filter((g) => g.id !== grape.id)
    .sort((a, b) => dist(grape.profile, a.profile) - dist(grape.profile, b.profile))
    .slice(0, count);
}
