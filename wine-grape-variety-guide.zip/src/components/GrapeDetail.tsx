import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Check,
  ChevronDown,
  Clock3,
  Globe2,
  Hourglass,
  Lightbulb,
  MapPin,
  Plus,
  Share2,
  Snowflake,
  Thermometer,
  UtensilsCrossed,
  Volume2,
  Wine,
  X,
} from "lucide-react";
import type { Grape } from "../data/types";
import { fToC, formatTempRange, similarGrapes, tempPosition, tempVerdict } from "../data/types";
import { TIER_META, allGrapes, tierOf } from "../data";
import { cn } from "../utils/cn";
import DecantTimer from "./DecantTimer";
import FlavorChip from "./FlavorIcon";
import ProfileBars from "./ProfileBars";
import WineGlass from "./WineGlass";

interface Props {
  grape: Grape;
  unit: "F" | "C";
  isFavorite: boolean;
  inCompare: boolean;
  onClose: () => void;
  onNavigate: (g: Grape) => void;
  onToggleFavorite: (id: string) => void;
  onToggleCompare: (id: string) => void;
  onNotify?: (msg: string) => void;
}

function speak(text: string) {
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text.replace(/\(.*?\)/g, "").trim());
    u.rate = 0.82;
    window.speechSynthesis.speak(u);
  } catch {
    /* speech unavailable */
  }
}

function ThermometerScale({ grape, unit }: { grape: Grape; unit: "F" | "C" }) {
  const [lo, hi] = grape.handling.serveTempF;
  const ticks = [40, 50, 60, 70];
  return (
    <div className="mt-3">
      <div className="relative h-2.5 overflow-hidden rounded-full bg-gradient-to-r from-sky-300/70 via-emerald-200/50 via-40% to-rose-400/70 opacity-90">
        <div
          className="absolute top-0 h-full rounded-full border border-white/70 bg-white/25 shadow-[0_0_12px_rgba(255,255,255,0.45)]"
          style={{ left: `${tempPosition(lo)}%`, width: `${Math.max(tempPosition(hi) - tempPosition(lo), 3)}%` }}
        />
      </div>
      <div className="relative mt-1 h-4">
        {ticks.map((t) => (
          <span
            key={t}
            className="absolute -translate-x-1/2 font-mono text-[12px] text-faded"
            style={{ left: `${tempPosition(t)}%` }}
          >
            {unit === "F" ? `${t}°` : `${fToC(t)}°`}
          </span>
        ))}
        <span className="absolute right-0 inline-flex translate-x-1 items-center gap-0.5 text-[12px] text-faded">
          {unit === "F" ? "°F" : "°C"}
        </span>
      </div>
      <p className="mt-0.5 text-[13.5px] italic text-parchment/75">{tempVerdict([lo, hi])}</p>
    </div>
  );
}

const DETAIL_TABS = [
  { id: "overview", label: "Overview" },
  { id: "flavors", label: "Flavours" },
  { id: "profile", label: "Profile" },
  { id: "handling", label: "Serve" },
  { id: "regions", label: "Regions" },
  { id: "pairings", label: "Pair" },
] as const;

export default function GrapeDetail({ grape: g, unit, isFavorite, inCompare, onClose, onNavigate, onToggleFavorite, onToggleCompare, onNotify }: Props) {
  const idx = allGrapes.findIndex((x) => x.id === g.id);
  const prev = allGrapes[(idx - 1 + allGrapes.length) % allGrapes.length];
  const next = allGrapes[(idx + 1) % allGrapes.length];
  const similar = similarGrapes(g, allGrapes, 3);
  const accent = g.color === "red" ? "#c1455f" : "#c9a44e";
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showAllRegions, setShowAllRegions] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("overview");

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
    setShowAllRegions(false);
    setActiveTab("overview");
  }, [g.id]);

  // scroll spy
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const sections = DETAIL_TABS.map((t) => document.getElementById(`detail-${t.id}`)).filter(Boolean) as HTMLElement[];
      let current = "overview";
      for (const sec of sections) {
        const rect = sec.getBoundingClientRect();
        const containerRect = el.getBoundingClientRect();
        if (rect.top <= containerRect.top + 100) current = sec.id.replace("detail-", "");
      }
      setActiveTab(current);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onNavigate(prev);
      if (e.key === "ArrowRight") onNavigate(next);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, onNavigate, prev, next]);

  const handleShare = async () => {
    const text = `${g.name} — ${g.tagline} · ${formatTempRange(g.handling.serveTempF, unit)} · ${g.primaryFlavors.slice(0, 3).join(", ")}`;
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: g.name, text, url });
        return;
      } catch {
        /* user cancelled */
      }
    }
    try {
      await navigator.clipboard.writeText(`${g.name}: ${text}`);
      onNotify?.("Link copied");
    } catch {
      /* clipboard unavailable */
    }
  };

  const scrollTo = (id: string) => {
    document.getElementById(`detail-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    setActiveTab(id);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 48, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 32, scale: 0.98 }}
        transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="relative flex max-h-[94dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-3xl border border-line bg-cellar shadow-2xl sm:rounded-3xl"
        role="dialog"
        aria-modal="true"
        aria-label={`${g.name} grape guide`}
      >
        {/* ------- header ------- */}
        <div className="relative overflow-hidden">
          <div
            className="absolute inset-0"
            style={{
              background: `radial-gradient(120% 160% at 18% 0%, ${g.wineColor}66 0%, transparent 55%), radial-gradient(90% 120% at 90% 10%, ${g.color === "red" ? "#8c2439" : "#c9a44e"}30 0%, transparent 50%), linear-gradient(180deg, #241118, #181016)`,
            }}
          />
          <div className="relative flex items-start gap-4 px-5 pb-5 pt-6 sm:px-8 sm:pt-8">
            <WineGlass
              color={g.wineColor}
              colorDeep={g.wineColorDeep}
              shape={g.handling.glassShape}
              swirl
              className="h-28 w-[70px] shrink-0 drop-shadow-[0_14px_24px_rgba(0,0,0,0.55)] sm:h-40 sm:w-[100px]"
            />
            <div className="min-w-0 flex-1 pr-10">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className={cn("rounded-full px-2 py-[2px] text-[12.5px] font-bold uppercase tracking-wider", g.color === "red" ? "bg-claret text-cream" : "bg-gold text-ink")}>
                  {g.color} grape
                </span>
                <span className="rounded-full border border-gold/40 bg-gold/10 px-2 py-[2px] text-[12.5px] font-bold uppercase tracking-wider text-goldsoft">
                  {TIER_META[tierOf(g)].title}
                </span>
                {g.styles.map((s) => (
                  <span key={s} className="rounded-full border border-white/15 bg-white/[0.05] px-2 py-[2px] text-[12.5px] font-semibold uppercase tracking-wider text-parchment">
                    {s}
                  </span>
                ))}
              </div>
              <h2 className="mt-2 font-display text-[34px] font-semibold leading-[1.05] text-cream sm:text-5xl">{g.name}</h2>
              <div className="mt-1.5 flex items-center gap-2">
                <p className="font-display text-[19px] italic text-goldsoft">{g.pronunciation}</p>
                <button
                  onClick={() => speak(g.name)}
                  className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-gold/40 text-goldsoft transition hover:bg-gold hover:text-ink sm:h-9 sm:w-9"
                  aria-label={`Hear how to pronounce ${g.name}`}
                  title="Hear pronunciation"
                >
                  <Volume2 className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
                </button>
              </div>
              <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[14.5px] text-parchment/85">
                <span className="inline-flex items-center gap-1"><MapPin className="h-4.5 w-4.5 text-gold" /> {g.origin}</span>
                <span className="inline-flex items-center gap-1"><Snowflake className="h-4.5 w-4.5 text-gold" /> {g.climate} climate</span>
                <span className="inline-flex items-center gap-1 font-mono"><Wine className="h-4.5 w-4.5 text-gold" /> {g.profile.abv} ABV</span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="absolute right-4 top-4 inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-black/30 text-cream transition hover:bg-claret"
              aria-label="Close details"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* quick actions */}
          <div className="relative flex flex-wrap gap-2 px-5 pb-5 sm:px-8">
            <button
              onClick={() => onToggleFavorite(g.id)}
              aria-pressed={isFavorite}
              className={cn(
                "inline-flex h-11 items-center gap-2 rounded-full px-5 text-[15.5px] font-semibold transition",
                isFavorite ? "bg-claret text-cream" : "border border-white/20 bg-white/[0.05] text-cream hover:border-claret"
              )}
            >
              <Bookmark className={cn("h-5 w-5", isFavorite && "fill-current")} />
              {isFavorite ? "Saved" : "Save"}
            </button>
            <button
              onClick={() => onToggleCompare(g.id)}
              aria-pressed={inCompare}
              className={cn(
                "inline-flex h-11 items-center gap-2 rounded-full px-5 text-[15.5px] font-semibold transition",
                inCompare ? "bg-gold text-ink" : "border border-white/20 bg-white/[0.05] text-cream hover:border-gold/70"
              )}
            >
              {inCompare ? <Check className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
              {inCompare ? "In compare" : "Compare"}
            </button>
            <button
              onClick={handleShare}
              className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-white/[0.05] text-cream transition hover:border-gold/40 hover:text-goldsoft"
              aria-label={`Share ${g.name}`}
              title="Share"
            >
              <Share2 className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* ------- body ------- */}
        <div ref={scrollRef} className="scroll-pt-12 overflow-y-auto px-5 pb-6 sm:px-8">
          {/* sticky section nav */}
          <div className="sticky top-0 z-10 -mx-5 -mt-0 flex items-center gap-1 overflow-x-auto border-y border-line bg-cellar/95 px-5 py-2 backdrop-blur-md sm:-mx-8 sm:px-8">
            {DETAIL_TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => scrollTo(t.id)}
                className={cn(
                  "shrink-0 rounded-full px-3 py-1.5 text-[13.5px] font-semibold transition",
                  activeTab === t.id ? "bg-gold text-ink" : "bg-white/[0.06] text-parchment hover:bg-white/[0.1] hover:text-cream"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div id="detail-overview" className="scroll-mt-16 pt-4">
            <p className="font-display text-[21px] font-medium italic leading-snug text-cream/95">{g.tagline}</p>
            <p className="mt-2 text-[16.5px] leading-relaxed text-parchment/90">{g.description}</p>
          </div>

          {/* aromas & flavours — primary / secondary / tertiary */}
          <section id="detail-flavors" className="scroll-mt-16 pt-7">
            <h3 className="flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">
              <span className="hairline w-6" /> Aromas & Flavours
            </h3>
            <div className="mt-3 divide-y divide-line/60 overflow-hidden rounded-2xl border border-line bg-panel">
              {(
                [
                  { label: "Primary", sub: "From the grape itself", list: g.primaryFlavors },
                  { label: "Secondary", sub: "From winemaking — oak, lees, malolactic", list: g.secondaryFlavors },
                  { label: "Tertiary", sub: "From bottle age", list: g.tertiaryFlavors },
                ] as { label: string; sub: string; list?: string[] }[]
              )
                .filter((t) => t.list && t.list.length > 0)
                .map((t) => (
                  <div key={t.label} className="grid gap-2 px-4 py-3 sm:grid-cols-[150px_1fr] sm:gap-4 sm:px-5">
                    <div>
                      <p className="text-[14.5px] font-bold uppercase tracking-[0.14em] text-cream">{t.label}</p>
                      <p className="text-[13.5px] leading-snug text-faded">{t.sub}</p>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {t.list!.map((f) => (
                        <FlavorChip key={f} flavor={f} size="sm" />
                      ))}
                    </div>
                  </div>
                ))}
            </div>
          </section>

          {/* taste profile */}
          <section id="detail-profile" className="scroll-mt-16 pt-7">
            <div className="rounded-2xl border border-line bg-panel p-4 sm:p-5">
              <div className="mb-4 flex items-baseline justify-between">
                <h3 className="text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">Taste Profile</h3>
                <span className="font-mono text-[13.5px] text-faded">{g.profile.abv} ABV</span>
              </div>
              <ProfileBars key={g.id} profile={g.profile} accent={accent} />
            </div>
          </section>

          {/* handling */}
          <section id="detail-handling" className="scroll-mt-16 pt-7">
            <h3 className="flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">
              <span className="hairline w-6" /> Handling — Serve It Right
            </h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-line bg-panel p-4">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-[13.5px] font-bold uppercase tracking-[0.16em] text-faded">
                    <Thermometer className="h-5 w-5 text-gold" /> Serve at
                  </span>
                  <span className="font-display text-[18px] font-semibold text-cream">{formatTempRange(g.handling.serveTempF, unit)}</span>
                </div>
                <ThermometerScale grape={g} unit={unit} />
              </div>

              <div className="rounded-2xl border border-line bg-panel p-4">
                <span className="inline-flex items-center gap-1.5 text-[13.5px] font-bold uppercase tracking-[0.16em] text-faded">
                  <Wine className="h-5 w-5 text-gold" /> Glassware
                </span>
                <div className="mt-2 flex items-center gap-3">
                  <WineGlass color={g.wineColor} colorDeep={g.wineColorDeep} shape={g.handling.glassShape} className="h-14 w-9" />
                  <div>
                    <p className="font-display text-[17px] font-semibold leading-tight text-cream">{g.handling.glass}</p>
                    <p className="text-[13.5px] leading-snug text-parchment/80">
                      {g.handling.glassShape === "burgundy" && "A wide bowl collects delicate aromas."}
                      {g.handling.glassShape === "bordeaux" && "A tall bowl softens tannin and spreads bold fruit."}
                      {g.handling.glassShape === "white" && "A smaller bowl keeps it cold and focused."}
                      {g.handling.glassShape === "flute" && "A narrow flute preserves bubbles and perfume."}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-line bg-panel p-4">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-[13.5px] font-bold uppercase tracking-[0.16em] text-faded">
                    <Hourglass className="h-5 w-5 text-gold" /> Decant
                  </span>
                  <span className="font-display text-[18px] font-semibold text-cream">{g.handling.decantLabel}</span>
                </div>
                <div className="mt-2.5">
                  {g.handling.decantMinutes > 0 ? (
                    <DecantTimer minutes={g.handling.decantMinutes} accent={accent} />
                  ) : (
                    <p className="text-[14px] leading-snug text-parchment">
                      Pour straight from the bottle — this wine is all about freshness. Just make sure it's properly chilled.
                    </p>
                  )}
                </div>
              </div>

              <div className="rounded-2xl border border-line bg-panel p-4">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-[13.5px] font-bold uppercase tracking-[0.16em] text-faded">
                    <Clock3 className="h-5 w-5 text-gold" /> Cellar window
                  </span>
                  <span className="font-display text-[18px] font-semibold text-cream">{g.handling.cellar}</span>
                </div>
                <p className="mt-2 text-[14px] leading-snug text-parchment">
                  {g.handling.cellar.toLowerCase().includes("fresh") || g.handling.cellar.startsWith("1")
                    ? "Best young and vibrant — don't sit on it. Buy it, chill it, drink it."
                    : "Quality examples reward patience. Store sideways, somewhere cool, dark and vibration-free (≈55°F / 13°C)."}
                </p>
              </div>
            </div>
          </section>

          {/* pairings */}
          <section id="detail-pairings" className="scroll-mt-16 pt-7">
            <h3 className="flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">
              <span className="hairline w-6" /> <UtensilsCrossed className="h-4 w-4" /> On the Table
            </h3>
            <div className="mt-3 flex flex-wrap gap-2">
              {g.pairings.map((p) => (
                <span key={p} className="rounded-full border border-gold/25 bg-gold/[0.06] px-3 py-1.5 text-[14px] font-medium text-parchment">
                  {p}
                </span>
              ))}
            </div>
          </section>

          {/* regions */}
          <section id="detail-regions" className="scroll-mt-16 pt-7">
            <h3 className="flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">
              <span className="hairline w-6" /> <Globe2 className="h-4 w-4" /> Where It Grows Best
            </h3>
            <div className="mt-3 overflow-hidden rounded-2xl border border-line bg-panel">
              <div className="divide-y divide-line/70">
                {(showAllRegions ? g.regions : g.regions.slice(0, 3)).map((r, i) => (
                  <motion.div
                    key={r.name}
                    initial={i >= 3 ? { opacity: 0, y: 6 } : false}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25, delay: i >= 3 ? (i - 3) * 0.04 : 0 }}
                    className="px-4 py-3 sm:px-5"
                  >
                    <p className="font-display text-[16px] font-semibold text-cream">{r.name}</p>
                    <p className="mt-0.5 text-[14px] leading-relaxed text-parchment/85">{r.notes}</p>
                  </motion.div>
                ))}
              </div>
              {g.regions.length > 3 && (
                <button
                  onClick={() => setShowAllRegions((s) => !s)}
                  aria-expanded={showAllRegions}
                  className="flex w-full items-center justify-center gap-1.5 border-t border-line/70 bg-black/20 py-2.5 text-[13.5px] font-semibold text-goldsoft transition hover:bg-black/35 hover:text-cream"
                >
                  {showAllRegions ? "Show fewer" : `Show ${g.regions.length - 3} more ${g.regions.length - 3 === 1 ? "region" : "regions"}`}
                  <ChevronDown className={cn("h-4 w-4 transition-transform", showAllRegions && "rotate-180")} />
                </button>
              )}
            </div>
          </section>

          {/* synonyms + fact */}
          <div className="mt-6 grid gap-3 sm:grid-cols-[1fr_1.4fr]">
            <div className="rounded-2xl border border-line bg-panel p-4">
              <h4 className="text-[12.5px] font-bold uppercase tracking-[0.16em] text-faded">Also known as</h4>
              <p className="mt-1.5 font-display text-[15.5px] italic leading-relaxed text-parchment">{g.synonyms.join(" · ")}</p>
            </div>
            <div className="rounded-2xl border border-gold/30 bg-gradient-to-br from-gold/[0.09] to-transparent p-4">
              <h4 className="flex items-center gap-1.5 text-[12.5px] font-bold uppercase tracking-[0.16em] text-gold">
                <Lightbulb className="h-4 w-4" /> Sommelier's Notebook
              </h4>
              <p className="mt-1.5 text-[14px] leading-relaxed text-parchment">{g.funFact}</p>
            </div>
          </div>

          {/* similar */}
          <section className="mt-7">
            <h3 className="flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">
              <span className="hairline w-6" /> If You Like This, Try…
            </h3>
            <div className="mt-3 grid grid-cols-3 gap-2.5">
              {similar.map((s) => (
                <button
                  key={s.id}
                  onClick={() => onNavigate(s)}
                  className="group rounded-2xl border border-line bg-panel px-3 py-3 text-center transition hover:border-gold/60"
                >
                  <WineGlass color={s.wineColor} colorDeep={s.wineColorDeep} shape={s.handling.glassShape} className="mx-auto h-12 w-[30px]" />
                  <p className="mt-1.5 truncate font-display text-[14px] font-semibold text-cream group-hover:text-goldsoft">{s.name}</p>
                  <p className="truncate text-[11.5px] uppercase tracking-wider text-faded">{s.styles[0]}</p>
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* ------- footer nav ------- */}
        <div className="relative flex items-center justify-between gap-3 border-t border-line bg-black/30 px-4 py-3 sm:px-6">
          <button onClick={() => onNavigate(prev)} className="inline-flex min-w-0 items-center gap-2 rounded-full border border-line px-3.5 py-2 text-[13.5px] font-semibold text-parchment transition hover:border-gold/60 hover:text-cream">
            <ArrowLeft className="h-4 w-4 shrink-0" />
            <span className="truncate">{prev.name}</span>
          </button>
          <span className="hidden font-mono text-[12.5px] text-faded sm:block">
            {idx + 1} / {allGrapes.length} · ← → to browse
          </span>
          <button onClick={() => onNavigate(next)} className="inline-flex min-w-0 items-center gap-2 rounded-full border border-line px-3.5 py-2 text-[13.5px] font-semibold text-parchment transition hover:border-gold/60 hover:text-cream">
            <span className="truncate">{next.name}</span>
            <ArrowRight className="h-4 w-4 shrink-0" />
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
