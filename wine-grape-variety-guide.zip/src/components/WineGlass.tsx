import { useId } from "react";
import type { GlassShape } from "../data/types";

interface Props {
  color: string;
  colorDeep: string;
  shape?: GlassShape;
  className?: string;
  /** 0–1 fill level */
  fill?: number;
  swirl?: boolean;
}

/** Stylised wine glass whose bowl is filled with the grape's in-glass colour. */
export default function WineGlass({ color, colorDeep, shape = "bordeaux", className = "", fill = 0.42, swirl = false }: Props) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const gradId = `wine-${uid}`;
  const clipId = `bowl-${uid}`;

  // Bowl paths per glass shape (viewBox 0 0 100 160)
  const bowls: Record<GlassShape, string> = {
    bordeaux: "M28,8 L72,8 C72,44 68,70 50,70 C32,70 28,44 28,8 Z",
    burgundy: "M24,14 L76,14 C80,42 76,72 50,72 C24,72 20,42 24,14 Z",
    white: "M33,8 L67,8 C69,36 64,62 50,62 C36,62 31,36 33,8 Z",
    flute: "M38,6 L62,6 C63,40 60,66 50,66 C40,66 37,40 38,6 Z",
  };
  const bowl = bowls[shape];

  // Wine surface height computed from bowl depth (~8..70)
  const top = shape === "burgundy" ? 14 : 8;
  const bottom = shape === "white" ? 62 : shape === "flute" ? 66 : 70;
  const surfaceY = bottom - (bottom - top) * fill;

  return (
    <svg viewBox="0 0 100 160" className={className} role="img" aria-hidden="true">
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0.35" y2="1">
          <stop offset="0%" stopColor={color} />
          <stop offset="55%" stopColor={colorDeep} />
          <stop offset="100%" stopColor={colorDeep} />
        </linearGradient>
        <clipPath id={clipId}>
          <path d={bowl} />
        </clipPath>
      </defs>

      <g className={swirl ? "swirl" : undefined}>
        {/* wine fill */}
        <g clipPath={`url(#${clipId})`}>
          <rect x="14" y={surfaceY} width="72" height={bottom - surfaceY + 8} fill={`url(#${gradId})`} />
          {/* surface ellipse sheen */}
          <ellipse cx="50" cy={surfaceY + 1.5} rx="24" ry="2.6" fill={color} opacity="0.85" />
          <ellipse cx="42" cy={surfaceY + 1} rx="9" ry="1.2" fill="#ffffff" opacity="0.28" />
        </g>
        {/* glass bowl */}
        <path d={bowl} fill="rgba(255,255,255,0.045)" stroke="rgba(244,236,220,0.55)" strokeWidth="1.6" />
        {/* highlight streak */}
        <path
          d={shape === "burgundy" ? "M33,20 C30,38 31,54 38,64" : "M36,14 C34,34 35,50 40,60"}
          fill="none"
          stroke="rgba(255,255,255,0.4)"
          strokeWidth="2.4"
          strokeLinecap="round"
        />
      </g>

      {/* stem + foot */}
      <line x1="50" y1={shape === "white" ? 62 : shape === "flute" ? 66 : 70} x2="50" y2="138" stroke="rgba(244,236,220,0.55)" strokeWidth="2.2" />
      <path d="M28,146 C36,139 64,139 72,146" fill="none" stroke="rgba(244,236,220,0.55)" strokeWidth="2.2" strokeLinecap="round" />
      <ellipse cx="50" cy="148" rx="23" ry="2.4" fill="rgba(0,0,0,0.35)" />
    </svg>
  );
}
