import { useEffect } from "react";
import { motion } from "framer-motion";
import { Crown, X } from "lucide-react";
import type { Grape } from "../data/types";
import { formatTempRange } from "../data/types";
import { cn } from "../utils/cn";
import FlavorChip from "./FlavorIcon";
import { profileRows } from "./ProfileBars";
import WineGlass from "./WineGlass";

const SLOTS = ["#c1455f", "#c9a44e", "#9db38a"];

interface Props {
  grapes: Grape[];
  unit: "F" | "C";
  onClose: () => void;
  onRemove: (id: string) => void;
  onOpen: (g: Grape) => void;
}

export default function CompareView({ grapes, unit, onClose, onRemove, onOpen }: Props) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const maxBy = (fn: (g: Grape) => number) => grapes.reduce((a, b) => (fn(b) > fn(a) ? b : a), grapes[0]);
  const minBy = (fn: (g: Grape) => number) => grapes.reduce((a, b) => (fn(b) < fn(a) ? b : a), grapes[0]);
  const superlatives =
    grapes.length > 1
      ? [
          { label: "Fullest body", grape: maxBy((g) => g.profile.body) },
          { label: "Brightest acidity", grape: maxBy((g) => g.profile.acidity) },
          { label: "Serve coldest", grape: minBy((g) => g.handling.serveTempF[0]) },
          { label: "Longest decant", grape: maxBy((g) => g.handling.decantMinutes) },
          { label: "Lightest & easiest-drinking", grape: minBy((g) => g.profile.body + g.profile.tannin) },
        ]
      : [];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 48 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 32 }}
        transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[94dvh] w-full max-w-5xl flex-col overflow-hidden rounded-t-3xl border border-line bg-cellar shadow-2xl sm:rounded-3xl"
        role="dialog"
        aria-modal="true"
        aria-label="Compare grape varieties"
      >
        <div className="flex items-center justify-between border-b border-line px-5 py-4 sm:px-7">
          <div>
            <h2 className="font-display text-2xl font-semibold text-cream">Side by Side</h2>
            <p className="text-sm text-faded">Comparing {grapes.length} {grapes.length === 1 ? "variety" : "varieties"} — add up to 3</p>
          </div>
          <button onClick={onClose} className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-line text-cream transition hover:bg-claret" aria-label="Close comparison">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto px-5 py-5 sm:px-7">
          {/* headers */}
          <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${grapes.length}, minmax(0,1fr))` }}>
            {grapes.map((g, i) => (
              <div key={g.id} className="relative rounded-2xl border border-line bg-panel px-3 py-4 text-center" style={{ boxShadow: `inset 0 0 0 1px transparent, 0 0 24px ${SLOTS[i]}18` }}>
                <span className="absolute left-3 top-3 h-2.5 w-2.5 rounded-full" style={{ background: SLOTS[i] }} />
                <button
                  onClick={() => onRemove(g.id)}
                  className="absolute right-2 top-2 inline-flex h-6 w-6 items-center justify-center rounded-full text-faded transition hover:bg-claret hover:text-cream"
                  aria-label={`Remove ${g.name} from comparison`}
                >
                  <X className="h-4.5 w-4.5" />
                </button>
                <button onClick={() => onOpen(g)} className="block w-full">
                  <WineGlass color={g.wineColor} colorDeep={g.wineColorDeep} shape={g.handling.glassShape} className="mx-auto h-20 w-[50px]" />
                  <p className="mt-2 font-display text-[19px] font-semibold leading-tight text-cream sm:text-xl">{g.name}</p>
                  <p className="text-[12.5px] uppercase tracking-wider text-faded">{g.color} · {g.origin}</p>
                </button>
              </div>
            ))}
          </div>

          {/* superlatives */}
          {superlatives.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {superlatives.map((s) => (
                <span key={s.label} className="inline-flex items-center gap-1.5 rounded-full border border-gold/30 bg-gold/[0.07] px-3 py-1 text-[13.5px] font-medium text-parchment">
                  <Crown className="h-4 w-4 text-gold" />
                  {s.label}: <strong className="text-cream">{s.grape.name}</strong>
                </span>
              ))}
            </div>
          )}

          {/* profile chart */}
          <h3 className="mt-7 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">Taste Profile</h3>
          <div className="mt-3 space-y-4 rounded-2xl border border-line bg-panel p-4 sm:p-5">
            {profileRows(grapes[0].profile).map((row) => (
              <div key={row.key}>
                <p className="mb-1.5 text-[13.5px] font-semibold uppercase tracking-[0.14em] text-faded">{row.label}</p>
                <div className="space-y-1">
                  {grapes.map((g, i) => {
                    const r = profileRows(g.profile).find((x) => x.key === row.key)!;
                    return (
                      <div key={g.id} className="flex items-center gap-2">
                        <div className="h-[9px] flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${(r.value / 5) * 100}%` }}
                            transition={{ duration: 0.6, ease: "easeOut", delay: i * 0.08 }}
                            className="h-full rounded-full"
                            style={{ background: `linear-gradient(90deg, ${SLOTS[i]}99, ${SLOTS[i]})` }}
                          />
                        </div>
                        <span className="w-28 shrink-0 truncate text-[13.5px] text-parchment">
                          {r.word} <span className="text-faded">· {g.name.split(" ")[0]}</span>
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* fact table */}
          <h3 className="mt-7 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">Handling & Facts</h3>
          <div className="mt-3 overflow-hidden rounded-2xl border border-line">
            {[
              { label: "Serve at", get: (g: Grape) => formatTempRange(g.handling.serveTempF, unit) },
              { label: "Decant", get: (g: Grape) => (g.handling.decantMinutes === 0 ? "Not needed" : g.handling.decantLabel) },
              { label: "Glassware", get: (g: Grape) => g.handling.glass },
              { label: "Cellar window", get: (g: Grape) => g.handling.cellar },
              { label: "Alcohol", get: (g: Grape) => `${g.profile.abv} ABV` },
              { label: "Climate", get: (g: Grape) => g.climate },
              { label: "Also known as", get: (g: Grape) => g.synonyms.join(", ") },
            ].map((row, ri) => (
              <div
                key={row.label}
                className={cn("grid items-center gap-3 px-4 py-2.5", ri % 2 === 0 ? "bg-panel" : "bg-panel2/60")}
                style={{ gridTemplateColumns: `110px repeat(${grapes.length}, minmax(0,1fr))` }}
              >
                <span className="text-[13.5px] font-semibold uppercase tracking-wider text-faded">{row.label}</span>
                {grapes.map((g) => (
                  <span key={g.id} className="truncate text-[15.5px] font-medium text-parchment" title={row.get(g)}>
                    {row.get(g)}
                  </span>
                ))}
              </div>
            ))}
          </div>

          {/* flavours */}
          <h3 className="mt-7 text-[13.5px] font-bold uppercase tracking-[0.2em] text-gold">Primary Flavours</h3>
          <div className="mt-3 grid gap-3 pb-2" style={{ gridTemplateColumns: `repeat(${grapes.length}, minmax(0,1fr))` }}>
            {grapes.map((g) => (
              <div key={g.id} className="flex flex-wrap content-start gap-1.5">
                {g.primaryFlavors.map((f) => (
                  <FlavorChip key={f} flavor={f} size="sm" />
                ))}
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
