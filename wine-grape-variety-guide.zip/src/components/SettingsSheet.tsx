import { motion, AnimatePresence } from "framer-motion";
import { RotateCcw, Thermometer, X } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  unit: "F" | "C";
  onToggleUnit: () => void;
  onClearRecents: () => void;
  onClearFavorites: () => void;
  favoritesCount: number;
  recentsCount: number;
}

export default function SettingsSheet({ open, onClose, unit, onToggleUnit, onClearRecents, onClearFavorites, favoritesCount, recentsCount }: Props) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center sm:p-6"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 24, opacity: 0 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md overflow-hidden rounded-t-3xl border border-line bg-cellar shadow-2xl sm:rounded-3xl"
            role="dialog"
            aria-modal="true"
            aria-label="Settings"
          >
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="font-display text-[19px] font-semibold text-cream">Settings</h2>
              <button onClick={onClose} className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-line text-faded transition hover:bg-claret hover:text-cream" aria-label="Close settings">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-5 p-5">
              <div className="flex items-center justify-between rounded-2xl border border-line bg-panel p-4">
                <div>
                  <p className="flex items-center gap-1.5 text-[14.5px] font-semibold text-cream"><Thermometer className="h-4 w-4 text-gold" /> Temperature</p>
                  <p className="mt-0.5 text-[13.5px] text-faded">Show serving temps in Fahrenheit or Celsius</p>
                </div>
                <div className="flex items-center rounded-full border border-line bg-ink p-1" role="group" aria-label="Temperature unit">
                  {(["F", "C"] as const).map((u) => (
                    <button
                      key={u}
                      onClick={() => unit !== u && onToggleUnit()}
                      aria-pressed={unit === u}
                      className={`h-8 w-10 rounded-full text-[14px] font-bold transition ${unit === u ? "bg-gold text-ink" : "text-parchment/70 hover:text-cream"}`}
                    >
                      °{u}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-line bg-panel p-4">
                <p className="text-[14.5px] font-semibold text-cream">Your guide</p>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div className="rounded-xl border border-line bg-ink/50 p-3 text-center">
                    <p className="font-display text-2xl font-semibold text-cream">{favoritesCount}</p>
                    <p className="text-[12.5px] uppercase tracking-wider text-faded">Saved</p>
                  </div>
                  <div className="rounded-xl border border-line bg-ink/50 p-3 text-center">
                    <p className="font-display text-2xl font-semibold text-cream">{recentsCount}</p>
                    <p className="text-[12.5px] uppercase tracking-wider text-faded">Recently viewed</p>
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={onClearFavorites}
                    disabled={favoritesCount === 0}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-full border border-line py-2 text-[13.5px] font-semibold text-parchment transition hover:border-claret/60 hover:text-cream disabled:opacity-40"
                  >
                    <RotateCcw className="h-3.5 w-3.5" /> Clear saved
                  </button>
                  <button
                    onClick={onClearRecents}
                    disabled={recentsCount === 0}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-full border border-line py-2 text-[13.5px] font-semibold text-parchment transition hover:border-gold/40 hover:text-cream disabled:opacity-40"
                  >
                    <RotateCcw className="h-3.5 w-3.5" /> Clear recents
                  </button>
                </div>
              </div>

              <div className="rounded-2xl border border-gold/20 bg-gold/[0.06] p-4">
                <p className="text-[13.5px] font-semibold text-gold">About</p>
                <p className="mt-1 text-[13.5px] leading-relaxed text-parchment/80">
                  Pocket Sommelier is a field guide to grape varieties — flavours, structure, serving and cellaring — modelled on Wine Folly’s grape library. Data is for quick reference at the table or in the shop.
                </p>
                <p className="mt-2 font-mono text-[11.5px] text-faded">v1.0 · 30 varieties · built for phone</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
