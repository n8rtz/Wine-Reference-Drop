import {
  Apple,
  Banana,
  Candy,
  Cherry,
  Citrus,
  Coffee,
  Flame,
  Flower2,
  Gem,
  Grape,
  Leaf,
  Milk,
  Mountain,
  Sparkles,
  TreePine,
  Waves,
  type LucideIcon,
} from "lucide-react";

const RULES: [RegExp, LucideIcon][] = [
  [/cherry|cranberry/, Cherry],
  [/grapefruit|lemon|lime|orange|tangerine|mandarin|citrus|zest|peel|pith/, Citrus],
  [/apple|pear|peach|apricot|quince|nectarine|melon|starfruit|gooseberry/, Apple],
  [/banana/, Banana],
  [/pineapple|passionfruit|lychee|tropical/, Sparkles],
  [/rose|violet|blossom|flower|jasmine|honeysuckle|geranium|petal|floral|chamomile/, Flower2],
  [/herb|leaf|olive|bay|dill|eucalyptus|mint|pea|grass|green|bramble|tomato/, Leaf],
  [/pepper|spice|chili|paprika|ginger|clove|anise|allspice|jalape/, Flame],
  [/coffee|espresso|cocoa|chocolate|mocha/, Coffee],
  [/cedar|oak|wood|tobacco|leather|graphite|pencil/, TreePine],
  [/salt|sea|oyster|shell|brine/, Waves],
  [/stone|flint|chalk|ash|gravel|mineral|slate|talc|curd/, Gem],
  [/soil|earth|mushroom|forest|truffle|tar|game|meat|smoke|wool|petrol|balsamic/, Mountain],
  [/butter|cream|brioche|toast|wax|honey|vanilla|caramel|almond|hazelnut/, Milk],
  [/jam|sauce|paste|candy|stewed|dried|fig|raisin/, Candy],
];

export function flavorIcon(flavor: string): LucideIcon {
  const f = flavor.toLowerCase();
  for (const [re, Icon] of RULES) if (re.test(f)) return Icon;
  return Grape; // berries, plum, currant & friends
}

export default function FlavorChip({
  flavor,
  tone = "dark",
  size = "md",
}: {
  flavor: string;
  tone?: "dark" | "light";
  size?: "sm" | "md";
}) {
  const Icon = flavorIcon(flavor);
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${
        size === "sm" ? "px-2 py-0.5 text-[13.5px]" : "px-2.5 py-1 text-sm"
      } ${
        tone === "dark"
          ? "border-line bg-white/[0.04] text-parchment"
          : "border-black/10 bg-black/[0.04] text-stone-700"
      }`}
    >
      <Icon className={`${size === "sm" ? "h-4 w-4" : "h-4.5 w-4.5"} text-gold`} strokeWidth={2.2} />
      {flavor}
    </span>
  );
}
