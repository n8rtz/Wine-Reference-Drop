import { motion } from "framer-motion";
import type { TasteProfile } from "../data/types";
import { alcoholLabel, bodyLabel, levelLabel, sweetnessLabel } from "../data/types";
import { cn } from "../utils/cn";

interface Row {
  key: keyof TasteProfile | "alcoholRow";
  label: string;
  value: number;
  word: string;
}

export function profileRows(p: TasteProfile): Row[] {
  return [
    { key: "sweetness", label: "Sweetness", value: p.sweetness, word: sweetnessLabel(p.sweetness) },
    { key: "body", label: "Body", value: p.body, word: bodyLabel(p.body) },
    { key: "tannin", label: "Tannin", value: p.tannin, word: levelLabel(p.tannin) },
    { key: "acidity", label: "Acidity", value: p.acidity, word: levelLabel(p.acidity) },
    { key: "alcoholRow", label: "Alcohol", value: p.alcohol, word: alcoholLabel(p.alcohol) },
  ];
}

/** Full Wine Folly–style taste profile with animated 5-segment scales. */
export default function ProfileBars({
  profile,
  accent = "#8c2439",
  compact = false,
}: {
  profile: TasteProfile;
  accent?: string;
  compact?: boolean;
}) {
  const rows = profileRows(profile);
  return (
    <div className={compact ? "space-y-2" : "space-y-3"}>
      {rows.map((row, ri) => (
        <div key={row.key} className="grid grid-cols-[96px_1fr] items-center gap-3 sm:grid-cols-[108px_1fr_150px]">
          <span className="text-[13.5px] font-semibold uppercase tracking-[0.14em] text-faded">{row.label}</span>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <motion.span
                key={i}
                initial={{ scaleY: 0.3, opacity: 0 }}
                animate={{ scaleY: 1, opacity: 1 }}
                transition={{ delay: 0.15 + ri * 0.08 + i * 0.05, duration: 0.3, ease: "easeOut" }}
                className={cn(
                  "h-[18px] flex-1 origin-bottom rounded-[3px]",
                  i <= row.value ? "" : "bg-white/[0.07]"
                )}
                style={
                  i <= row.value
                    ? {
                        background: `linear-gradient(180deg, ${accent}e6, ${accent}99)`,
                        boxShadow: `0 0 10px ${accent}55`,
                      }
                    : undefined
                }
              />
            ))}
          </div>
          <span className="hidden text-right text-sm font-medium text-parchment sm:block">{row.word}</span>
          <span className="col-span-2 -mt-1 text-[13.5px] text-faded sm:hidden">{row.word}</span>
        </div>
      ))}
    </div>
  );
}

/** Stacked meter for cards: label on top, 5-segment bar, rating word beneath. */
export function StackedMeter({ label, value, word, accent = "#c9a44e" }: { label: string; value: number; word: string; accent?: string }) {
  return (
    <div className="min-w-0">
      <span className="block text-[11.5px] font-bold uppercase tracking-[0.08em] text-faded">{label}</span>
      <span className="mt-1 flex gap-[3px]">
        {[1, 2, 3, 4, 5].map((i) => (
          <span
            key={i}
            className="h-[8px] flex-1 rounded-[3px]"
            style={{ background: i <= value ? accent : "rgba(255,255,255,0.1)", boxShadow: i <= value ? `0 0 6px ${accent}55` : undefined }}
          />
        ))}
      </span>
      <span className="mt-1 block truncate text-[13px] font-medium text-parchment/90">{word}</span>
    </div>
  );
}

/** Tiny inline meter used on cards: label + 5 dots. */
export function MiniMeter({ label, value, accent = "#c9a44e" }: { label: string; value: number; accent?: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[12.5px] font-semibold uppercase tracking-[0.13em] text-faded">{label}</span>
      <span className="flex gap-[3px]">
        {[1, 2, 3, 4, 5].map((i) => (
          <span
            key={i}
            className="h-[5px] w-[5px] rounded-full"
            style={{ background: i <= value ? accent : "rgba(255,255,255,0.14)" }}
          />
        ))}
      </span>
    </div>
  );
}
