import { useEffect, useRef, useState } from "react";
import { BellRing, Pause, Play, RotateCcw } from "lucide-react";
import { cn } from "../utils/cn";

function chime() {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    [880, 1174.66].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.18);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + i * 0.18 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.18 + 0.7);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.18);
      osc.stop(ctx.currentTime + i * 0.18 + 0.75);
    });
  } catch {
    /* audio unavailable — stay silent */
  }
}

const fmt = (s: number) => {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
};

export default function DecantTimer({ minutes, accent }: { minutes: number; accent: string }) {
  const total = minutes * 60;
  const [left, setLeft] = useState(total);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const endRef = useRef<number | null>(null);

  useEffect(() => {
    setLeft(total);
    setRunning(false);
    setDone(false);
    endRef.current = null;
  }, [total]);

  useEffect(() => {
    if (!running) return;
    endRef.current = Date.now() + left * 1000;
    const id = window.setInterval(() => {
      const remain = Math.max(0, Math.round(((endRef.current ?? Date.now()) - Date.now()) / 1000));
      setLeft(remain);
      if (remain <= 0) {
        window.clearInterval(id);
        setRunning(false);
        setDone(true);
        endRef.current = null;
        chime();
      }
    }, 250);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  const pct = total > 0 ? ((total - left) / total) * 100 : 100;
  const R = 26;
  const CIRC = 2 * Math.PI * R;

  return (
    <div className="flex items-center gap-3">
      <div className="relative h-[64px] w-[64px] shrink-0">
        <svg viewBox="0 0 64 64" className="h-full w-full -rotate-90">
          <circle cx="32" cy="32" r={R} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="5" />
          <circle
            cx="32"
            cy="32"
            r={R}
            fill="none"
            stroke={done ? "#9db38a" : accent}
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={CIRC - (CIRC * pct) / 100}
            className="transition-[stroke-dashoffset] duration-300"
          />
        </svg>
        <span className={cn("absolute inset-0 flex items-center justify-center", running && "tick-pulse")}>
          {done ? <BellRing className="h-5 w-5 text-sage" /> : <span className="font-mono text-[13.5px] font-semibold text-cream">{fmt(left)}</span>}
        </span>
      </div>
      <div className="min-w-0">
        <p className="text-[15.5px] leading-snug text-parchment">
          {done ? (
            <span className="font-semibold text-sage">Ready to pour — enjoy!</span>
          ) : running ? (
            "Decanting… the wine is opening up."
          ) : (
            "Start the decant timer when you pour it into the decanter."
          )}
        </p>
        <div className="mt-1.5 flex gap-1.5">
          <button
            onClick={() => {
              if (done) {
                setDone(false);
                setLeft(total);
                endRef.current = null;
                setRunning(true);
              } else {
                setRunning((r) => !r);
              }
            }}
            className="inline-flex h-9 items-center gap-1 rounded-full bg-gold px-3 text-[13.5px] font-bold text-ink transition hover:bg-goldsoft"
          >
            {running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {done ? "Restart" : running ? "Pause" : left < total ? "Resume" : "Start timer"}
          </button>
          {left < total && !done && (
            <button
              onClick={() => {
                setRunning(false);
                setLeft(total);
                endRef.current = null;
              }}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-line text-parchment transition hover:border-gold/60"
              aria-label="Reset timer"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
