import { motion } from "framer-motion";
import { Bookmark, Check, ChevronRight, Plus } from "lucide-react";
import type { Grape } from "../data/types";
import { bodyShort, levelShort, sweetnessShort } from "../data/types";
import { cn } from "../utils/cn";
import FlavorChip from "./FlavorIcon";
import { MiniMeter, StackedMeter } from "./ProfileBars";
import WineGlass from "./WineGlass";

interface Props {
  grape: Grape;
  unit: "F" | "C";
  isFavorite: boolean;
  inCompare: boolean;
  onOpen: (g: Grape) => void;
  onToggleFavorite: (id: string) => void;
  onToggleCompare: (id: string) => void;
}

/**
 * Compact card: everything a user needs to recognise and shortlist a grape
 * — name, colour, origin (never truncated), top aromas, structure at a glance.
 * Tagline, temps, decanting, pairings etc. live in the detail page.
 */
export default function GrapeCard({ grape: g, isFavorite, inCompare, onOpen, onToggleFavorite, onToggleCompare }: Props) {
  const accent = g.color === "red" ? "#c1455f" : "#c9a44e";
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
      className="pressable group relative overflow-hidden rounded-2xl border border-line bg-panel shadow-[0_8px_28px_rgba(0,0,0,0.32)] transition-all duration-300 hover:border-gold/50"
    >
      {/* ambient glow in the wine's colour */}
      <div
        className="pointer-events-none absolute -top-12 left-1/4 h-32 w-56 -translate-x-1/2 rounded-full opacity-20 blur-3xl transition-opacity duration-500 group-hover:opacity-40"
        style={{ background: g.color === "red" ? g.wineColor : "#c9a44e" }}
      />

      {/* corner actions — small, out of the content flow */}
      <div className="absolute right-2.5 top-2.5 z-10 flex items-center gap-1">
        <button
          onClick={() => onToggleCompare(g.id)}
          aria-pressed={inCompare}
          aria-label={inCompare ? `Remove ${g.name} from comparison` : `Add ${g.name} to comparison`}
          title={inCompare ? "Remove from compare" : "Add to compare"}
          className={cn(
            "inline-flex h-8 w-8 items-center justify-center rounded-full border transition-all",
            inCompare ? "border-gold bg-gold text-ink" : "border-line bg-ink/40 text-parchment/80 hover:border-gold/60 hover:text-goldsoft"
          )}
        >
          {inCompare ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
        </button>
        <button
          onClick={() => onToggleFavorite(g.id)}
          aria-pressed={isFavorite}
          aria-label={isFavorite ? `Remove ${g.name} from saved` : `Save ${g.name}`}
          className={cn(
            "inline-flex h-8 w-8 items-center justify-center rounded-full border transition-all",
            isFavorite ? "border-claret bg-claret text-cream" : "border-line bg-ink/40 text-parchment/80 hover:border-claret hover:text-[#e8a1b0]"
          )}
        >
          <Bookmark key={isFavorite ? "on" : "off"} className={cn("h-4 w-4", isFavorite && "fill-current fav-pop")} />
        </button>
      </div>

      <button onClick={() => onOpen(g)} className="relative block w-full cursor-pointer p-3 text-left" aria-label={`Open ${g.name} details`}>
        {/* identity row */}
        <div className="flex items-center gap-3">
          <WineGlass
            color={g.wineColor}
            colorDeep={g.wineColorDeep}
            shape={g.handling.glassShape}
            className="h-[52px] w-[32px] shrink-0 drop-shadow-[0_4px_10px_rgba(0,0,0,0.5)]"
          />
          <div className="min-w-0">
            <h3 className="pr-[76px] font-display text-[21px] font-semibold leading-[1.1] text-cream">{g.name}</h3>
            <span
              className={cn(
                "mt-1 inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-[2px] text-[11.5px] font-bold uppercase tracking-wider",
                g.color === "red" ? "bg-claret/30 text-[#e8a1b0]" : "bg-gold/20 text-goldsoft"
              )}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: g.color === "red" ? "#c1455f" : "#e3c888" }} aria-hidden="true" />
              {g.color === "red" ? "Red" : "White"}
            </span>
          </div>
        </div>

        {/* tagline — the personable bit */}
        <p className="mt-2 text-[14px] leading-snug text-parchment/80 line-clamp-2">{g.tagline}</p>

        {/* aromas — one row, scrolls if needed, never wraps */}
        <div className="no-scrollbar -mx-3 mt-2.5 flex gap-1.5 overflow-x-auto px-3">
          {g.primaryFlavors.slice(0, 5).map((f) => (
            <span key={f} className="shrink-0">
              <FlavorChip flavor={f} size="sm" />
            </span>
          ))}
          <span className="flex shrink-0 items-center pl-0.5 text-faded" aria-hidden="true">
            <ChevronRight className="h-3.5 w-3.5" />
          </span>
        </div>

        {/* structure — 4 meters, one row */}
        <div className="mt-2.5 grid grid-cols-4 gap-2.5 border-t border-line/60 pt-2.5">
          <StackedMeter label="Body" value={g.profile.body} word={bodyShort(g.profile.body)} accent={accent} />
          <StackedMeter label="Acid" value={g.profile.acidity} word={levelShort(g.profile.acidity)} accent={accent} />
          <StackedMeter label="Tannin" value={g.profile.tannin} word={levelShort(g.profile.tannin)} accent={accent} />
          <StackedMeter label="Sweet" value={g.profile.sweetness} word={sweetnessShort(g.profile.sweetness)} accent={accent} />
        </div>
      </button>
    </motion.article>
  );
}

/** Dense single-row layout for rapid tableside scanning. */
export function GrapeRow({ grape: g, isFavorite, onOpen, onToggleFavorite }: Omit<Props, "inCompare" | "onToggleCompare">) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      className="group flex items-center gap-3 px-3 py-2.5 transition hover:bg-white/[0.03] sm:gap-4 sm:px-4"
    >
      <button onClick={() => onOpen(g)} className="flex min-w-0 flex-1 cursor-pointer items-center gap-3 text-left sm:gap-4" aria-label={`Open ${g.name} details`}>
        <span className="relative flex h-11 w-8 shrink-0 items-center justify-center">
          <span
            className="absolute inset-0 rounded-full opacity-20 blur-md transition group-hover:opacity-40"
            style={{ background: g.color === "red" ? g.wineColor : "#c9a44e" }}
          />
          <WineGlass color={g.wineColor} colorDeep={g.wineColorDeep} shape={g.handling.glassShape} className="relative h-10 w-6" />
        </span>

        <span className="min-w-0 flex-1 sm:w-[220px] sm:flex-none">
          <span className="block truncate font-display text-[19px] font-semibold leading-tight text-cream">{g.name}</span>
          <span className="block truncate text-[13.5px] leading-snug text-faded md:hidden">{g.primaryFlavors.slice(0, 3).join(" · ")}</span>
          <span className="hidden text-[13.5px] leading-snug text-faded md:block">{g.color === "red" ? "Red" : "White"}</span>
        </span>

        <span className="hidden min-w-0 flex-1 truncate text-[15px] text-parchment/80 md:block">
          {g.primaryFlavors.slice(0, 3).join(" · ")}
        </span>

        <span className="hidden w-[120px] shrink-0 lg:block">
          <MiniMeter label="Body" value={g.profile.body} accent={g.color === "red" ? "#c1455f" : "#c9a44e"} />
          <span className="mt-1 block">
            <MiniMeter label="Acid" value={g.profile.acidity} accent={g.color === "red" ? "#c1455f" : "#c9a44e"} />
          </span>
        </span>

        <ChevronRight className="h-5 w-5 shrink-0 text-faded transition group-hover:translate-x-0.5 group-hover:text-goldsoft" />
      </button>

      <button
        onClick={() => onToggleFavorite(g.id)}
        aria-pressed={isFavorite}
        aria-label={isFavorite ? `Remove ${g.name} from saved` : `Save ${g.name}`}
        className={cn(
          "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-all",
          isFavorite ? "border-claret bg-claret text-cream" : "border-line text-parchment hover:border-claret hover:text-[#e8a1b0]"
        )}
      >
        <Bookmark key={isFavorite ? "on2" : "off2"} className={cn("h-4.5 w-4.5", isFavorite && "fill-current fav-pop")} />
      </button>
    </motion.div>
  );
}
