import { Bookmark, Grape as GrapeIcon, Home, Settings2, Wine } from "lucide-react";
import { cn } from "../utils/cn";

interface Props {
  savedCount: number;
  onShowSaved: () => void;
  onShowAll: () => void;
  onOpenSettings: () => void;
  onNotify: (m: string) => void;
}

/** App-level navigation. Settings lives here; the top bar has been removed. */
export function MobileTabBar({ savedCount, onShowSaved, onShowAll, onOpenSettings, onNotify }: Props) {
  const tabs = [
    { label: "Home", icon: Home, action: () => onNotify("Home lives in the full app — you're in the Grape Guide.") },
    { label: "Cellar", icon: Wine, action: () => onNotify("My Cellar lives in the full app — you're in the Grape Guide.") },
    { label: "Grapes", icon: GrapeIcon, active: true, action: onShowAll },
    { label: "Saved", icon: Bookmark, action: onShowSaved, badge: savedCount },
    { label: "Settings", icon: Settings2, action: onOpenSettings },
  ];
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line/70 bg-ink/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl"
      aria-label="App navigation"
    >
      <div className="mx-auto grid max-w-lg grid-cols-5">
        {tabs.map((t) => (
          <button
            key={t.label}
            onClick={t.action}
            aria-current={t.active ? "page" : undefined}
            className={cn(
              "relative flex flex-col items-center gap-1 py-2.5 text-[12.5px] font-semibold transition",
              t.active ? "text-goldsoft" : "text-faded hover:text-parchment"
            )}
          >
            {t.active && <span className="absolute -top-px h-0.5 w-10 rounded-full bg-gold" />}
            <span className="relative">
              <t.icon className="h-6 w-6" />
              {!!t.badge && (
                <span className="absolute -right-2.5 -top-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-claret px-1 text-[11px] font-bold text-cream">
                  {t.badge}
                </span>
              )}
            </span>
            {t.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
