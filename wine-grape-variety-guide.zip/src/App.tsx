import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownWideNarrow,
  ArrowRight,
  Bookmark,
  Check,
  ChevronDown,
  Clock3,
  LayoutGrid,
  Rows3,
  Search,
  SlidersHorizontal,
  Sparkles,
  Wine,
  X,
} from "lucide-react";
import CompareView from "./components/CompareView";
import GrapeCard, { GrapeRow } from "./components/GrapeCard";
import GrapeDetail from "./components/GrapeDetail";
import { MobileTabBar } from "./components/Header";
import SettingsSheet from "./components/SettingsSheet";
import WineGlass from "./components/WineGlass";
import { ALL_STYLES, TIER_META, allGrapes, byTier, grapeById, popularityRank, stats, tierOf } from "./data";
import type { Grape } from "./data/types";
import { formatTempRange, tempPosition } from "./data/types";
import { cn } from "./utils/cn";

type ColorFilter = "all" | "red" | "white" | "saved";
type SortKey = "popular" | "az" | "body-desc" | "body-asc" | "acidity-desc" | "alcohol-desc" | "temp-asc";

const SORTS: { key: SortKey; label: string }[] = [
  { key: "popular", label: "Most popular" },
  { key: "az", label: "Name · A–Z" },
  { key: "body-desc", label: "Body · fullest first" },
  { key: "body-asc", label: "Body · lightest first" },
  { key: "acidity-desc", label: "Acidity · brightest first" },
  { key: "alcohol-desc", label: "Alcohol · highest first" },
  { key: "temp-asc", label: "Serving temp · coldest first" },
];

const COLLECTIONS: { title: string; blurb: string; ids: string[] }[] = [
  { title: "Steak night", blurb: "Bold, tannic reds built for the grill", ids: ["cabernet-sauvignon", "syrah", "malbec", "tempranillo", "nebbiolo"] },
  { title: "Seafood whites", blurb: "Salty, citrusy and made for the coast", ids: ["sauvignon-blanc", "albarino", "assyrtiko", "vermentino"] },
  { title: "Aromatic whites", blurb: "Perfumed, floral, unforgettable", ids: ["viognier", "gewurztraminer", "torrontes", "riesling"] },
  { title: "Chillable reds", blurb: "Light, juicy reds to serve cool", ids: ["gamay", "pinot-noir", "barbera", "grenache"] },
];

const HERO_IMG =
  "https://images.pexels.com/photos/16547190/pexels-photo-16547190.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1600";

function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* storage unavailable */
    }
  }, [key, value]);
  return [value, setValue] as const;
}

function matchesQuery(g: Grape, tokens: string[]) {
  const haystack = [
    g.name,
    g.pronunciation,
    g.origin,
    ...g.synonyms,
    ...g.primaryFlavors,
    ...g.styles,
    ...g.regions.map((r) => r.name),
    ...g.pairings,
  ]
    .join(" ")
    .toLowerCase();
  return tokens.every((t) => haystack.includes(t));
}

/* ------------------------------------------------------------------ */
/* Small shared pieces                                                 */
/* ------------------------------------------------------------------ */
function SectionHeading({ eyebrow, title, blurb, count, right }: { eyebrow?: string; title: string; blurb?: string; count?: number; right?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && (
          <p className="flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.22em] text-gold">
            <span className="hairline w-8" /> {eyebrow}
          </p>
        )}
        <h2 className="mt-1.5 font-display text-[29px] font-semibold leading-tight text-cream sm:text-3xl">
          {title}
          {count !== undefined && <span className="ml-2 align-middle font-mono text-[14.5px] font-normal text-faded">{count}</span>}
        </h2>
        {blurb && <p className="mt-1 max-w-xl text-[16px] text-parchment/75">{blurb}</p>}
      </div>
      {right}
    </div>
  );
}

/** Horizontal strip of grape "chips" with mini glasses — the fast lane. */
function QuickJump({ grapes, label, icon: Icon, onOpen, onClear }: { grapes: Grape[]; label: string; icon: typeof Clock3; onOpen: (g: Grape) => void; onClear?: () => void }) {
  if (grapes.length === 0) return null;
  return (
    <div>
      <div className="mb-2 flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.2em] text-gold">
        <Icon className="h-4.5 w-4.5" /> {label}
        {onClear && (
          <button onClick={onClear} className="ml-1 text-[12.5px] font-semibold normal-case tracking-normal text-faded hover:text-cream">
            clear
          </button>
        )}
      </div>
      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {grapes.map((g) => (
          <button
            key={g.id}
            onClick={() => onOpen(g)}
            className="group flex shrink-0 items-center gap-2 rounded-full border border-white/12 bg-black/35 py-1 pl-1.5 pr-3.5 backdrop-blur transition hover:border-gold/60 hover:bg-panel"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-full" style={{ background: `${g.color === "red" ? g.wineColor : "#c9a44e"}33` }}>
              <WineGlass color={g.wineColor} colorDeep={g.wineColorDeep} shape={g.handling.glassShape} className="h-6 w-4" />
            </span>
            <span className="text-[15px] font-semibold text-cream group-hover:text-goldsoft">{g.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Serving-temperature master chart                                    */
/* ------------------------------------------------------------------ */
function TempChart({ unit, onOpen }: { unit: "F" | "C"; onOpen: (g: Grape) => void }) {
  const [showAll, setShowAll] = useState(false);
  const source = showAll ? allGrapes : byTier(1);
  const sorted = [...source].sort(
    (a, b) => a.handling.serveTempF[0] + a.handling.serveTempF[1] - (b.handling.serveTempF[0] + b.handling.serveTempF[1])
  );
  const ticks = [35, 45, 55, 65];
  const tickLabel = (f: number) => (unit === "F" ? `${f}°F` : `${Math.round(((f - 32) * 5) / 9)}°C`);
  return (
    <section id="temp-chart" className="mx-auto mt-16 max-w-7xl scroll-mt-24 px-4 sm:px-6">
      <SectionHeading
        eyebrow="Pocket cheat-sheet"
        title="Serving temperature at a glance"
        blurb="From ice-cold Moscato to cellar-warm Cabernet. Tap any row for the full guide."
        right={
          <button
            onClick={() => setShowAll((s) => !s)}
            className="rounded-full border border-line px-3.5 py-1.5 text-[14.5px] font-semibold text-parchment transition hover:border-gold/60 hover:text-cream"
          >
            {showAll ? "Show essentials only" : `Show all ${stats.total} grapes`}
          </button>
        }
      />

      <div className="relative mt-5 overflow-hidden rounded-2xl border border-line bg-panel px-4 py-4 sm:px-6">
        <div className="relative mb-2 ml-[138px] h-5 sm:ml-[188px]">
          {ticks.map((t) => (
            <span key={t} className="absolute -translate-x-1/2 font-mono text-[12.5px] text-faded" style={{ left: `${tempPosition(t)}%` }}>
              {tickLabel(t)}
            </span>
          ))}
        </div>
        <div className="relative">
          {sorted.map((g) => {
            const [lo, hi] = g.handling.serveTempF;
            return (
              <button key={g.id} onClick={() => onOpen(g)} className="group flex w-full items-center gap-2 rounded-lg px-1 py-[5px] text-left transition hover:bg-white/[0.04]">
                <span className="flex w-[110px] shrink-0 items-center gap-1.5 sm:w-[160px]">
                  <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: g.color === "red" ? "#c1455f" : "#e3c888" }} />
                  <span className="truncate text-[14.5px] font-medium text-parchment group-hover:text-cream">{g.name}</span>
                </span>
                <span className="relative h-[14px] flex-1 rounded-full bg-white/[0.045]">
                  {[45, 55, 65].map((t) => (
                    <span key={t} className="absolute top-0 h-full w-px bg-white/[0.05]" style={{ left: `${tempPosition(t)}%` }} />
                  ))}
                  <motion.span
                    initial={{ opacity: 0, scaleX: 0.4 }}
                    whileInView={{ opacity: 1, scaleX: 1 }}
                    viewport={{ once: true, margin: "-40px" }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                    className="absolute top-[2px] h-[10px] origin-left rounded-full"
                    style={{
                      left: `${tempPosition(lo)}%`,
                      width: `${Math.max(tempPosition(hi) - tempPosition(lo), 2.5)}%`,
                      background: `linear-gradient(90deg, ${g.color === "red" ? g.wineColor : "#b98d2e"}, ${g.color === "red" ? "#c1455f" : "#e3c888"})`,
                      boxShadow: "0 1px 6px rgba(0,0,0,0.4)",
                    }}
                  />
                </span>
                <span className="w-[92px] shrink-0 text-right font-mono text-[13.5px] text-faded group-hover:text-goldsoft">{formatTempRange([lo, hi], unit)}</span>
              </button>
            );
          })}
        </div>
        <p className="mt-3 border-t border-line/60 pt-3 text-[14px] leading-relaxed text-faded">
          Rule of thumb: 20 minutes in the fridge takes the edge off a room-temperature red; 20 minutes out of the fridge wakes up an over-chilled white.
        </p>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* App                                                                 */
/* ------------------------------------------------------------------ */
export default function App() {
  const [query, setQuery] = useState("");
  const [colorFilter, setColorFilter] = useState<ColorFilter>("all");
  const [styleFilter, setStyleFilter] = useState<string | null>(null);
  const [sort, setSort] = useState<SortKey>("popular");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [showDeepCuts, setShowDeepCuts] = useState(false);
  const [favorites, setFavorites] = useLocalStorage<string[]>("ps:favorites", []);
  const [recent, setRecent] = useLocalStorage<string[]>("ps:recent", []);
  const [unit, setUnit] = useLocalStorage<"F" | "C">("ps:unit", "F");
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [searchFocused, setSearchFocused] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const searchRef = useRef<HTMLInputElement>(null);

  const notify = useCallback((msg: string) => setToast(msg), []);
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(id);
  }, [toast]);

  const openGrape = useCallback(
    (g: Grape) => {
      setSelectedId(g.id);
      setRecent((prev) => [g.id, ...prev.filter((x) => x !== g.id)].slice(0, 6));
    },
    [setRecent]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "/" && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLSelectElement)) {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = selectedId || compareOpen || filtersOpen || settingsOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [selectedId, compareOpen, filtersOpen, settingsOpen]);

  const favSet = useMemo(() => new Set(favorites), [favorites]);
  const toggleFavorite = useCallback(
    (id: string) => {
      setFavorites((prev) => {
        const has = prev.includes(id);
        if (!has) notify(`${grapeById(id)?.name} saved to your guide.`);
        return has ? prev.filter((x) => x !== id) : [...prev, id];
      });
    },
    [setFavorites, notify]
  );

  const toggleCompare = useCallback(
    (id: string) => {
      setCompareIds((prev) => {
        if (prev.includes(id)) return prev.filter((x) => x !== id);
        if (prev.length >= 3) {
          notify("Comparison holds 3 grapes — remove one to add another.");
          return prev;
        }
        return [...prev, id];
      });
    },
    [notify]
  );

  const hasFilters = query.trim() !== "" || colorFilter !== "all" || styleFilter !== null;
  const isBrowsing = !hasFilters && sort === "popular"; // the curated, tiered home layout

  const suggestions = useMemo(() => {
    if (query.trim().length < 2) return [];
    const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    return allGrapes.filter((g) => matchesQuery(g, tokens)).sort((a, b) => popularityRank(a.id) - popularityRank(b.id)).slice(0, 5);
  }, [query]);

  useEffect(() => setActiveIdx(0), [query]);

  const filtered = useMemo(() => {
    const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    const list = allGrapes.filter((g) => {
      if (colorFilter === "red" && g.color !== "red") return false;
      if (colorFilter === "white" && g.color !== "white") return false;
      if (colorFilter === "saved" && !favSet.has(g.id)) return false;
      if (styleFilter && !g.styles.includes(styleFilter)) return false;
      if (tokens.length && !matchesQuery(g, tokens)) return false;
      return true;
    });
    const by: Record<SortKey, (a: Grape, b: Grape) => number> = {
      popular: (a, b) => popularityRank(a.id) - popularityRank(b.id),
      az: (a, b) => a.name.localeCompare(b.name),
      "body-desc": (a, b) => b.profile.body - a.profile.body || popularityRank(a.id) - popularityRank(b.id),
      "body-asc": (a, b) => a.profile.body - b.profile.body || popularityRank(a.id) - popularityRank(b.id),
      "acidity-desc": (a, b) => b.profile.acidity - a.profile.acidity || popularityRank(a.id) - popularityRank(b.id),
      "alcohol-desc": (a, b) => b.profile.alcohol - a.profile.alcohol || popularityRank(a.id) - popularityRank(b.id),
      "temp-asc": (a, b) => a.handling.serveTempF[0] - b.handling.serveTempF[0] || popularityRank(a.id) - popularityRank(b.id),
    };
    return [...list].sort(by[sort]);
  }, [query, colorFilter, styleFilter, sort, favSet]);

  const selected = selectedId ? grapeById(selectedId) : undefined;
  const compareGrapes = compareIds.map(grapeById).filter(Boolean) as Grape[];
  const recentGrapes = recent.map(grapeById).filter(Boolean) as Grape[];
  const essentials = byTier(1);

  const featured = useMemo(() => {
    const now = new Date();
    const day = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
    return allGrapes[day % allGrapes.length];
  }, []);

  const clearFilters = () => {
    setQuery("");
    setColorFilter("all");
    setStyleFilter(null);
  };

  const scrollToGuide = () => document.getElementById("guide")?.scrollIntoView({ behavior: "smooth" });

  const cardProps = (g: Grape) => ({
    grape: g,
    unit,
    isFavorite: favSet.has(g.id),
    inCompare: compareIds.includes(g.id),
    onOpen: openGrape,
    onToggleFavorite: toggleFavorite,
    onToggleCompare: toggleCompare,
  });

  const renderFlat = (list: Grape[]) =>
    view === "grid" ? (
      <motion.div layout className="grid gap-3 sm:grid-cols-2 sm:gap-4 xl:grid-cols-3">
        <AnimatePresence>
          {list.map((g) => (
            <GrapeCard key={g.id} {...cardProps(g)} />
          ))}
        </AnimatePresence>
      </motion.div>
    ) : (
      <motion.div layout className="divide-y divide-line/60 overflow-hidden rounded-2xl border border-line bg-panel">
        <AnimatePresence>
          {list.map((g) => (
            <GrapeRow key={g.id} {...cardProps(g)} />
          ))}
        </AnimatePresence>
      </motion.div>
    );

  return (
    <div className="min-h-screen bg-ink pb-24">


      {/* ------------------------------ HERO ------------------------------ */}
      <section className="grain relative overflow-hidden">
        <img src={HERO_IMG} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/70 via-ink/60 to-ink" />
        <div className="absolute inset-0 bg-[radial-gradient(70%_60%_at_50%_0%,rgba(140,36,57,0.25),transparent)]" />

        <div className="relative mx-auto max-w-7xl px-4 pb-10 pt-10 sm:px-6 sm:pt-14">
          <div className="grid items-start gap-8 lg:grid-cols-[1.25fr_1fr]">
            {/* left: title + search + quick access */}
            <div>
              <p className="rise-in flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.26em] text-gold">
                <span className="hairline w-10" /> Reference Library · Grapes
              </p>
              <h1 className="rise-in mt-3 font-display text-[44px] font-semibold leading-[1.02] text-cream sm:text-6xl" style={{ animationDelay: "60ms" }}>
                The Grape <em className="text-goldsoft">Reference</em>
              </h1>
              <p className="rise-in mt-3 max-w-xl text-[17px] leading-relaxed text-parchment/85" style={{ animationDelay: "120ms" }}>
                Flavours, taste profiles, serving temperatures, decant times and pairings for {stats.total} varieties — the
                essentials up front, the deep cuts a tap away.
              </p>

              <div className="rise-in relative mt-6 max-w-xl" style={{ animationDelay: "180ms" }}>
                <Search className="pointer-events-none absolute left-4 top-1/2 z-10 h-5 w-5 -translate-y-1/2 text-gold" />
                <input
                  ref={searchRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onFocus={() => setSearchFocused(true)}
                  onBlur={() => window.setTimeout(() => setSearchFocused(false), 160)}
                  onKeyDown={(e) => {
                    if (!suggestions.length) return;
                    if (e.key === "ArrowDown") { e.preventDefault(); setActiveIdx((i) => (i + 1) % suggestions.length); }
                    else if (e.key === "ArrowUp") { e.preventDefault(); setActiveIdx((i) => (i - 1 + suggestions.length) % suggestions.length); }
                    else if (e.key === "Enter") { e.preventDefault(); const g = suggestions[activeIdx]; if (g) { openGrape(g); setSearchFocused(false); } }
                    else if (e.key === "Escape") { setSearchFocused(false); }
                  }}
                  placeholder='Search grapes, flavours, regions… try "black pepper"'
                  className="w-full rounded-2xl border border-line bg-panel/90 py-3.5 pl-12 pr-16 text-[17.5px] text-cream shadow-2xl outline-none backdrop-blur transition placeholder:text-faded focus:border-gold/70 focus:ring-2 focus:ring-gold/20"
                  aria-label="Search grape varieties"
                  aria-expanded={searchFocused && suggestions.length > 0}
                  aria-controls="search-suggestions"
                />
                {query ? (
                  <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 z-10 inline-flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full border border-line text-parchment transition hover:bg-claret hover:text-cream" aria-label="Clear search">
                    <X className="h-4.5 w-4.5" />
                  </button>
                ) : (
                  <kbd className="absolute right-4 top-1/2 z-10 hidden -translate-y-1/2 rounded-md border border-line bg-black/40 px-2 py-0.5 font-mono text-[13.5px] text-faded sm:block">/</kbd>
                )}
                {searchFocused && suggestions.length > 0 && (
                  <div id="search-suggestions" role="listbox" className="absolute left-0 right-0 top-[calc(100%+8px)] z-20 overflow-hidden rounded-2xl border border-line bg-cellar shadow-2xl">
                    {suggestions.map((g, i) => (
                      <button
                        key={g.id}
                        role="option"
                        aria-selected={i === activeIdx}
                        onMouseEnter={() => setActiveIdx(i)}
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => { openGrape(g); setSearchFocused(false); setQuery(""); }}
                        className={`flex w-full items-center gap-3 px-3 py-2.5 text-left transition ${i === activeIdx ? "bg-gold text-ink" : "hover:bg-white/[0.04] text-cream"}`}
                      >
                        <span className={`flex h-9 w-7 shrink-0 items-center justify-center rounded-full ${i === activeIdx ? "bg-ink/10" : "bg-white/[0.06]"}`}>
                          <WineGlass color={g.wineColor} colorDeep={g.wineColorDeep} shape={g.handling.glassShape} className="h-6 w-4" />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className={`block truncate font-display text-[15.5px] font-semibold ${i === activeIdx ? "text-ink" : "text-cream"}`}>{g.name}</span>
                          <span className={`block truncate text-[13.5px] ${i === activeIdx ? "text-ink/70" : "text-parchment/70"}`}>{g.primaryFlavors.slice(0, 3).join(" · ")} · {g.origin}</span>
                        </span>
                        <ArrowRight className={`h-4 w-4 shrink-0 ${i === activeIdx ? "text-ink/60" : "text-faded"}`} />
                      </button>
                    ))}
                    <div className="flex items-center justify-between border-t border-line bg-black/20 px-3 py-2">
                      <span className="text-[12.5px] text-faded">{filtered.length} matches · press Enter to open</span>
                      <button onMouseDown={(e) => e.preventDefault()} onClick={() => { setSearchFocused(false); scrollToGuide(); }} className={`text-[12.5px] font-semibold ${suggestions.length ? "text-gold hover:text-goldsoft" : "text-faded"}`}>See all →</button>
                    </div>
                  </div>
                )}
              </div>

              <div className="rise-in mt-6 space-y-5" style={{ animationDelay: "240ms" }}>
                <QuickJump grapes={recentGrapes} label="Recently viewed" icon={Clock3} onOpen={openGrape} onClear={() => setRecent([])} />
                <QuickJump grapes={essentials} label="Quick access · the essentials" icon={Sparkles} onOpen={openGrape} />
              </div>
              <div className="rise-in mt-4 flex flex-wrap items-center gap-1.5" style={{ animationDelay: "280ms" }}>
                <span className="text-[12.5px] font-semibold text-faded">Jump to:</span>
                {[
                  ["Essentials", "tier-essentials"],
                  ["Worth knowing", "tier-worth-knowing"],
                  ["Deep cuts", "tier-deep-cuts"],
                  ["Temp chart", "temp-chart"],
                ].map(([label, id]) => (
                  <a
                    key={id}
                    href={`#${id}`}
                    onClick={(e) => { e.preventDefault(); document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); }}
                    className="rounded-full border border-white/15 bg-black/25 px-2.5 py-1 text-[12.5px] font-medium text-parchment backdrop-blur hover:border-gold/40 hover:text-cream"
                  >
                    {label}
                  </a>
                ))}
              </div>
            </div>

            {/* right: grape of the day */}
            <button
              onClick={() => openGrape(featured)}
              className="rise-in group relative flex w-full items-center gap-4 overflow-hidden rounded-2xl border border-gold/30 bg-gradient-to-br from-panel2/95 to-panel/80 p-4 text-left shadow-2xl backdrop-blur transition hover:border-gold/60 sm:gap-5 sm:p-5 lg:mt-10"
              style={{ animationDelay: "300ms" }}
            >
              <div className="pointer-events-none absolute -left-10 top-0 h-full w-56 opacity-25 blur-2xl" style={{ background: featured.color === "red" ? featured.wineColor : "#c9a44e" }} />
              <WineGlass color={featured.wineColor} colorDeep={featured.wineColorDeep} shape={featured.handling.glassShape} swirl className="relative h-24 w-[60px] shrink-0 sm:h-28 sm:w-[70px]" />
              <div className="relative min-w-0 flex-1">
                <p className="inline-flex items-center gap-1.5 text-[12.5px] font-bold uppercase tracking-[0.22em] text-gold">
                  <Sparkles className="h-4 w-4" /> Grape of the day
                </p>
                <p className="mt-1 truncate font-display text-2xl font-semibold text-cream sm:text-[29px]">{featured.name}</p>
                <p className="line-clamp-2 text-[15.5px] leading-snug text-parchment/85">{featured.tagline}</p>
                <p className="mt-1.5 truncate text-[14px] text-parchment/60">{featured.origin} · {featured.styles.join(" · ")}</p>
              </div>
              <span className="relative hidden h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gold/40 text-goldsoft transition group-hover:bg-gold group-hover:text-ink sm:flex">
                <ArrowRight className="h-5 w-5" />
              </span>
            </button>
          </div>
        </div>
      </section>

      {/* ------------------------------ FILTER BAR ------------------------------ */}
      <div id="guide" className="sticky top-0 z-30 border-y border-line/60 bg-ink/90 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 py-2 sm:px-6 sm:py-2">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-1 items-center rounded-full border border-line bg-panel p-[3px] sm:flex-none" role="tablist" aria-label="Filter by colour">
              {(
                [
                  { key: "all", label: "All" },
                  { key: "red", label: "Reds" },
                  { key: "white", label: "Whites" },
                ] as { key: ColorFilter; label: string }[]
              ).map((t) => (
                <button
                  key={t.key}
                  role="tab"
                  aria-selected={colorFilter === t.key}
                  onClick={() => setColorFilter(t.key)}
                  className={cn(
                    "flex-1 rounded-full px-2.5 py-1.5 text-[14.5px] font-semibold transition sm:flex-none sm:px-3 sm:py-1.5",
                    colorFilter === t.key
                      ? t.key === "red" ? "bg-claret text-cream" : t.key === "white" ? "bg-gold text-ink" : "bg-cream text-ink"
                      : "text-parchment/75 hover:text-cream"
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => setColorFilter(colorFilter === "saved" ? "all" : "saved")}
              aria-pressed={colorFilter === "saved"}
              aria-label={colorFilter === "saved" ? "Show all grapes" : `Show saved grapes${favorites.length ? ` (${favorites.length})` : ""}`}
              className={cn(
                "relative inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition",
                colorFilter === "saved" ? "border-claret bg-claret text-cream" : "border-line bg-panel text-parchment hover:border-claret/60 hover:text-cream"
              )}
              title={favorites.length ? `${favorites.length} saved` : "No saved grapes yet — tap the bookmark on a card to save it"}
            >
              <Bookmark className={cn("h-4 w-4", colorFilter === "saved" && "fill-current")} />
              {favorites.length > 0 && (
                <span className="absolute -right-1 -top-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-claret px-1 text-[10px] font-bold leading-none text-cream ring-1 ring-ink">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Right cluster — Filters + view toggle + sort, all on one compact line */}
            <div className="flex items-center gap-1.5 sm:ml-auto">
              <button
                onClick={() => setFiltersOpen(true)}
                className={cn(
                  "inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-[13.5px] font-semibold transition",
                  styleFilter ? "border-gold bg-gold text-ink" : "border-line bg-panel text-parchment hover:border-gold/50 hover:text-cream"
                )}
              >
                <SlidersHorizontal className="h-3.5 w-3.5" />
                Filters
                {styleFilter && <span className="ml-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-ink px-1 text-[10px] font-bold text-gold">{1}</span>}
              </button>

              <div className="flex items-center rounded-full border border-line bg-panel p-[2px]" role="group" aria-label="Layout view">
                <button onClick={() => setView("grid")} aria-pressed={view === "grid"} title="Grid view" className={cn("inline-flex h-7 w-8 items-center justify-center rounded-full transition", view === "grid" ? "bg-gold text-ink" : "text-parchment/70 hover:text-cream")}>
                  <LayoutGrid className="h-3.5 w-3.5" />
                </button>
                <button onClick={() => setView("list")} aria-pressed={view === "list"} title="Compact list view" className={cn("inline-flex h-7 w-8 items-center justify-center rounded-full transition", view === "list" ? "bg-gold text-ink" : "text-parchment/70 hover:text-cream")}>
                  <Rows3 className="h-3.5 w-3.5" />
                </button>
              </div>

              <label className="relative inline-flex h-8 items-center gap-1 rounded-full border border-line bg-panel pl-2 pr-1">
                <ArrowDownWideNarrow className="h-3.5 w-3.5 shrink-0 text-gold" />
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value as SortKey)}
                  className="h-full bg-transparent pr-6 text-[13.5px] font-semibold text-parchment outline-none"
                  aria-label="Sort grape varieties"
                >
                  {SORTS.map((s) => (
                    <option key={s.key} value={s.key} className="bg-panel">{s.label}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 h-3 w-3 text-faded" />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Active filter summary — shows when any filter/search is applied */}
      {hasFilters && (
        <div className="border-b border-line/60 bg-panel/60">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-4 py-2.5 sm:px-6">
            <span className="text-[13.5px] font-medium text-parchment">
              <span className="font-bold text-cream">{filtered.length}</span> of {stats.total} · {filtered.length === 0 ? "no matches" : "matches"}
            </span>
            {query && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-gold/30 bg-gold/10 px-2.5 py-1 text-[13.5px] text-goldsoft">“{query}” <button onClick={() => setQuery("")} className="rounded-full bg-gold/20 p-0.5 hover:bg-gold hover:text-ink" aria-label="Clear search"><X className="h-3 w-3" /></button></span>
            )}
            {colorFilter !== "all" && (
              <span className="inline-flex items-center gap-1 rounded-full border border-line bg-ink px-2.5 py-1 text-[13.5px] font-medium capitalize text-parchment">{colorFilter} <button onClick={() => setColorFilter("all")} className="ml-1 rounded-full p-0.5 text-faded hover:text-cream"><X className="h-3 w-3" /></button></span>
            )}
            {styleFilter && (
              <span className="inline-flex items-center gap-1 rounded-full border border-line bg-ink px-2.5 py-1 text-[13.5px] font-medium text-parchment">{styleFilter} <button onClick={() => setStyleFilter(null)} className="ml-1 rounded-full p-0.5 text-faded hover:text-cream"><X className="h-3 w-3" /></button></span>
            )}
            <button onClick={() => { clearFilters(); setSort("popular"); }} className="ml-auto text-[13.5px] font-semibold text-goldsoft hover:text-cream">Clear all</button>
          </div>
        </div>
      )}

      {/* Filters sheet */}
      <AnimatePresence>
        {filtersOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center sm:p-6"
            onClick={() => setFiltersOpen(false)}
          >
            <motion.div
              initial={{ y: 32, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 32, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg overflow-hidden rounded-t-3xl border border-line bg-cellar shadow-2xl sm:rounded-3xl"
              role="dialog"
              aria-modal="true"
              aria-label="Filter by wine style"
            >
              <div className="flex items-center justify-between border-b border-line px-5 py-4">
                <h2 className="font-display text-[19px] font-semibold text-cream">Filter by style</h2>
                <button onClick={() => setFiltersOpen(false)} className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-line text-faded transition hover:bg-claret hover:text-cream" aria-label="Close filters">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="px-5 py-5">
                <p className="text-[13.5px] text-parchment/75">Pick a style to narrow the list — e.g. Bold Red, Crisp White, Aromatic, Age-Worthy…</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => setStyleFilter(null)}
                    aria-pressed={!styleFilter}
                    className={cn("rounded-full border px-3.5 py-2 text-[14px] font-semibold transition", !styleFilter ? "border-gold bg-gold text-ink" : "border-line text-parchment hover:border-gold/50 hover:text-cream")}
                  >
                    All styles
                  </button>
                  {ALL_STYLES.map((s) => (
                    <button
                      key={s}
                      onClick={() => setStyleFilter(s)}
                      aria-pressed={styleFilter === s}
                      className={cn("rounded-full border px-3.5 py-2 text-[14px] font-semibold transition", styleFilter === s ? "border-gold bg-gold text-ink" : "border-line text-parchment hover:border-gold/50 hover:text-cream")}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between border-t border-line bg-black/20 px-5 py-3">
                <span className="text-[13.5px] text-faded">{styleFilter ? `Filtering by “${styleFilter}”` : "Showing all styles"}</span>
                <div className="flex gap-2">
                  {styleFilter && (
                    <button onClick={() => setStyleFilter(null)} className="rounded-full border border-line px-4 py-2 text-[13.5px] font-semibold text-parchment hover:border-gold/50 hover:text-cream">Clear</button>
                  )}
                  <button onClick={() => setFiltersOpen(false)} className="rounded-full bg-gold px-5 py-2 text-[13.5px] font-bold text-ink hover:bg-goldsoft">Done</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ------------------------------ CONTENT ------------------------------ */}
      <main className="mx-auto max-w-7xl px-4 pt-10 sm:px-6">
        {isBrowsing ? (
          <div className="space-y-16">
            <section id="tier-essentials">
              <SectionHeading eyebrow="Start here" title={TIER_META[1].title} blurb={TIER_META[1].blurb} count={essentials.length} />
              <div className="mt-6">{renderFlat(essentials)}</div>
            </section>

            <section>
              <SectionHeading eyebrow="Curated" title="Picked for the table" blurb="Sommelier-favourite line-ups for common occasions — tap a grape to open its guide." />
              <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {COLLECTIONS.map((col) => (
                  <div key={col.title} className="rounded-2xl border border-line bg-panel p-4">
                    <h3 className="font-display text-[17px] font-semibold text-cream">{col.title}</h3>
                    <p className="mt-1 text-[13.5px] leading-snug text-parchment/70">{col.blurb}</p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {col.ids.map((id) => {
                        const g = grapeById(id)!;
                        return (
                          <button key={id} onClick={() => openGrape(g)} className="inline-flex items-center gap-1.5 rounded-full border border-line bg-ink px-2.5 py-1 text-[13.5px] font-medium text-parchment transition hover:border-gold/50 hover:text-cream">
                            <span className="h-2 w-2 rounded-full" style={{ background: g.color === "red" ? "#c1455f" : "#e3c888" }} />
                            {g.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section id="tier-worth-knowing">
              <SectionHeading eyebrow="Next step" title={TIER_META[2].title} blurb={TIER_META[2].blurb} count={byTier(2).length} />
              <div className="mt-6 divide-y divide-line/60 overflow-hidden rounded-2xl border border-line bg-panel">
                {byTier(2).map((g) => (
                  <GrapeRow key={g.id} {...cardProps(g)} />
                ))}
              </div>
            </section>

            <section id="tier-deep-cuts">
              <SectionHeading
                eyebrow="Feeling adventurous"
                title={TIER_META[3].title}
                blurb={TIER_META[3].blurb}
                count={byTier(3).length}
                right={
                  <button
                    onClick={() => setShowDeepCuts((s) => !s)}
                    aria-expanded={showDeepCuts}
                    className="inline-flex items-center gap-1.5 rounded-full border border-line px-4 py-2 text-[15px] font-semibold text-parchment transition hover:border-gold/60 hover:text-cream"
                  >
                    {showDeepCuts ? "Hide" : `Show ${byTier(3).length} grapes`}
                    <ChevronDown className={cn("h-5 w-5 transition-transform", showDeepCuts && "rotate-180")} />
                  </button>
                }
              />
              <AnimatePresence initial={false}>
                {showDeepCuts ? (
                  <motion.div key="open" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.3 }} className="overflow-hidden">
                    <div className="mt-6 divide-y divide-line/60 overflow-hidden rounded-2xl border border-line bg-panel">
                      {byTier(3).map((g) => (
                        <GrapeRow key={g.id} {...cardProps(g)} />
                      ))}
                    </div>
                  </motion.div>
                ) : (
                  <motion.button
                    key="closed"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setShowDeepCuts(true)}
                    className="mt-6 flex w-full flex-wrap items-center gap-x-3 gap-y-2 rounded-2xl border border-dashed border-line px-5 py-4 text-left transition hover:border-gold/50"
                  >
                    {byTier(3).map((g) => (
                      <span key={g.id} className="inline-flex items-center gap-1.5 text-[15.5px] text-parchment/80">
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: g.color === "red" ? "#c1455f" : "#e3c888" }} />
                        {g.name}
                      </span>
                    ))}
                    <span className="ml-auto text-[14.5px] font-semibold text-goldsoft">Expand →</span>
                  </motion.button>
                )}
              </AnimatePresence>
            </section>
          </div>
        ) : (
          /* ---------- filtered / sorted results ---------- */
          <section>
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="font-display text-2xl font-semibold text-cream">
                {colorFilter === "saved" ? "Your saved guide" : colorFilter === "red" ? "Red varieties" : colorFilter === "white" ? "White varieties" : query ? `Results for “${query}”` : "All varieties"}
                {styleFilter && <span className="text-goldsoft"> · {styleFilter}</span>}
              </h2>
              <div className="flex shrink-0 items-center gap-3">
                <p className="font-mono text-[14.5px] text-faded">{filtered.length} of {stats.total}</p>
                {(hasFilters || sort !== "popular") && (
                  <button onClick={() => { clearFilters(); setSort("popular"); }} className="text-[14.5px] font-semibold text-goldsoft hover:text-cream">
                    Reset
                  </button>
                )}
              </div>
            </div>

            {filtered.length === 0 ? (
              <div className="mt-8 flex flex-col items-center rounded-3xl border border-dashed border-line bg-panel/60 px-6 py-16 text-center">
                {colorFilter === "saved" && !query && !styleFilter ? (
                  <>
                    <Bookmark className="h-10 w-10 text-gold" />
                    <p className="mt-4 font-display text-2xl font-semibold text-cream">Your pocket guide is empty</p>
                    <p className="mt-1.5 max-w-sm text-[15.5px] text-parchment/80">Tap the bookmark on any grape to build your personal shortlist — perfect for the wine shop or the dinner table.</p>
                    <button onClick={() => setColorFilter("all")} className="mt-5 rounded-full bg-claret px-5 py-2.5 text-[15.5px] font-semibold text-cream transition hover:bg-claretdeep">Back to the essentials</button>
                  </>
                ) : (
                  <>
                    <Wine className="h-10 w-10 text-gold" />
                    <p className="mt-4 font-display text-2xl font-semibold text-cream">No grapes match that pour</p>
                    <p className="mt-1.5 max-w-sm text-[15.5px] text-parchment/80">Try a flavour ("peach", "leather"), a region ("Bordeaux"), or clear the filters.</p>
                    <button onClick={clearFilters} className="mt-5 rounded-full bg-claret px-5 py-2.5 text-[15.5px] font-semibold text-cream transition hover:bg-claretdeep">Clear search & filters</button>
                  </>
                )}
              </div>
            ) : (
              <div className="mt-6 space-y-10">
                {/* keep the hierarchy even in results: popular first, deeper cuts visually grouped */}
                {sort === "popular" && filtered.some((g) => tierOf(g) !== 1) && filtered.some((g) => tierOf(g) === 1) ? (
                  <>
                    <div>{renderFlat(filtered.filter((g) => tierOf(g) === 1))}</div>
                    <div>
                      <p className="mb-4 flex items-center gap-2 text-[13.5px] font-bold uppercase tracking-[0.2em] text-faded">
                        <span className="hairline w-6" /> Less common matches
                      </p>
                      <div className="divide-y divide-line/60 overflow-hidden rounded-2xl border border-line bg-panel">
                        {filtered.filter((g) => tierOf(g) !== 1).map((g) => (
                          <GrapeRow key={g.id} {...cardProps(g)} />
                        ))}
                      </div>
                    </div>
                  </>
                ) : (
                  renderFlat(filtered)
                )}
              </div>
            )}
          </section>
        )}
      </main>

      <TempChart unit={unit} onOpen={openGrape} />

      {/* ------------------------------ FOOTER ------------------------------ */}
      <footer className="mx-auto mt-16 max-w-7xl px-4 pb-10 sm:px-6">
        <div className="hairline" />
        <div className="flex flex-col items-center gap-2 pt-6 text-center">
          <Wine className="h-5 w-5 text-gold" />
          <p className="font-display text-xl italic text-parchment">"Wine is sunlight, held together by water."</p>
          <p className="text-[13.5px] uppercase tracking-[0.2em] text-faded">— Galileo Galilei</p>
          <p className="mt-4 max-w-lg text-[14.5px] leading-relaxed text-faded">
            Pocket Sommelier · Grape Reference module. Written for quick reference, modelled on the structure of Wine Folly's grape guides. Always drink responsibly.
          </p>
        </div>
      </footer>

      {/* ------------------------------ COMPARE TRAY ------------------------------ */}
      <AnimatePresence>
        {compareGrapes.length > 0 && !compareOpen && !selected && (
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 24 }} className="fixed inset-x-0 bottom-[84px] z-40 flex justify-center px-4">
            <div className="flex max-w-full items-center gap-2 rounded-full border border-gold/40 bg-panel2/95 py-2 pl-3 pr-2 shadow-2xl backdrop-blur">
              <div className="no-scrollbar flex max-w-[42vw] items-center gap-1.5 overflow-x-auto">
                {compareGrapes.map((g) => (
                  <span key={g.id} className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-black/35 py-1 pl-2 pr-1 text-[14px] font-semibold text-cream">
                    <span className="h-2 w-2 rounded-full" style={{ background: g.color === "red" ? "#c1455f" : "#e3c888" }} />
                    {g.name}
                    <button onClick={() => toggleCompare(g.id)} className="inline-flex h-5 w-5 items-center justify-center rounded-full text-faded transition hover:bg-claret hover:text-cream" aria-label={`Remove ${g.name}`}>
                      <X className="h-4 w-4" />
                    </button>
                  </span>
                ))}
              </div>
              <button
                onClick={() => compareGrapes.length >= 2 && setCompareOpen(true)}
                disabled={compareGrapes.length < 2}
                className={cn("shrink-0 rounded-full px-4 py-2 text-[15px] font-bold transition", compareGrapes.length >= 2 ? "bg-gold text-ink hover:bg-goldsoft" : "cursor-not-allowed bg-white/[0.06] text-faded")}
              >
                {compareGrapes.length >= 2 ? "Compare" : "Add 1 more"}
              </button>
              <button onClick={() => setCompareIds([])} className="shrink-0 px-1 text-[14px] font-semibold text-faded transition hover:text-cream">Clear</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ------------------------------ TOAST ------------------------------ */}
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="fixed inset-x-0 bottom-[152px] z-[60] flex justify-center px-4" role="status">
            <p className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-ink/95 px-4 py-2.5 text-[15.5px] font-medium text-cream shadow-2xl">
              <Check className="h-5 w-5 text-gold" />
              {toast}
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ------------------------------ MODALS ------------------------------ */}
      <AnimatePresence>
        {selected && (
          <GrapeDetail
            key="detail"
            grape={selected}
            unit={unit}
            isFavorite={favSet.has(selected.id)}
            inCompare={compareIds.includes(selected.id)}
            onClose={() => setSelectedId(null)}
            onNavigate={openGrape}
            onToggleFavorite={toggleFavorite}
            onToggleCompare={toggleCompare}
            onNotify={notify}
          />
        )}
        {compareOpen && compareGrapes.length > 0 && (
          <CompareView
            key="compare"
            grapes={compareGrapes}
            unit={unit}
            onClose={() => setCompareOpen(false)}
            onRemove={(id) => {
              toggleCompare(id);
              if (compareGrapes.length <= 1) setCompareOpen(false);
            }}
            onOpen={(g) => {
              setCompareOpen(false);
              openGrape(g);
            }}
          />
        )}
      </AnimatePresence>

      <SettingsSheet
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        unit={unit}
        onToggleUnit={() => setUnit(unit === "F" ? "C" : "F")}
        onClearRecents={() => setRecent([])}
        onClearFavorites={() => setFavorites([])}
        favoritesCount={favorites.length}
        recentsCount={recent.length}
      />

      <MobileTabBar
        savedCount={favorites.length}
        onShowSaved={() => {
          setColorFilter("saved");
          scrollToGuide();
        }}
        onShowAll={() => {
          clearFilters();
          scrollToGuide();
        }}
        onOpenSettings={() => setSettingsOpen(true)}
        onNotify={notify}
      />
    </div>
  );
}
