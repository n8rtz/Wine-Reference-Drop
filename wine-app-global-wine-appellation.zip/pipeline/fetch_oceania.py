#!/usr/bin/env python3
"""Australia (Wine Australia GI Register) and New Zealand (IPONZ GI Register).

Australia: https://www.wineaustralia.com/labelling/register-of-protected-gis-and-other-terms/geographical-indications
           The register is an HTML table (State / Zone / Region / Sub-region). Parsed with pandas.read_html.
New Zealand: https://www.iponz.govt.nz/about-ip/geographical-indications/register/  (HTML register of GIs)
Both fall back to Wikidata (Australian GI Q11818734, NZ wine regions located in Q664) when the page layout changes.
Outputs: data/au_gis.csv, data/nz_gis.csv
"""
from __future__ import annotations

import io
import re

import pandas as pd
from bs4 import BeautifulSoup

from common import Record, get, sparql, write_records

AU_URL = "https://www.wineaustralia.com/labelling/register-of-protected-gis-and-other-terms/geographical-indications"
NZ_URL = "https://www.iponz.govt.nz/about-ip/geographical-indications/register/"


def australia() -> list[Record]:
    recs: list[Record] = []
    try:
        html = get(AU_URL, cache="wine_australia_gis.html").text
        tables = pd.read_html(io.StringIO(html))
        for t in tables:
            cols = [str(c).strip().lower() for c in t.columns]
            if not any("region" in c for c in cols):
                continue
            t.columns = cols
            state_col = next((c for c in cols if "state" in c), None)
            zone_col = next((c for c in cols if "zone" in c), None)
            region_col = next((c for c in cols if c.startswith("region")), None)
            sub_col = next((c for c in cols if "sub" in c), None)
            for _, row in t.iterrows():
                state = str(row.get(state_col, "")).strip() if state_col else ""
                zone = str(row.get(zone_col, "")).strip() if zone_col else ""
                region = str(row.get(region_col, "")).strip() if region_col else ""
                sub = str(row.get(sub_col, "")).strip() if sub_col else ""
                for val, cls, parent in ((zone, "Zone", state), (region, "GI", zone or state), (sub, "Sub-region", region)):
                    if val and val.lower() not in ("nan", "none", "-"):
                        recs.append(Record(country="Australia", region=state or "Australia", sub_region=zone or None,
                                           appellation_name=val, classification_system=cls, parent_name=parent or None,
                                           source="Wine Australia GI Register"))
    except Exception as exc:  # noqa: BLE001
        print("[au] register parse failed, falling back to Wikidata:", exc)
    if not recs:
        for r in sparql("""
            SELECT ?item ?itemLabel ?parentLabel WHERE {
              ?item wdt:P31 wd:Q11818734 . OPTIONAL { ?item wdt:P131 ?parent . }
              SERVICE wikibase:label { bd:serviceParam wikibase:language "en". } }""", cache="wd_au.json"):
            recs.append(Record(country="Australia", region=r.get("parentLabel") or "Australia",
                               appellation_name=r["itemLabel"], classification_system="GI", source="Wikidata (fallback)"))
    # de-duplicate on name
    seen, out = set(), []
    for r in recs:
        k = r.appellation_name.lower()
        if k not in seen:
            seen.add(k)
            out.append(r)
    return out


def new_zealand() -> list[Record]:
    recs: list[Record] = []
    try:
        html = get(NZ_URL, cache="iponz_gis.html").text
        soup = BeautifulSoup(html, "lxml")
        text_rows = []
        for tr in soup.select("table tr"):
            cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
            if len(cells) >= 2:
                text_rows.append(cells)
        for cells in text_rows:
            name = cells[0]
            if not name or name.lower() in ("name", "geographical indication"):
                continue
            if re.search(r"wine", " ".join(cells), re.I) or len(cells) <= 3:
                recs.append(Record(country="New Zealand", region="New Zealand", appellation_name=name,
                                   classification_system="GI", official_code=next((c for c in cells if re.fullmatch(r"\d{3,}", c)), None),
                                   source="IPONZ GI Register"))
    except Exception as exc:  # noqa: BLE001
        print("[nz] register parse failed, falling back to Wikidata:", exc)
    if not recs:
        for r in sparql("""
            SELECT ?item ?itemLabel ?parentLabel WHERE {
              ?item wdt:P31/wdt:P279* wd:Q1341100 ; wdt:P17 wd:Q664 . OPTIONAL { ?item wdt:P131 ?parent . }
              SERVICE wikibase:label { bd:serviceParam wikibase:language "en". } }""", cache="wd_nz.json"):
            recs.append(Record(country="New Zealand", region=r.get("parentLabel") or "New Zealand",
                               appellation_name=r["itemLabel"], classification_system="GI", source="Wikidata (fallback)"))
    return recs


if __name__ == "__main__":
    write_records(australia(), "au_gis")
    write_records(new_zealand(), "nz_gis")
