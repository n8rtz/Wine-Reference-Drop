#!/usr/bin/env python3
"""EU eAmbrosia register → all registered WINE PDO/PGI names with official file numbers.

Source: https://webgate.ec.europa.eu/eambrosia-api/api/v1/geographical-indications  (keyless JSON API)
Covers France (AOC/AOP), Italy (DOC/DOCG/IGT), Spain (DO/DOCa/VP), Germany, Portugal, Austria (DAC),
Greece, Hungary and every other member state, plus third-country GIs protected in the EU.

Outputs:
  data/eambrosia_wine.json   compact snapshot (also consumed by the Next.js seed: src/data/eambrosia-wine.json)
  data/eu_appellations.csv   normalised Record rows
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from common import DATA_DIR, Record, get, write_records

API = "https://webgate.ec.europa.eu/eambrosia-api/api/v1/geographical-indications"

ISO = {
    "FR": "France", "IT": "Italy", "ES": "Spain", "PT": "Portugal", "DE": "Germany", "AT": "Austria", "HU": "Hungary",
    "GR": "Greece", "EL": "Greece", "RO": "Romania", "BG": "Bulgaria", "HR": "Croatia", "SI": "Slovenia", "CZ": "Czechia",
    "SK": "Slovakia", "CY": "Cyprus", "MT": "Malta", "LU": "Luxembourg", "GB": "United Kingdom", "NL": "Netherlands",
    "BE": "Belgium", "DK": "Denmark", "IE": "Ireland", "PL": "Poland", "SE": "Sweden", "LT": "Lithuania", "LV": "Latvia",
    "EE": "Estonia", "FI": "Finland", "US": "United States", "AU": "Australia", "CL": "Chile", "ZA": "South Africa",
    "BR": "Brazil", "GE": "Georgia", "MD": "Moldova", "CH": "Switzerland", "CN": "China", "JP": "Japan", "CA": "Canada",
    "RS": "Serbia", "BA": "Bosnia and Herzegovina", "MK": "North Macedonia", "ME": "Montenegro", "AL": "Albania",
    "NZ": "New Zealand", "AR": "Argentina", "MX": "Mexico", "VN": "Vietnam", "SG": "Singapore", "KR": "South Korea",
}
NATIONAL = {
    "France": {"PDO": "AOC", "PGI": "IGP"}, "Italy": {"PDO": "DOP", "PGI": "IGT"}, "Spain": {"PDO": "DOP", "PGI": "IGP"},
    "Portugal": {"PDO": "DOP", "PGI": "IGP"}, "Germany": {"PDO": "Anbaugebiet", "PGI": "Landwein"},
    "Luxembourg": {"PDO": "AOP", "PGI": "IGP"},
}


def fetch(include_applied: bool = False) -> list[dict]:
    r = get(API, cache="eambrosia_all.json")
    items = r.json()
    out = []
    for i in items:
        if i.get("productType") != "WINE":
            continue
        if i.get("removedFlag"):
            continue
        if not include_applied and i.get("status") != "registered":
            continue
        names: list[str] = []
        for n in i.get("protectedNames") or []:
            for part in str(n).split(" / "):
                part = part.strip()
                if part and part not in names:
                    names.append(part)
        if not names:
            continue
        out.append({
            "id": i.get("giIdentifier"), "file": i.get("fileNumber"), "names": names,
            "countries": i.get("countries") or [], "type": i.get("giType"), "status": i.get("status"),
            "date": i.get("euProtectionDate"), "removed": bool(i.get("removedFlag")),
            "third": bool(i.get("thirdCountryFlag")),
        })
    return out


def to_records(items: list[dict]) -> list[Record]:
    recs = []
    for it in items:
        country = ISO.get((it["countries"] or ["?"])[0], (it["countries"] or ["?"])[0])
        cls = NATIONAL.get(country, {}).get(it["type"], it["type"])
        recs.append(Record(country=country, region="", appellation_name=it["names"][0],
                           classification_system=cls, official_code=it["file"],
                           alternate_names=it["names"][1:], source="eAmbrosia (EU)"))
    return recs


if __name__ == "__main__":
    include_applied = "--include-applied" in sys.argv
    items = fetch(include_applied)
    (DATA_DIR / "eambrosia_wine.json").write_text(json.dumps(items, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"[eambrosia] {len(items)} wine GIs")
    write_records(to_records(items), "eu_appellations")
    # keep the Next.js seed snapshot in sync when run from the repo root
    seed_copy = Path(__file__).resolve().parents[1] / "src" / "data" / "eambrosia-wine.json"
    if seed_copy.parent.exists() and "--sync-seed" in sys.argv:
        seed_copy.write_text(json.dumps(items, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        print(f"[eambrosia] synced {seed_copy}")
