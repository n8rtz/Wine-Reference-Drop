#!/usr/bin/env python3
"""Merge the curated gazetteer with fetched registry records and build the final SQLite database.

Inputs (all optional – whatever exists is merged, curated rows win on conflicts):
  data/curated.json        – export of the Next.js gazetteer  (GET /api/export?format=json  or  npm run build:sqlite)
  data/*.csv               – outputs of the fetch_*.py scripts

Outputs:
  dist/wine_gazetteer.sqlite      – schema from the spec + appellations_fts (FTS5, tokenize='trigram') + appellation_meta
  dist/sql/<continent>.sql        – executable INSERT batches grouped by continent
  dist/sql/<country>.sql          – executable INSERT batches grouped by country

Usage:
  python build_sqlite.py [--curated data/curated.json] [--no-fetched]
"""
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
from collections import defaultdict
from pathlib import Path

from common import DATA_DIR, DIST_DIR, generate_alternates, normalize_for_search, strip_diacritics

CONTINENTS = {
    "France": "Europe", "Italy": "Europe", "Spain": "Europe", "Portugal": "Europe", "Germany": "Europe", "Austria": "Europe",
    "Switzerland": "Europe", "Luxembourg": "Europe", "Hungary": "Europe", "Czechia": "Europe", "Slovakia": "Europe",
    "Slovenia": "Europe", "Croatia": "Europe", "Greece": "Europe", "Romania": "Europe", "Bulgaria": "Europe", "Cyprus": "Europe",
    "Malta": "Europe", "United Kingdom": "Europe", "Netherlands": "Europe", "Belgium": "Europe", "Denmark": "Europe",
    "Georgia": "Europe", "Moldova": "Europe", "Ukraine": "Europe", "Armenia": "Europe", "Turkey": "Asia", "Israel": "Asia",
    "Lebanon": "Asia", "Japan": "Asia", "China": "Asia", "India": "Asia", "United States": "North America", "Canada": "North America",
    "Mexico": "North America", "Argentina": "South America", "Chile": "South America", "Uruguay": "South America",
    "Brazil": "South America", "Peru": "South America", "Bolivia": "South America", "Australia": "Oceania",
    "New Zealand": "Oceania", "South Africa": "Africa",
}

DDL = """
CREATE TABLE appellations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    country VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    sub_region VARCHAR(100),
    appellation_name VARCHAR(150) NOT NULL,
    classification_system VARCHAR(50),
    official_code VARCHAR(20),
    alternate_names TEXT
);
CREATE VIRTUAL TABLE appellations_fts USING fts5(
    appellation_name, region, sub_region, country, alternate_names, tokenize='trigram'
);
CREATE TABLE appellation_meta (
    appellation_id INTEGER PRIMARY KEY REFERENCES appellations(id),
    continent VARCHAR(40), level VARCHAR(20), parent_id INTEGER REFERENCES appellations(id), source VARCHAR(80)
);
CREATE INDEX idx_appellations_country ON appellations(country);
CREATE INDEX idx_appellations_region ON appellations(country, region);
CREATE INDEX idx_appellations_name ON appellations(appellation_name);
"""


def load_curated(path: Path) -> list[dict]:
    if not path.exists():
        print(f"[build] no curated file at {path} (run the Next.js export first) – continuing with fetched data only")
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = data["rows"] if isinstance(data, dict) else data
    print(f"[build] curated rows: {len(rows)}")
    return rows


def load_fetched() -> list[dict]:
    rows: list[dict] = []
    for csv_path in sorted(DATA_DIR.glob("*.csv")):
        with csv_path.open(encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                rows.append(r)
    print(f"[build] fetched rows: {len(rows)}")
    return rows


def merge(curated: list[dict], fetched: list[dict]) -> list[dict]:
    """Curated rows win; fetched rows fill official codes / alternates or add new entries."""
    by_key: dict[tuple[str, str], dict] = {}
    out: list[dict] = []
    for r in curated:
        key = (r["country"], normalize_for_search(r["appellation_name"]))
        by_key[key] = r
        out.append(r)
        for alt in (r.get("alternate_names") or "").split(", "):
            if alt:
                by_key.setdefault((r["country"], normalize_for_search(alt)), r)
    for r in fetched:
        name = (r.get("appellation_name") or "").strip()
        if not name:
            continue
        key = (r["country"], normalize_for_search(name))
        hit = by_key.get(key)
        if hit:
            if not hit.get("official_code") and r.get("official_code"):
                hit["official_code"] = r["official_code"]
            alts = [a for a in (hit.get("alternate_names") or "").split(", ") if a]
            if name != hit["appellation_name"] and name not in alts:
                alts.append(name)
            hit["alternate_names"] = ", ".join(alts) or None
            continue
        new = {
            "id": None, "country": r["country"], "region": r.get("region") or r["country"], "sub_region": r.get("sub_region") or None,
            "appellation_name": name, "classification_system": r.get("classification_system") or None,
            "official_code": (r.get("official_code") or None), "alternate_names": r.get("alternate_names") or ", ".join(generate_alternates(name)) or None,
            "continent": CONTINENTS.get(r["country"], "Other"), "level": r.get("level") or "appellation", "parent_id": None,
            "source": r.get("source") or "fetched", "_parent_name": r.get("parent_name"),
        }
        by_key[key] = new
        out.append(new)
    # assign ids & resolve parents for new rows
    next_id = max([int(r["id"]) for r in out if r.get("id")] or [0]) + 1
    for r in out:
        if not r.get("id"):
            r["id"] = next_id
            next_id += 1
    name_to_id = {(r["country"], normalize_for_search(r["appellation_name"])): r["id"] for r in out}
    for r in out:
        if r.get("parent_id") is None:
            for cand in (r.get("_parent_name"), r.get("sub_region"), r.get("region")):
                if cand and normalize_for_search(cand) != normalize_for_search(r["appellation_name"]):
                    pid = name_to_id.get((r["country"], normalize_for_search(cand)))
                    if pid and pid != r["id"]:
                        r["parent_id"] = pid
                        break
        r["official_code"] = (r.get("official_code") or None)
        if r["official_code"]:
            r["official_code"] = str(r["official_code"])[:20]
        r["region"] = strip_diacritics(r["region"]) if False else r["region"]  # keep accents (spec)
    return out


def q(v) -> str:
    if v is None or v == "":
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def write_sql(rows: list[dict], path: Path, title: str) -> None:
    lines = [f"-- {title}", f"-- {len(rows)} rows", DDL.strip(), "BEGIN;"]
    for i in range(0, len(rows), 200):
        chunk = rows[i:i + 200]
        lines.append("INSERT INTO appellations (id, country, region, sub_region, appellation_name, classification_system, official_code, alternate_names) VALUES")
        lines.append(",\n".join(f"  ({r['id']}, {q(r['country'])}, {q(r['region'])}, {q(r['sub_region'])}, {q(r['appellation_name'])}, {q(r['classification_system'])}, {q(r['official_code'])}, {q(r['alternate_names'])})" for r in chunk) + ";")
    for i in range(0, len(rows), 200):
        chunk = rows[i:i + 200]
        lines.append("INSERT INTO appellation_meta (appellation_id, continent, level, parent_id, source) VALUES")
        lines.append(",\n".join(f"  ({r['id']}, {q(r.get('continent'))}, {q(r.get('level'))}, {q(r.get('parent_id'))}, {q(r.get('source'))})" for r in chunk) + ";")
    lines.append("INSERT INTO appellations_fts (rowid, appellation_name, region, sub_region, country, alternate_names) SELECT id, appellation_name, region, sub_region, country, alternate_names FROM appellations;")
    lines.append("COMMIT;")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build(rows: list[dict]) -> Path:
    db_path = DIST_DIR / "wine_gazetteer.sqlite"
    if db_path.exists():
        db_path.unlink()
    con = sqlite3.connect(db_path)
    con.executescript(DDL)
    con.executemany(
        "INSERT INTO appellations (id, country, region, sub_region, appellation_name, classification_system, official_code, alternate_names) VALUES (?,?,?,?,?,?,?,?)",
        [(r["id"], r["country"], r["region"], r.get("sub_region"), r["appellation_name"], r.get("classification_system"), r.get("official_code"), r.get("alternate_names")) for r in rows],
    )
    con.executemany(
        "INSERT INTO appellation_meta (appellation_id, continent, level, parent_id, source) VALUES (?,?,?,?,?)",
        [(r["id"], r.get("continent"), r.get("level"), r.get("parent_id"), r.get("source")) for r in rows],
    )
    con.execute("INSERT INTO appellations_fts (rowid, appellation_name, region, sub_region, country, alternate_names) SELECT id, appellation_name, region, sub_region, country, alternate_names FROM appellations")
    con.commit()
    n = con.execute("SELECT count(*) FROM appellations").fetchone()[0]
    probe = con.execute("SELECT appellation_name FROM appellations_fts WHERE appellations_fts MATCH 'neuf' LIMIT 1").fetchone()
    con.execute("VACUUM")
    con.close()
    print(f"[build] {db_path} – {n} rows, FTS5 trigram probe: {probe}")
    return db_path


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--curated", default=str(DATA_DIR / "curated.json"))
    ap.add_argument("--no-fetched", action="store_true")
    args = ap.parse_args()
    rows = merge(load_curated(Path(args.curated)), [] if args.no_fetched else load_fetched())
    rows.sort(key=lambda r: int(r["id"]))
    build(rows)
    sql_dir = DIST_DIR / "sql"
    sql_dir.mkdir(exist_ok=True)
    by_cont, by_country = defaultdict(list), defaultdict(list)
    for r in rows:
        by_cont[r.get("continent") or "Other"].append(r)
        by_country[r["country"]].append(r)
    for cont, rs in by_cont.items():
        write_sql(rs, sql_dir / f"{normalize_for_search(cont).replace(' ', '_')}.sql", f"Wine Gazetteer – {cont}")
    for c, rs in by_country.items():
        write_sql(rs, sql_dir / f"country_{normalize_for_search(c).replace(' ', '_')}.sql", f"Wine Gazetteer – {c}")
    write_sql(rows, sql_dir / "world.sql", "Wine Gazetteer – World")
    print(f"[build] SQL batches -> {sql_dir}")
