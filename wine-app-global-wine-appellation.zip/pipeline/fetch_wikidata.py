#!/usr/bin/env python3
"""Wikidata SPARQL fallback / enrichment: wine regions (Q1341100) and appellations (Q12857018).

Returns item label, country, administrative parent (P131) and 'part of' (P361) so the merge step can
infer region → sub-region hierarchy for registries that do not expose it (SAWIS, INV, SAG, IPONZ).
Output: data/wikidata_wine_regions.csv
"""
from __future__ import annotations

from common import Record, sparql, write_records

QUERY = """
SELECT DISTINCT ?item ?itemLabel ?countryLabel ?parentLabel ?partOfLabel ?classLabel WHERE {
  VALUES ?root { wd:Q1341100 wd:Q12857018 }
  ?item wdt:P31/wdt:P279* ?root .
  ?item wdt:P31 ?class .
  OPTIONAL { ?item wdt:P17 ?country . }
  OPTIONAL { ?item wdt:P131 ?parent . }
  OPTIONAL { ?item wdt:P361 ?partOf . }
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en,fr,it,es,de,pt,el,hu". }
}
"""

# Secondary, by national type: AOC (Q152045), AVA (Q372286), DOC Italy (Q20979), DOCG (Q1137215),
# DO Spain (Q1146012), German wine region (Q1151417), Australian GI (Q11818734), South African WO (Q7995546)
QUERY_TYPES = """
SELECT DISTINCT ?item ?itemLabel ?countryLabel ?parentLabel ?classLabel WHERE {
  VALUES ?class { wd:Q152045 wd:Q372286 wd:Q20979 wd:Q1137215 wd:Q1146012 wd:Q1151417 wd:Q11818734 wd:Q7995546 }
  ?item wdt:P31 ?class .
  OPTIONAL { ?item wdt:P17 ?country . }
  OPTIONAL { ?item wdt:P131 ?parent . }
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en,fr,it,es,de,pt". }
}
"""


def run() -> list[Record]:
    rows = sparql(QUERY, cache="wikidata_regions.json") + sparql(QUERY_TYPES, cache="wikidata_types.json")
    seen: set[tuple[str, str]] = set()
    recs: list[Record] = []
    for r in rows:
        label = r.get("itemLabel") or ""
        country = r.get("countryLabel") or ""
        if not label or label.startswith("Q") and label[1:].isdigit():
            continue
        key = (country, label.lower())
        if key in seen:
            continue
        seen.add(key)
        recs.append(Record(country=country or "Unknown", region=r.get("partOfLabel") or r.get("parentLabel") or "",
                           appellation_name=label, classification_system=r.get("classLabel"),
                           official_code=r.get("item", "").rsplit("/", 1)[-1][:20],
                           source="Wikidata SPARQL"))
    return recs


if __name__ == "__main__":
    write_records(run(), "wikidata_wine_regions")
