# Wine Gazetteer – acquisition & build pipeline

Executable Python scripts that pull every legally defined wine appellation / GI from the
primary registries, normalise them (UTF-8, accent-preserving names + unaccented alternates),
merge them with the curated seed shipped in `src/data/*.ts`, and build the SQLite deliverable
with an FTS5 **trigram** index for OCR string matching.

```
pip install -r requirements.txt
python run_all.py                       # fetch everything + build dist/wine_gazetteer.sqlite
python fetch_eambrosia.py --sync-seed   # refresh src/data/eambrosia-wine.json used by the Next.js seed
python fetch_ttb_avas.py  --sync-seed   # refresh src/data/ttb-avas.json
python build_sqlite.py --curated data/curated.json
```

| Script | Registry | Endpoint / method |
| --- | --- | --- |
| `fetch_eambrosia.py` | EU eAmbrosia (PDO/PGI wine, all member states + 3rd countries) | `https://webgate.ec.europa.eu/eambrosia-api/api/v1/geographical-indications` (JSON) |
| `fetch_ttb_avas.py` | US TTB – 27 CFR Part 9 (all AVAs) | eCFR versioner API (structure JSON + full XML for state inference) |
| `fetch_oceania.py` | Wine Australia GI Register · IPONZ GI Register | HTML tables (`pandas.read_html` / BeautifulSoup), Wikidata fallback |
| `fetch_south_africa.py` | SAWIS Wine of Origin (GU / region / district / ward) | SAWIS production-areas table, Wikidata fallback |
| `fetch_south_america.py` | INV Argentina (IG / DOC) · SAG Chile (Decreto 464) | argentina.gob.ar page, BCN leychile text, Wikidata fallback |
| `fetch_wikidata.py` | Wikidata SPARQL (`wd:Q1341100` wine region, `wd:Q12857018` appellation) | `https://query.wikidata.org/sparql` |
| `build_sqlite.py` | – | merge + dedupe → `dist/wine_gazetteer.sqlite`, `dist/sql/*.sql` |

`data/curated.json` is the JSON export of the running app (`GET /api/export?format=json`), which already
contains the curated hierarchy (Pauillac → Médoc → Bordeaux → France; Oakville → Napa Valley → California → USA),
eAmbrosia file numbers and CFR section numbers. Fetched rows fill missing codes / add new registrations.

### Target schema (dist/wine_gazetteer.sqlite)

```sql
CREATE TABLE appellations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    country VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    sub_region VARCHAR(100),
    appellation_name VARCHAR(150) NOT NULL,
    classification_system VARCHAR(50),
    official_code VARCHAR(20),
    alternate_names TEXT
);
CREATE VIRTUAL TABLE appellations_fts USING fts5(
    appellation_name, region, sub_region, country, alternate_names, tokenize='trigram'
);
-- plus appellation_meta(appellation_id, continent, level, parent_id, source) for hierarchy navigation
```

OCR example:

```sql
SELECT a.appellation_name, a.region, a.country, bm25(appellations_fts) AS rank
FROM appellations_fts JOIN appellations a ON a.id = appellations_fts.rowid
WHERE appellations_fts MATCH 'chateauneuf' ORDER BY rank LIMIT 5;
```
