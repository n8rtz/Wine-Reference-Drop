#!/usr/bin/env python3
"""Run every fetcher, then build the SQLite database. Usage: python run_all.py [--skip-fetch]"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEPS = ["fetch_eambrosia.py", "fetch_ttb_avas.py", "fetch_oceania.py", "fetch_south_africa.py",
         "fetch_south_america.py", "fetch_wikidata.py"]

if "--skip-fetch" not in sys.argv:
    for step in STEPS:
        print(f"\n=== {step} ===")
        rc = subprocess.call([sys.executable, str(HERE / step)])
        if rc != 0:
            print(f"!! {step} exited with {rc} – continuing (fallbacks are applied downstream)")
print("\n=== build_sqlite.py ===")
sys.exit(subprocess.call([sys.executable, str(HERE / "build_sqlite.py")]))
