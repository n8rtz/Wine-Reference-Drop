"""Shared helpers for the Wine Gazetteer acquisition pipeline.

Mirrors the normalisation rules used by the Next.js seed (src/lib/normalize.ts)
so records produced here merge cleanly with the curated dataset.
"""
from __future__ import annotations

import csv
import json
import os
import re
import time
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable

DATA_DIR = Path(__file__).resolve().parent / "data"
DIST_DIR = Path(__file__).resolve().parent / "dist"
DATA_DIR.mkdir(exist_ok=True)
DIST_DIR.mkdir(exist_ok=True)

USER_AGENT = "WineGazetteerPipeline/1.0 (+https://github.com/; data engineering; contact: data@example.org)"

SPECIAL = {
    "ß": "ss", "ø": "o", "Ø": "O", "æ": "ae", "Æ": "AE", "œ": "oe", "Œ": "OE", "đ": "d", "Đ": "D",
    "ł": "l", "Ł": "L", "ı": "i", "ħ": "h", "Ħ": "H", "þ": "th", "ð": "d", "’": "'", "‘": "'", "`": "'",
    "´": "'", "–": "-", "—": "-", "‐": "-",
}


def strip_diacritics(s: str) -> str:
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = "".join(SPECIAL.get(ch, ch) for ch in s)
    return unicodedata.normalize("NFC", s)


def normalize_for_search(s: str) -> str:
    s = strip_diacritics(s).lower()
    s = re.sub(r"['\".]", "", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def generate_alternates(name: str, manual: Iterable[str] = ()) -> list[str]:
    """Unaccented / punctuation variants + Saint↔St etc. (same rules as the TS seed)."""
    out: list[str] = []
    seen = {name.lower()}

    def push(v: str) -> None:
        v = re.sub(r"\s+", " ", v).strip()
        if v and v.lower() not in seen:
            seen.add(v.lower())
            out.append(v)

    for base in [name, *manual]:
        forms = {base, strip_diacritics(base)}
        for f in list(forms):
            push(f)
            if "-" in f:
                push(f.replace("-", " "))
            if re.search(r"['’]", f):
                push(re.sub(r"['’]", "", f))
                push(re.sub(r"['’]", " ", f))
            push(re.sub(r"\bSaint-", "St-", f))
            push(re.sub(r"\bSaint ", "St. ", f))
            push(re.sub(r"\bSainte-", "Ste-", f))
            push(re.sub(r"\bSt\. ", "Saint ", f))
            push(re.sub(r"\bMount ", "Mt. ", f))
            push(re.sub(r"\bMt\. ", "Mount ", f))
            if re.search(r"[äöüÄÖÜ]", f):
                push(f.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("Ä", "Ae").replace("Ö", "Oe").replace("Ü", "Ue"))
    # second pass: unaccented copies of transformed forms
    for v in list(out):
        push(strip_diacritics(v))
    return out


@dataclass
class Record:
    country: str
    region: str
    appellation_name: str
    sub_region: str | None = None
    classification_system: str | None = None
    official_code: str | None = None
    alternate_names: list[str] = field(default_factory=list)
    source: str = ""
    level: str = "appellation"
    parent_name: str | None = None

    def finalize(self) -> dict:
        alts = generate_alternates(self.appellation_name, self.alternate_names)
        d = asdict(self)
        d["alternate_names"] = ", ".join(a.replace(",", " ") for a in alts) or None
        d["region"] = self.region or self.country
        return d


FIELDS = ["country", "region", "sub_region", "appellation_name", "classification_system", "official_code",
          "alternate_names", "source", "level", "parent_name"]


def write_records(records: Iterable[Record], name: str) -> Path:
    rows = [r.finalize() for r in records]
    path = DATA_DIR / f"{name}.csv"
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    (DATA_DIR / f"{name}.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"[{name}] wrote {len(rows)} records -> {path}")
    return path


def session():
    import requests  # lazy: build_sqlite.py only needs the standard library

    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json, text/html;q=0.9, */*;q=0.8"})
    return s


def get(url: str, *, params: dict | None = None, retries: int = 3, timeout: int = 90, cache: str | None = None, **kw):
    """GET with retries + optional on-disk cache (pipeline/data/cache/*)."""
    cache_dir = DATA_DIR / "cache"
    cache_dir.mkdir(exist_ok=True)
    if cache and (cache_dir / cache).exists() and not os.environ.get("NO_CACHE"):
        class _R:  # minimal cached response shim
            status_code = 200
            content = (cache_dir / cache).read_bytes()
            text = content.decode("utf-8", "replace")

            def json(self):
                return json.loads(self.text)
        return _R()  # type: ignore[return-value]
    last: Exception | None = None
    for attempt in range(retries):
        try:
            r = session().get(url, params=params, timeout=timeout, **kw)
            r.raise_for_status()
            if cache:
                (cache_dir / cache).write_bytes(r.content)
            return r
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"GET {url} failed after {retries} attempts: {last}")


def sparql(query: str, cache: str | None = None) -> list[dict]:
    r = get("https://query.wikidata.org/sparql", params={"query": query, "format": "json"}, cache=cache,
            headers={"Accept": "application/sparql-results+json"})
    data = r.json()
    out = []
    for b in data["results"]["bindings"]:
        out.append({k: v.get("value") for k, v in b.items()})
    return out
