#!/usr/bin/env python3
"""US TTB American Viticultural Areas from 27 CFR Part 9 (Subpart C) via the eCFR API.

Sources:
  structure: https://www.ecfr.gov/api/versioner/v1/structure/current/title-27.json
  full text: https://www.ecfr.gov/api/versioner/v1/full/{date}/title-27.xml?part=9   (state inference)

Outputs: data/ttb_avas.json (section → name) and data/us_avas.csv (Record rows, region = state)
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from common import DATA_DIR, Record, get, write_records

STRUCTURE = "https://www.ecfr.gov/api/versioner/v1/structure/current/title-27.json"
TITLES = "https://www.ecfr.gov/api/versioner/v1/titles.json"
FULL = "https://www.ecfr.gov/api/versioner/v1/full/{date}/title-27.xml"

STATES = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida",
          "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine",
          "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada",
          "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma",
          "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah",
          "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]
STATE_RE = re.compile(r"\b(" + "|".join(sorted(STATES, key=len, reverse=True)) + r")\b")


def sections() -> list[dict]:
    tree = get(STRUCTURE, cache="ecfr_title27_structure.json").json()
    out: list[dict] = []

    def walk(n: dict) -> None:
        if n.get("type") == "section" and str(n.get("identifier", "")).startswith("9."):
            ident = n["identifier"]
            try:
                num = float(ident.split(".")[1])
            except ValueError:
                return
            if 22 <= num < 1000:  # Subpart C – approved AVAs start at § 9.22 (Augusta)
                label = (n.get("label_description") or n.get("label") or "").strip()
                name = re.sub(r"\s+AVA\.?$", "", label, flags=re.I).rstrip(".").strip()
                out.append({"section": ident, "name": name})
        for c in n.get("children") or []:
            walk(c)

    walk(tree)
    return out


def infer_states(secs: list[dict]) -> dict[str, str]:
    """Parse the § 9.x text to find the state(s) each AVA lies in (best effort)."""
    try:
        latest = get(TITLES, cache="ecfr_titles.json").json()
        date = next(t["latest_issue_date"] for t in latest["titles"] if t["number"] == 27)
        xml = get(FULL.format(date=date), params={"part": "9"}, cache="ecfr_title27_part9.xml").text
    except Exception as exc:  # noqa: BLE001
        print("[ttb] could not fetch full text for state inference:", exc)
        return {}
    states: dict[str, str] = {}
    for m in re.finditer(r'<DIV8[^>]*N="(9\.\d+)"[^>]*>(.*?)</DIV8>', xml, flags=re.S):
        ident, body = m.group(1), re.sub(r"<[^>]+>", " ", m.group(2))
        head = body[:1500]
        found = []
        for s in STATE_RE.findall(head):
            if s not in found:
                found.append(s)
        if found:
            states[ident] = found[0]
    return states


if __name__ == "__main__":
    secs = sections()
    (DATA_DIR / "ttb_avas.json").write_text(json.dumps(secs, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"[ttb] {len(secs)} AVA sections")
    states = infer_states(secs) if "--no-states" not in sys.argv else {}
    recs = [Record(country="United States", region=states.get(s["section"], ""), appellation_name=s["name"],
                   classification_system="AVA", official_code=f"27 CFR {s['section']}", source="TTB 27 CFR Part 9")
            for s in secs]
    write_records(recs, "us_avas")
    if "--sync-seed" in sys.argv:
        seed_copy = Path(__file__).resolve().parents[1] / "src" / "data" / "ttb-avas.json"
        seed_copy.write_text(json.dumps(secs, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        print(f"[ttb] synced {seed_copy}")
