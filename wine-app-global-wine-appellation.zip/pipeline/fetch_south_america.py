#!/usr/bin/env python3
"""Argentina (INV Indicaciones Geográficas / DOC) and Chile (SAG Decreto 464 Denominaciones de Origen).

Argentina: the INV publishes the IG register (Ley 25.163) on argentina.gob.ar; names are extracted from the
           page text / linked PDF list. Fallback: Wikidata items located in Argentina that are wine regions.
Chile:     Decreto 464/1994 (Zonificación Vitícola) consolidated text on leychile.cl (BCN API, JSON/HTML).
           Regions → sub-regions → zones → areas are parsed from the article structure. Fallback: Wikidata.
Outputs: data/ar_igs.csv, data/cl_dos.csv
"""
from __future__ import annotations

import re

from bs4 import BeautifulSoup

from common import Record, get, sparql, write_records

INV_URL = "https://www.argentina.gob.ar/inv/vinos/indicaciones-geograficas"
BCN_URL = "https://www.bcn.cl/leychile/navegar?idNorma=13601"  # Decreto 464 Zonificación vitícola


def argentina() -> list[Record]:
    recs: list[Record] = []
    try:
        html = get(INV_URL, cache="inv_igs.html").text
        soup = BeautifulSoup(html, "lxml")
        current_prov = "Argentina"
        for el in soup.select("h2, h3, h4, li, td"):
            txt = el.get_text(" ", strip=True)
            if not txt or len(txt) > 80:
                continue
            if el.name in ("h2", "h3", "h4"):
                current_prov = txt
                continue
            m = re.match(r"^(IG|I\.G\.|DOC)\s*[:\-–]?\s*(.+)$", txt, re.I)
            name = m.group(2).strip() if m else None
            cls = (m.group(1).upper().replace(".", "") if m else "IG")
            if name:
                recs.append(Record(country="Argentina", region=current_prov, appellation_name=name,
                                   classification_system=cls, source="INV Argentina"))
    except Exception as exc:  # noqa: BLE001
        print("[ar] INV page parse failed:", exc)
    if not recs:
        for r in sparql("""
            SELECT DISTINCT ?item ?itemLabel ?parentLabel WHERE {
              ?item wdt:P31/wdt:P279* wd:Q1341100 ; wdt:P17 wd:Q414 . OPTIONAL { ?item wdt:P131 ?parent . }
              SERVICE wikibase:label { bd:serviceParam wikibase:language "es,en". } }""", cache="wd_ar.json"):
            recs.append(Record(country="Argentina", region=r.get("parentLabel") or "Argentina",
                               appellation_name=r["itemLabel"], classification_system="IG", source="Wikidata (fallback)"))
    return recs


def chile() -> list[Record]:
    recs: list[Record] = []
    try:
        html = get(BCN_URL, cache="bcn_decreto_464.html").text
        text = BeautifulSoup(html, "lxml").get_text("\n", strip=True)
        region = subregion = None
        for line in text.splitlines():
            l = line.strip()
            m = re.match(r"^(?:[IVX]+\.?|\d+\.)?\s*REGI[ÓO]N\s+(?:VIT[ÍI]COLA\s+)?(?:DE[L]?\s+)?(.+)$", l, re.I)
            if m:
                region = "Valle " + m.group(1).title() if not m.group(1).lower().startswith(("valle", "atacama", "coquimbo", "aconcagua", "sur", "austral")) else m.group(1).title()
                recs.append(Record(country="Chile", region=region, appellation_name=region, classification_system="DO", level="region", source="SAG Decreto 464"))
                continue
            m = re.match(r"^(?:[a-z]\)|\d+\.\d+)?\s*Subregi[óo]n\s+(?:del?\s+)?(.+)$", l, re.I)
            if m and region:
                subregion = m.group(1).title()
                recs.append(Record(country="Chile", region=region, sub_region=subregion, appellation_name=subregion, classification_system="DO", level="sub_region", source="SAG Decreto 464"))
                continue
            m = re.match(r"^(?:Zona|[ÁA]rea)\s+(?:del?\s+)?(.+)$", l, re.I)
            if m and region:
                recs.append(Record(country="Chile", region=region, sub_region=subregion, appellation_name=m.group(1).title(), classification_system="DO", source="SAG Decreto 464"))
    except Exception as exc:  # noqa: BLE001
        print("[cl] BCN parse failed:", exc)
    if not recs:
        for r in sparql("""
            SELECT DISTINCT ?item ?itemLabel ?parentLabel WHERE {
              ?item wdt:P31/wdt:P279* wd:Q1341100 ; wdt:P17 wd:Q298 . OPTIONAL { ?item wdt:P131 ?parent . }
              SERVICE wikibase:label { bd:serviceParam wikibase:language "es,en". } }""", cache="wd_cl.json"):
            recs.append(Record(country="Chile", region=r.get("parentLabel") or "Chile", appellation_name=r["itemLabel"],
                               classification_system="DO", source="Wikidata (fallback)"))
    return recs


if __name__ == "__main__":
    write_records(argentina(), "ar_igs")
    write_records(chile(), "cl_dos")
