#!/usr/bin/env python3
"""South Africa – SAWIS Wine of Origin scheme (geographical units, regions, districts, wards).

SAWIS publishes the demarcated production areas as a PDF / web table
(https://www.sawis.co.za/cert/productionareas.php). Because the layout changes, this fetcher:
  1. tries to parse any HTML table on the SAWIS page (columns: Geographical unit / Region / District / Ward)
  2. falls back to Wikidata (items with P31 = Wine of Origin ward/district/region Q7995546 or located in ZA)
Output: data/za_wo.csv
"""
from __future__ import annotations

import io

import pandas as pd

from common import Record, get, sparql, write_records

SAWIS_URL = "https://www.sawis.co.za/cert/productionareas.php"
LEVELS = [("geographical unit", "Geographical Unit"), ("region", "Region"), ("district", "District"), ("ward", "Ward")]


def sawis() -> list[Record]:
    recs: list[Record] = []
    html = get(SAWIS_URL, cache="sawis_production_areas.html").text
    for t in pd.read_html(io.StringIO(html)):
        cols = [str(c).strip().lower() for c in t.columns]
        if not any("ward" in c or "district" in c for c in cols):
            continue
        t.columns = cols
        for _, row in t.iterrows():
            chain = []
            for key, cls in LEVELS:
                col = next((c for c in cols if key in c), None)
                val = str(row.get(col, "")).strip() if col else ""
                if val and val.lower() not in ("nan", "none", "-"):
                    chain.append((val, cls))
            for i, (val, cls) in enumerate(chain):
                gu = chain[0][0] if chain else "Western Cape"
                parent = chain[i - 1][0] if i else None
                recs.append(Record(country="South Africa", region=gu, sub_region=chain[1][0] if len(chain) > 1 and i > 1 else None,
                                   appellation_name=val, classification_system=cls, parent_name=parent,
                                   source="SAWIS Wine of Origin"))
    seen, out = set(), []
    for r in recs:
        if r.appellation_name.lower() not in seen:
            seen.add(r.appellation_name.lower())
            out.append(r)
    return out


def wikidata_fallback() -> list[Record]:
    rows = sparql("""
        SELECT DISTINCT ?item ?itemLabel ?classLabel ?parentLabel WHERE {
          { ?item wdt:P31 wd:Q7995546 } UNION { ?item wdt:P31/wdt:P279* wd:Q1341100 ; wdt:P17 wd:Q258 }
          OPTIONAL { ?item wdt:P31 ?class . } OPTIONAL { ?item wdt:P131 ?parent . }
          SERVICE wikibase:label { bd:serviceParam wikibase:language "en,af". } }""", cache="wd_za.json")
    return [Record(country="South Africa", region=r.get("parentLabel") or "Western Cape", appellation_name=r["itemLabel"],
                   classification_system="WO", source="Wikidata (fallback)") for r in rows]


if __name__ == "__main__":
    try:
        recs = sawis()
    except Exception as exc:  # noqa: BLE001
        print("[za] SAWIS parse failed, using Wikidata:", exc)
        recs = []
    if not recs:
        recs = wikidata_fallback()
    write_records(recs, "za_wo")
