/**
 * CLI: npm run build:sqlite
 * Builds the SQLite deliverable straight from the curated data modules (no database needed) and
 * writes static artefacts to public/downloads/ + pipeline/data/curated.json for the Python pipeline.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { getGazetteerRows } from "@/data";
import { buildCsv, buildSqlScript, buildSqliteDatabase, slugify, type ExportRow } from "@/lib/sqlite-export";

const rows: ExportRow[] = getGazetteerRows().map((r) => ({
  id: r.id,
  country: r.country,
  region: r.region,
  sub_region: r.subRegion,
  appellation_name: r.appellationName,
  classification_system: r.classificationSystem,
  official_code: r.officialCode,
  alternate_names: r.alternateNames,
  continent: r.continent,
  level: r.level,
  parent_id: r.parentId,
  source: r.source,
}));

const out = join(process.cwd(), "public", "downloads");
mkdirSync(join(out, "sql"), { recursive: true });
writeFileSync(join(out, "wine_gazetteer.sqlite"), buildSqliteDatabase(rows));
writeFileSync(join(out, "wine_gazetteer.csv"), buildCsv(rows));
writeFileSync(join(out, "sql", "world.sql"), buildSqlScript(rows, { title: "Wine Gazetteer — World" }));
const continents = [...new Set(rows.map((r) => r.continent))];
for (const c of continents) {
  writeFileSync(join(out, "sql", `${slugify(c!)}.sql`), buildSqlScript(rows.filter((r) => r.continent === c), { title: `Wine Gazetteer — ${c}` }));
}
const pipelineData = join(process.cwd(), "pipeline", "data");
mkdirSync(pipelineData, { recursive: true });
writeFileSync(join(pipelineData, "curated.json"), JSON.stringify({ generated_at: new Date().toISOString(), count: rows.length, rows }));
console.log(`built ${rows.length} rows -> ${out} (sqlite, csv, ${continents.length + 1} sql batches) and pipeline/data/curated.json`);
