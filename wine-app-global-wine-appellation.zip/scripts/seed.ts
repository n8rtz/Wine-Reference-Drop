/** CLI: npm run db:seed [-- --force]  – provisions pg_trgm, table, indexes and (re)loads the gazetteer. */
import "dotenv/config";
import { ensureSchema, loadRows } from "@/lib/seed";
import { pool } from "@/db";

(async () => {
  const force = process.argv.includes("--force");
  await ensureSchema();
  const res = await loadRows({ force });
  console.log(`seed complete: ${res.inserted} inserted, ${res.total} total rows (force=${force})`);
  await pool.end();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
