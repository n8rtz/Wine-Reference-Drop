"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type Row = {
  id: number;
  country: string;
  region: string;
  sub_region: string | null;
  appellation_name: string;
  classification_system: string | null;
  official_code: string | null;
  alternate_names: string | null;
  continent: string;
  level: string;
  parent_id: number | null;
  source: string;
  score?: number;
  match_type?: string;
};

type TreeNode = Row & { children: TreeNode[] };

type Detail = Row & { ancestors: Row[]; children: Row[] };

export interface ExplorerProps {
  countries: Array<{ country: string; continent: string; count: number }>;
  classifications: Array<{ classification: string; count: number }>;
  continents: Array<{ continent: string; count: number }>;
}

const TABS = [
  { id: "search", label: "Fuzzy search" },
  { id: "ocr", label: "OCR label match" },
  { id: "browse", label: "Browse hierarchy" },
  { id: "export", label: "Downloads & SQL" },
] as const;
type TabId = (typeof TABS)[number]["id"];

const SAMPLE_OCR =
  "GRAND VIN DE BORDEAUX 2016 CHATEAU LYNCH-BAGES PAUILLAC APPELLATION PAUILLAC CONTROLEE MIS EN BOUTEILLE AU CHATEAU 13% vol";

function Badge({ children, tone = "stone" }: { children: React.ReactNode; tone?: "stone" | "wine" | "green" | "amber" }) {
  const tones = {
    stone: "bg-stone-100 text-stone-700 ring-stone-200",
    wine: "bg-[#5b1a2a]/10 text-[#5b1a2a] ring-[#5b1a2a]/20",
    green: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    amber: "bg-amber-50 text-amber-800 ring-amber-200",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ${tones[tone]}`}>
      {children}
    </span>
  );
}

function Crumbs({ row }: { row: Row }) {
  const parts = [row.country, row.region !== row.country ? row.region : null, row.sub_region && row.sub_region !== row.region ? row.sub_region : null].filter(
    Boolean,
  ) as string[];
  return (
    <span className="text-xs text-stone-500">
      {parts.map((p, i) => (
        <span key={i}>
          {i > 0 && <span className="mx-1 text-stone-300">›</span>}
          {p}
        </span>
      ))}
    </span>
  );
}

function ResultRow({ row, onSelect }: { row: Row; onSelect: (id: number) => void }) {
  return (
    <button
      onClick={() => onSelect(row.id)}
      className="group flex w-full flex-col gap-1 rounded-xl border border-stone-200 bg-white px-4 py-3 text-left transition hover:border-[#5b1a2a]/40 hover:shadow-sm"
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-serif text-[17px] font-semibold text-stone-900 group-hover:text-[#5b1a2a]">{row.appellation_name}</span>
        {row.classification_system && <Badge tone="wine">{row.classification_system}</Badge>}
        {row.official_code && <Badge>{row.official_code}</Badge>}
        {row.match_type && <Badge tone={row.match_type === "exact" ? "green" : "amber"}>{row.match_type}</Badge>}
        {typeof row.score === "number" && <span className="ml-auto font-mono text-xs text-stone-400">{row.score.toFixed(2)}</span>}
      </div>
      <Crumbs row={row} />
      {row.alternate_names && (
        <div className="truncate text-xs text-stone-400">
          <span className="text-stone-500">alt:</span> {row.alternate_names}
        </div>
      )}
    </button>
  );
}

function DetailPanel({ id, onClose, onSelect }: { id: number; onClose: () => void; onSelect: (id: number) => void }) {
  const [detail, setDetail] = useState<Detail | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    setDetail(null);
    setError(null);
    fetch(`/api/appellations/${id}`)
      .then((r) => r.json())
      .then((d) => alive && (d.error ? setError(d.error) : setDetail(d)))
      .catch((e) => alive && setError(String(e)));
    return () => {
      alive = false;
    };
  }, [id]);

  return (
    <aside className="sticky top-6 rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
      <div className="mb-3 flex items-start justify-between gap-3">
        <h3 className="font-serif text-xl font-semibold text-[#5b1a2a]">{detail?.appellation_name ?? "Loading…"}</h3>
        <button onClick={onClose} className="rounded-md px-2 py-1 text-xs text-stone-500 hover:bg-stone-100">
          close
        </button>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      {detail && (
        <div className="space-y-4 text-sm">
          <div className="flex flex-wrap gap-1.5">
            {detail.classification_system && <Badge tone="wine">{detail.classification_system}</Badge>}
            <Badge>{detail.level.replace("_", " ")}</Badge>
            <Badge>{detail.continent}</Badge>
            {detail.official_code && <Badge tone="amber">{detail.official_code}</Badge>}
          </div>
          <div>
            <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-stone-400">Hierarchy</div>
            <div className="flex flex-wrap items-center gap-1 text-sm">
              <span className="text-stone-600">{detail.country}</span>
              {detail.ancestors.map((a) => (
                <span key={a.id} className="flex items-center gap-1">
                  <span className="text-stone-300">›</span>
                  <button onClick={() => onSelect(a.id)} className="text-[#5b1a2a] underline-offset-2 hover:underline">
                    {a.appellation_name}
                  </button>
                </span>
              ))}
              <span className="text-stone-300">›</span>
              <span className="font-semibold">{detail.appellation_name}</span>
            </div>
          </div>
          <dl className="grid grid-cols-3 gap-x-3 gap-y-1 text-xs">
            <dt className="text-stone-400">region</dt>
            <dd className="col-span-2 text-stone-700">{detail.region}</dd>
            <dt className="text-stone-400">sub_region</dt>
            <dd className="col-span-2 text-stone-700">{detail.sub_region ?? "—"}</dd>
            <dt className="text-stone-400">source</dt>
            <dd className="col-span-2 text-stone-700">{detail.source}</dd>
          </dl>
          {detail.alternate_names && (
            <div>
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-stone-400">Alternate names (OCR variants)</div>
              <div className="flex flex-wrap gap-1">
                {detail.alternate_names.split(", ").map((a) => (
                  <span key={a} className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-[11px] text-stone-700">
                    {a}
                  </span>
                ))}
              </div>
            </div>
          )}
          {detail.children.length > 0 && (
            <div>
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-stone-400">
                Contains ({detail.children.length})
              </div>
              <div className="flex max-h-56 flex-wrap gap-1 overflow-auto">
                {detail.children.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onSelect(c.id)}
                    className="rounded-full border border-stone-200 px-2 py-0.5 text-xs text-stone-700 hover:border-[#5b1a2a]/50 hover:text-[#5b1a2a]"
                  >
                    {c.appellation_name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </aside>
  );
}

function TreeView({ nodes, depth, onSelect }: { nodes: TreeNode[]; depth: number; onSelect: (id: number) => void }) {
  const [open, setOpen] = useState<Record<number, boolean>>({});
  return (
    <ul className={depth === 0 ? "space-y-1" : "ml-4 border-l border-stone-200 pl-3"}>
      {nodes.map((n) => {
        const has = n.children.length > 0;
        const isOpen = open[n.id] ?? depth < 1;
        return (
          <li key={n.id} className="py-0.5">
            <div className="flex items-center gap-1.5">
              {has ? (
                <button
                  onClick={() => setOpen((o) => ({ ...o, [n.id]: !isOpen }))}
                  className="grid h-5 w-5 place-items-center rounded text-stone-400 hover:bg-stone-100"
                  aria-label="toggle"
                >
                  <span className={`inline-block transition ${isOpen ? "rotate-90" : ""}`}>▸</span>
                </button>
              ) : (
                <span className="inline-block h-5 w-5 text-center text-stone-300">·</span>
              )}
              <button onClick={() => onSelect(n.id)} className="text-left text-sm text-stone-800 hover:text-[#5b1a2a] hover:underline">
                {n.appellation_name}
              </button>
              {n.classification_system && <Badge tone="wine">{n.classification_system}</Badge>}
              {has && <span className="text-[11px] text-stone-400">{n.children.length}</span>}
            </div>
            {has && isOpen && <TreeView nodes={n.children} depth={depth + 1} onSelect={onSelect} />}
          </li>
        );
      })}
    </ul>
  );
}

export default function GazetteerExplorer({ countries, classifications, continents }: ExplorerProps) {
  const [tab, setTab] = useState<TabId>("search");
  const [selected, setSelected] = useState<number | null>(null);

  // search state
  const [q, setQ] = useState("");
  const [country, setCountry] = useState("");
  const [classification, setClassification] = useState("");
  const [results, setResults] = useState<Row[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);

  // ocr state
  const [ocr, setOcr] = useState(SAMPLE_OCR);
  const [ocrMatches, setOcrMatches] = useState<Row[] | null>(null);
  const [ocrLoading, setOcrLoading] = useState(false);

  // browse state
  const [browseCountry, setBrowseCountry] = useState("France");
  const [tree, setTree] = useState<TreeNode[] | null>(null);

  // export state
  const [exportScope, setExportScope] = useState<string>("world");
  const [dialect, setDialect] = useState<"sqlite" | "postgres">("sqlite");

  const runSearch = useCallback(async () => {
    setLoading(true);
    const sp = new URLSearchParams();
    if (q.trim()) sp.set("q", q.trim());
    if (country) sp.set("country", country);
    if (classification) sp.set("classification", classification);
    sp.set("limit", "60");
    try {
      const r = await fetch(`/api/appellations?${sp}`);
      const d = await r.json();
      setResults(d.rows ?? []);
      setTotal(d.total ?? 0);
    } finally {
      setLoading(false);
    }
  }, [q, country, classification]);

  useEffect(() => {
    const t = setTimeout(runSearch, 250);
    return () => clearTimeout(t);
  }, [runSearch]);

  useEffect(() => {
    if (tab !== "browse") return;
    setTree(null);
    fetch(`/api/tree?country=${encodeURIComponent(browseCountry)}`)
      .then((r) => r.json())
      .then((d) => setTree(d.tree ?? []));
  }, [tab, browseCountry]);

  const runOcr = async () => {
    setOcrLoading(true);
    try {
      const r = await fetch("/api/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: ocr, limit: 20 }),
      });
      const d = await r.json();
      setOcrMatches(d.matches ?? []);
    } finally {
      setOcrLoading(false);
    }
  };

  const exportQuery = useMemo(() => {
    if (exportScope === "world") return "";
    if (exportScope.startsWith("continent:")) return `&continent=${encodeURIComponent(exportScope.slice(10))}`;
    return `&country=${encodeURIComponent(exportScope)}`;
  }, [exportScope]);

  const sortedCountries = useMemo(() => [...countries].sort((a, b) => a.country.localeCompare(b.country)), [countries]);

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div className="min-w-0">
        <div className="mb-4 flex flex-wrap gap-1 rounded-xl bg-stone-200/60 p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`rounded-lg px-3.5 py-1.5 text-sm font-medium transition ${
                tab === t.id ? "bg-white text-[#5b1a2a] shadow-sm" : "text-stone-600 hover:text-stone-900"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === "search" && (
          <section className="space-y-3">
            <div className="flex flex-col gap-2 sm:flex-row">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Try: chateauneuf, barosa valey, St Emilion, Rias Baixas, napa…"
                className="flex-1 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-[15px] shadow-sm outline-none focus:border-[#5b1a2a] focus:ring-2 focus:ring-[#5b1a2a]/20"
              />
              <select value={country} onChange={(e) => setCountry(e.target.value)} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
                <option value="">All countries</option>
                {sortedCountries.map((c) => (
                  <option key={c.country} value={c.country}>
                    {c.country} ({c.count})
                  </option>
                ))}
              </select>
              <select
                value={classification}
                onChange={(e) => setClassification(e.target.value)}
                className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm"
              >
                <option value="">All systems</option>
                {classifications.map((c) => (
                  <option key={c.classification} value={c.classification}>
                    {c.classification} ({c.count})
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>
                {loading ? "Searching…" : q ? `${results.length} matches (pg_trgm similarity + word_similarity)` : `${total.toLocaleString()} entries`}
              </span>
              <span className="font-mono">GET /api/appellations?q=…</span>
            </div>
            <div className="grid gap-2">
              {results.map((r) => (
                <ResultRow key={r.id} row={r} onSelect={setSelected} />
              ))}
              {!loading && results.length === 0 && <p className="rounded-xl border border-dashed border-stone-300 p-6 text-center text-sm text-stone-500">No matches.</p>}
            </div>
          </section>
        )}

        {tab === "ocr" && (
          <section className="space-y-3">
            <p className="text-sm text-stone-600">
              Paste raw OCR output from a wine label. Appellation names and their unaccented alternates are matched as whole words inside the
              text with <code className="rounded bg-stone-100 px-1 font-mono text-xs">strict_word_similarity</code>, so noisy OCR still resolves.
            </p>
            <textarea
              value={ocr}
              onChange={(e) => setOcr(e.target.value)}
              rows={5}
              className="w-full rounded-xl border border-stone-300 bg-white px-4 py-3 font-mono text-sm shadow-sm outline-none focus:border-[#5b1a2a] focus:ring-2 focus:ring-[#5b1a2a]/20"
            />
            <div className="flex items-center gap-3">
              <button
                onClick={runOcr}
                disabled={ocrLoading}
                className="rounded-xl bg-[#5b1a2a] px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-[#4a1322] disabled:opacity-60"
              >
                {ocrLoading ? "Matching…" : "Match appellations"}
              </button>
              <span className="font-mono text-xs text-stone-500">POST /api/match {"{ text }"}</span>
            </div>
            {ocrMatches && (
              <div className="grid gap-2">
                {ocrMatches.map((r) => (
                  <ResultRow key={r.id} row={r} onSelect={setSelected} />
                ))}
                {ocrMatches.length === 0 && <p className="rounded-xl border border-dashed border-stone-300 p-6 text-center text-sm text-stone-500">No appellation detected.</p>}
              </div>
            )}
          </section>
        )}

        {tab === "browse" && (
          <section className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <label className="text-sm text-stone-600">Country</label>
              <select value={browseCountry} onChange={(e) => setBrowseCountry(e.target.value)} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
                {sortedCountries.map((c) => (
                  <option key={c.country} value={c.country}>
                    {c.country} ({c.count})
                  </option>
                ))}
              </select>
              <span className="font-mono text-xs text-stone-500">GET /api/tree?country=…</span>
            </div>
            <div className="rounded-2xl border border-stone-200 bg-white p-4">
              {tree ? <TreeView nodes={tree} depth={0} onSelect={setSelected} /> : <p className="text-sm text-stone-500">Loading hierarchy…</p>}
            </div>
          </section>
        )}

        {tab === "export" && (
          <section className="space-y-5">
            <div className="rounded-2xl border border-stone-200 bg-white p-5">
              <h3 className="font-serif text-lg font-semibold text-[#5b1a2a]">Build a download</h3>
              <p className="mt-1 text-sm text-stone-600">
                Exports are generated live from PostgreSQL. The SQLite file contains the exact target schema (<code className="font-mono text-xs">appellations</code> +{" "}
                <code className="font-mono text-xs">appellations_fts</code> FTS5 with <code className="font-mono text-xs">tokenize=&apos;trigram&apos;</code>) plus an{" "}
                <code className="font-mono text-xs">appellation_meta</code> hierarchy table.
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <label className="text-sm text-stone-600">Scope</label>
                <select value={exportScope} onChange={(e) => setExportScope(e.target.value)} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
                  <option value="world">🌍 Whole world</option>
                  <optgroup label="By continent">
                    {continents.map((c) => (
                      <option key={c.continent} value={`continent:${c.continent}`}>
                        {c.continent} ({c.count})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="By country">
                    {sortedCountries.map((c) => (
                      <option key={c.country} value={c.country}>
                        {c.country} ({c.count})
                      </option>
                    ))}
                  </optgroup>
                </select>
                <label className="ml-2 text-sm text-stone-600">SQL dialect</label>
                <select value={dialect} onChange={(e) => setDialect(e.target.value as "sqlite" | "postgres")} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
                  <option value="sqlite">SQLite</option>
                  <option value="postgres">PostgreSQL</option>
                </select>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <a href={`/api/export?format=sqlite${exportQuery}`} className="rounded-xl bg-[#5b1a2a] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#4a1322]">
                  ⬇ SQLite database (.sqlite)
                </a>
                <a href={`/api/export?format=sql&dialect=${dialect}${exportQuery}`} className="rounded-xl border border-[#5b1a2a]/30 bg-white px-4 py-2 text-sm font-semibold text-[#5b1a2a] hover:bg-[#5b1a2a]/5">
                  ⬇ SQL batch script (.sql)
                </a>
                <a href={`/api/export?format=csv${exportQuery}`} className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50">
                  ⬇ CSV
                </a>
                <a href={`/api/export?format=json${exportQuery}`} className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50" target="_blank" rel="noreferrer">
                  JSON ↗
                </a>
              </div>
            </div>

            <div className="rounded-2xl border border-[#c98a3e]/40 bg-[#fdf8f1] p-5">
              <h3 className="font-serif text-lg font-semibold text-[#5b1a2a]">Pre-built static artefacts</h3>
              <p className="mt-1 text-sm text-stone-600">
                Generated by <code className="font-mono text-xs">npm run build:sqlite</code> from the curated data modules (no database required) and served from{" "}
                <code className="font-mono text-xs">public/downloads/</code>.
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-sm">
                <a className="rounded-lg border border-stone-300 bg-white px-3 py-1.5 hover:border-[#5b1a2a]/50" href="/downloads/wine_gazetteer.sqlite">wine_gazetteer.sqlite</a>
                <a className="rounded-lg border border-stone-300 bg-white px-3 py-1.5 hover:border-[#5b1a2a]/50" href="/downloads/wine_gazetteer.csv">wine_gazetteer.csv</a>
                <a className="rounded-lg border border-stone-300 bg-white px-3 py-1.5 hover:border-[#5b1a2a]/50" href="/downloads/sql/world.sql">sql/world.sql</a>
                {["europe", "north_america", "south_america", "oceania", "africa", "asia"].map((c) => (
                  <a key={c} className="rounded-lg border border-stone-300 bg-white px-3 py-1.5 hover:border-[#5b1a2a]/50" href={`/downloads/sql/${c}.sql`}>
                    sql/{c}.sql
                  </a>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-stone-200 bg-white p-5">
              <h3 className="font-serif text-lg font-semibold text-[#5b1a2a]">SQL batches by continent</h3>
              <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {continents.map((c) => (
                  <div key={c.continent} className="flex items-center justify-between rounded-xl border border-stone-200 px-3 py-2 text-sm">
                    <span>
                      {c.continent} <span className="text-stone-400">({c.count})</span>
                    </span>
                    <span className="flex gap-2 text-xs">
                      <a className="text-[#5b1a2a] hover:underline" href={`/api/export?format=sql&continent=${encodeURIComponent(c.continent)}`}>
                        .sql
                      </a>
                      <a className="text-[#5b1a2a] hover:underline" href={`/api/export?format=sqlite&continent=${encodeURIComponent(c.continent)}`}>
                        .sqlite
                      </a>
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-stone-200 bg-white p-5">
              <h3 className="font-serif text-lg font-semibold text-[#5b1a2a]">SQL batches by country</h3>
              <div className="mt-3 grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
                {sortedCountries.map((c) => (
                  <div key={c.country} className="flex items-center justify-between rounded-lg px-2 py-1 text-sm hover:bg-stone-50">
                    <span>
                      {c.country} <span className="text-stone-400">({c.count})</span>
                    </span>
                    <span className="flex gap-2 text-xs">
                      <a className="text-[#5b1a2a] hover:underline" href={`/api/export?format=sql&country=${encodeURIComponent(c.country)}`}>
                        .sql
                      </a>
                      <a className="text-[#5b1a2a] hover:underline" href={`/api/export?format=sqlite&country=${encodeURIComponent(c.country)}`}>
                        .sqlite
                      </a>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
      </div>

      <div className="min-w-0">
        {selected ? (
          <DetailPanel id={selected} onClose={() => setSelected(null)} onSelect={setSelected} />
        ) : (
          <aside className="sticky top-6 rounded-2xl border border-dashed border-stone-300 p-5 text-sm text-stone-500">
            <p className="font-serif text-base font-semibold text-stone-700">Record inspector</p>
            <p className="mt-1">Select any appellation to see its full parent chain (e.g. Pauillac → Médoc → Bordeaux → France), alternate OCR spellings, official code and children.</p>
            <div className="mt-4 space-y-2 font-mono text-[11px] text-stone-500">
              <div>GET /api/appellations?q=chablis</div>
              <div>GET /api/appellations/:id</div>
              <div>POST /api/match {"{ text }"}</div>
              <div>GET /api/tree?country=Italy</div>
              <div>GET /api/stats</div>
              <div>GET /api/export?format=sqlite|sql|csv|json</div>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
