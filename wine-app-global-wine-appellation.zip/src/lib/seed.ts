import { sql } from "drizzle-orm";
import { db } from "@/db";
import { appellations } from "@/db/schema";
import { getGazetteerRows } from "@/data";

/**
 * Self-provisioning seed: makes sure the table, pg_trgm extension and
 * trigram indexes exist, then loads the curated gazetteer if the table is
 * empty. Safe to call on every request (memoised per process).
 */
export async function ensureSchema() {
  await db.execute(sql`CREATE EXTENSION IF NOT EXISTS pg_trgm`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS appellations (
      id SERIAL PRIMARY KEY,
      country VARCHAR(100) NOT NULL,
      region VARCHAR(100) NOT NULL,
      sub_region VARCHAR(100),
      appellation_name VARCHAR(150) NOT NULL,
      classification_system VARCHAR(50),
      official_code VARCHAR(20),
      alternate_names TEXT,
      continent VARCHAR(40) NOT NULL,
      level VARCHAR(20) NOT NULL,
      parent_id INTEGER,
      source VARCHAR(60) NOT NULL,
      name_norm TEXT NOT NULL,
      alt_norm TEXT,
      search_text TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
  `);
  await db.execute(
    sql`CREATE UNIQUE INDEX IF NOT EXISTS appellations_natural_key ON appellations (country, region, appellation_name)`,
  );
  await db.execute(sql`CREATE INDEX IF NOT EXISTS appellations_country_idx ON appellations (country)`);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS appellations_region_idx ON appellations (country, region)`);
  await db.execute(
    sql`CREATE INDEX IF NOT EXISTS appellations_classification_idx ON appellations (classification_system)`,
  );
  await db.execute(sql`CREATE INDEX IF NOT EXISTS appellations_parent_idx ON appellations (parent_id)`);
  await db.execute(
    sql`CREATE INDEX IF NOT EXISTS appellations_name_trgm_idx ON appellations USING gin (name_norm gin_trgm_ops)`,
  );
  await db.execute(
    sql`CREATE INDEX IF NOT EXISTS appellations_search_trgm_idx ON appellations USING gin (search_text gin_trgm_ops)`,
  );
}

export async function loadRows(opts: { force?: boolean } = {}) {
  const rows = getGazetteerRows();
  if (opts.force) {
    await db.execute(sql`TRUNCATE TABLE appellations RESTART IDENTITY`);
  } else {
    const existing = await db.execute<{ count: string }>(sql`SELECT count(*)::text AS count FROM appellations`);
    const count = Number(existing.rows[0]?.count ?? 0);
    if (count >= rows.length) return { inserted: 0, total: count };
    await db.execute(sql`TRUNCATE TABLE appellations RESTART IDENTITY`);
  }

  const BATCH = 400;
  for (let i = 0; i < rows.length; i += BATCH) {
    const batch = rows.slice(i, i + BATCH).map((r) => ({
      id: r.id,
      country: r.country,
      region: r.region,
      subRegion: r.subRegion,
      appellationName: r.appellationName,
      classificationSystem: r.classificationSystem,
      officialCode: r.officialCode,
      alternateNames: r.alternateNames,
      continent: r.continent,
      level: r.level,
      parentId: r.parentId,
      source: r.source,
      nameNorm: r.nameNorm,
      altNorm: r.altNorm,
      searchText: r.searchText,
    }));
    await db.insert(appellations).values(batch);
  }
  await db.execute(
    sql`SELECT setval(pg_get_serial_sequence('appellations', 'id'), (SELECT max(id) FROM appellations))`,
  );
  return { inserted: rows.length, total: rows.length };
}

const g = globalThis as typeof globalThis & { __gazetteerSeedPromise?: Promise<void> };

export function ensureSeeded(): Promise<void> {
  if (!g.__gazetteerSeedPromise) {
    g.__gazetteerSeedPromise = (async () => {
      await ensureSchema();
      await loadRows();
    })().catch((err) => {
      g.__gazetteerSeedPromise = undefined;
      throw err;
    });
  }
  return g.__gazetteerSeedPromise;
}
