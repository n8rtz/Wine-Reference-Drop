import { sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { normalizeForSearch } from "@/lib/normalize";
import type { ExportRow } from "@/lib/sqlite-export";

export interface Filters {
  country?: string;
  continent?: string;
  region?: string;
  classification?: string;
  level?: string;
}

export interface AppellationDto extends ExportRow {
  continent: string;
  level: string;
  parent_id: number | null;
  source: string;
  score?: number;
  match_type?: string;
}

async function run<T>(query: SQL): Promise<{ rows: T[] }> {
  const res = await db.execute(query);
  return { rows: res.rows as unknown as T[] };
}

function whereClauses(f: Filters): SQL[] {
  const clauses: SQL[] = [];
  if (f.country) clauses.push(sql`country = ${f.country}`);
  if (f.continent) clauses.push(sql`continent = ${f.continent}`);
  if (f.region) clauses.push(sql`region = ${f.region}`);
  if (f.classification) clauses.push(sql`classification_system = ${f.classification}`);
  if (f.level) clauses.push(sql`level = ${f.level}`);
  return clauses;
}

function andAll(clauses: SQL[]): SQL {
  if (!clauses.length) return sql`TRUE`;
  return sql.join(clauses, sql` AND `);
}

const BASE_COLUMNS = sql`id, country, region, sub_region, appellation_name, classification_system, official_code, alternate_names, continent, level, parent_id, source`;

export async function fetchExportRows(f: Filters = {}): Promise<ExportRow[]> {
  const res = await run<ExportRow>(
    sql`SELECT ${BASE_COLUMNS} FROM appellations WHERE ${andAll(whereClauses(f))} ORDER BY id`,
  );
  return res.rows;
}

export async function listAppellations(f: Filters, limit: number, offset: number) {
  const where = andAll(whereClauses(f));
  const [rows, count] = await Promise.all([
    run<AppellationDto>(
      sql`SELECT ${BASE_COLUMNS} FROM appellations WHERE ${where} ORDER BY country, region, sub_region NULLS FIRST, appellation_name LIMIT ${limit} OFFSET ${offset}`,
    ),
    run<{ count: string }>(sql`SELECT count(*)::text AS count FROM appellations WHERE ${where}`),
  ]);
  return { rows: rows.rows, total: Number(count.rows[0]?.count ?? 0) };
}

/**
 * Fuzzy search: combines substring containment, pg_trgm similarity on the
 * name, and word_similarity against the enriched search text (name +
 * alternates + region + country) so misspelt / unaccented / OCR-damaged
 * queries still rank the right appellation first.
 */
export async function searchAppellations(query: string, f: Filters, limit: number, offset: number) {
  const qn = normalizeForSearch(query);
  if (!qn) return listAppellations(f, limit, offset);
  const where = andAll(whereClauses(f));
  const like = `%${qn}%`;
  const boundary = `\\m${qn}\\M`;
  const prefix = `${qn}%`;
  const scoreExpr = sql`GREATEST(
      CASE WHEN name_norm = ${qn} THEN 1.0 ELSE 0 END,
      CASE WHEN name_norm LIKE ${prefix} THEN 0.95 ELSE 0 END,
      CASE WHEN name_norm ~ ${boundary} THEN 0.9 ELSE 0 END,
      CASE WHEN name_norm LIKE ${like} THEN 0.8 ELSE 0 END,
      CASE WHEN alt_norm IS NOT NULL AND (',' || alt_norm || ',') LIKE ${`%,${qn},%`} THEN 0.97 ELSE 0 END,
      CASE WHEN search_text ~ ${boundary} THEN 0.7 ELSE 0 END,
      CASE WHEN search_text LIKE ${like} THEN 0.6 ELSE 0 END,
      similarity(name_norm, ${qn}),
      word_similarity(${qn}, search_text) * 0.85
    )`;
  const res = await run<AppellationDto>(sql`
    SELECT ${BASE_COLUMNS}, round((${scoreExpr})::numeric, 3)::float AS score
    FROM appellations
    WHERE ${where} AND (
      search_text LIKE ${like}
      OR similarity(name_norm, ${qn}) >= 0.3
      OR word_similarity(${qn}, search_text) >= 0.5
    )
    ORDER BY score DESC, length(name_norm) ASC, appellation_name ASC
    LIMIT ${limit} OFFSET ${offset}
  `);
  return { rows: res.rows, total: res.rows.length + offset };
}

/**
 * OCR label matching: given a blob of OCR text, find appellations whose
 * (normalised) name or alternates appear – exactly or approximately – as a
 * substring. Uses pg_trgm word_similarity(name, text) which measures how
 * well the name matches the *best* contiguous extent of the text.
 */
export async function matchOcrText(text: string, limit = 15, threshold = 0.7) {
  const tn = normalizeForSearch(text);
  if (tn.length < 3) return [];
  const res = await run<AppellationDto>(sql`
    WITH scored AS (
      SELECT ${BASE_COLUMNS},
        name_norm,
        GREATEST(
          strict_word_similarity(name_norm, ${tn}),
          COALESCE((SELECT max(strict_word_similarity(a, ${tn})) FROM unnest(string_to_array(alt_norm, ',')) AS a WHERE length(a) >= 4), 0)
        ) AS score,
        (${tn} ~ ('\\m' || name_norm || '\\M')
          OR EXISTS (SELECT 1 FROM unnest(string_to_array(alt_norm, ',')) AS a WHERE length(a) >= 4 AND ${tn} ~ ('\\m' || a || '\\M'))) AS exact_hit
      FROM appellations
      WHERE length(name_norm) >= 3
    )
    SELECT id, country, region, sub_region, appellation_name, classification_system, official_code, alternate_names,
           continent, level, parent_id, source,
           round(score::numeric, 3)::float AS score,
           CASE WHEN exact_hit THEN 'exact' ELSE 'fuzzy' END AS match_type
    FROM scored
    WHERE exact_hit OR score >= ${threshold}
    ORDER BY exact_hit DESC, score DESC, length(name_norm) DESC
    LIMIT ${limit}
  `);
  return res.rows;
}

export async function getAppellation(id: number) {
  const res = await run<AppellationDto>(sql`SELECT ${BASE_COLUMNS} FROM appellations WHERE id = ${id}`);
  const row = res.rows[0];
  if (!row) return null;
  const ancestors: AppellationDto[] = [];
  let cursor = row.parent_id;
  const seen = new Set<number>([row.id]);
  while (cursor && !seen.has(cursor)) {
    seen.add(cursor);
    const p = await run<AppellationDto>(sql`SELECT ${BASE_COLUMNS} FROM appellations WHERE id = ${cursor}`);
    const pr = p.rows[0];
    if (!pr) break;
    ancestors.unshift(pr);
    cursor = pr.parent_id;
  }
  const children = await run<AppellationDto>(
    sql`SELECT ${BASE_COLUMNS} FROM appellations WHERE parent_id = ${id} ORDER BY appellation_name`,
  );
  return { ...row, ancestors, children: children.rows };
}

export async function getStats() {
  const [total, byCountry, byClass, byContinent, byLevel] = await Promise.all([
    run<{ count: string }>(sql`SELECT count(*)::text AS count FROM appellations`),
    run<{ country: string; continent: string; count: string }>(
      sql`SELECT country, continent, count(*)::text AS count FROM appellations GROUP BY country, continent ORDER BY count(*) DESC`,
    ),
    run<{ classification_system: string; count: string }>(
      sql`SELECT COALESCE(classification_system, '—') AS classification_system, count(*)::text AS count FROM appellations GROUP BY 1 ORDER BY count(*) DESC`,
    ),
    run<{ continent: string; count: string }>(
      sql`SELECT continent, count(*)::text AS count FROM appellations GROUP BY continent ORDER BY count(*) DESC`,
    ),
    run<{ level: string; count: string }>(
      sql`SELECT level, count(*)::text AS count FROM appellations GROUP BY level ORDER BY count(*) DESC`,
    ),
  ]);
  return {
    total: Number(total.rows[0]?.count ?? 0),
    countries: byCountry.rows.map((r) => ({ ...r, count: Number(r.count) })),
    classifications: byClass.rows.map((r) => ({ classification: r.classification_system, count: Number(r.count) })),
    continents: byContinent.rows.map((r) => ({ ...r, count: Number(r.count) })),
    levels: byLevel.rows.map((r) => ({ ...r, count: Number(r.count) })),
  };
}

export interface TreeNode extends AppellationDto {
  children: TreeNode[];
}

export async function getTree(country: string): Promise<TreeNode[]> {
  const res = await run<AppellationDto>(
    sql`SELECT ${BASE_COLUMNS} FROM appellations WHERE country = ${country} ORDER BY appellation_name`,
  );
  const nodes = new Map<number, TreeNode>();
  for (const r of res.rows) nodes.set(r.id, { ...r, children: [] });
  const roots: TreeNode[] = [];
  for (const n of nodes.values()) {
    const parent = n.parent_id ? nodes.get(n.parent_id) : undefined;
    if (parent && parent !== n) parent.children.push(n);
    else roots.push(n);
  }
  const sortRec = (list: TreeNode[]) => {
    list.sort((a, b) => b.children.length - a.children.length || a.appellation_name.localeCompare(b.appellation_name));
    list.forEach((c) => sortRec(c.children));
  };
  sortRec(roots);
  return roots;
}
