/**
 * Text normalisation utilities shared by the seed pipeline, the search API
 * and the SQLite exporter.
 *
 * Goal: keep accented, legally-correct names in `appellation_name`
 * (Châteauneuf-du-Pape, Rías Baixas, Bärnkastel …) while populating
 * `alternate_names` with the unaccented / punctuation-free spellings that
 * OCR engines typically emit, so trigram matching stays robust.
 */

const SPECIAL_MAP: Record<string, string> = {
  ß: "ss",
  ø: "o",
  Ø: "O",
  æ: "ae",
  Æ: "AE",
  œ: "oe",
  Œ: "OE",
  đ: "d",
  Đ: "D",
  ł: "l",
  Ł: "L",
  ı: "i",
  ħ: "h",
  Ħ: "H",
  þ: "th",
  ð: "d",
  "’": "'",
  "‘": "'",
  "`": "'",
  "´": "'",
  "–": "-",
  "—": "-",
  "‐": "-",
};

/** Remove diacritics and fold special Latin letters to ASCII. */
export function stripDiacritics(input: string): string {
  let s = input.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  s = s.replace(/[ßøØæÆœŒđĐłŁıħĦþð’‘`´–—‐]/g, (ch) => SPECIAL_MAP[ch] ?? ch);
  return s.normalize("NFC");
}

/** Lower-case, unaccent, collapse punctuation to spaces – used for trigram columns. */
export function normalizeForSearch(input: string): string {
  return stripDiacritics(input)
    .toLowerCase()
    .replace(/['".]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

/** Title-ish comparison key used for de-duplication. */
export function dedupeKey(...parts: Array<string | null | undefined>): string {
  return parts.map((p) => normalizeForSearch(p ?? "")).join("|");
}

function uniqCaseInsensitive(values: string[], exclude: string): string[] {
  const seen = new Set<string>([exclude.toLowerCase()]);
  const out: string[] = [];
  for (const v of values) {
    const key = v.toLowerCase();
    if (!v.trim() || seen.has(key)) continue;
    seen.add(key);
    out.push(v.trim());
  }
  return out;
}

/**
 * Generate alternate spellings for a name:
 *  - unaccented form
 *  - hyphen → space form, apostrophe-less form
 *  - Saint/Sainte ↔ St/Ste, Mount ↔ Mt, Valle/Vallée variants
 *  - every manual alternate plus its unaccented form
 */
export function generateAlternates(name: string, manual: string[] = []): string[] {
  const variants: string[] = [];
  const push = (v: string) => {
    const t = v.replace(/\s+/g, " ").trim();
    if (t) variants.push(t);
  };

  const base = [name, ...manual];
  for (const b of base) {
    push(b);
    const un = stripDiacritics(b);
    push(un);

    const forms = new Set<string>([b, un]);
    for (const f of Array.from(forms)) {
      if (f.includes("-")) push(f.replace(/-/g, " "));
      if (/['’]/.test(f)) {
        push(f.replace(/['’]/g, ""));
        push(f.replace(/['’]/g, " "));
      }
      if (/\bSaint-/.test(f)) push(f.replace(/\bSaint-/g, "St-"));
      if (/\bSaint /.test(f)) push(f.replace(/\bSaint /g, "St. "));
      if (/\bSainte-/.test(f)) push(f.replace(/\bSainte-/g, "Ste-"));
      if (/\bSt\. /.test(f)) push(f.replace(/\bSt\. /g, "Saint "));
      if (/\bSt-/.test(f)) push(f.replace(/\bSt-/g, "Saint-"));
      if (/\bMount /.test(f)) push(f.replace(/\bMount /g, "Mt. "));
      if (/\bMt\. /.test(f)) push(f.replace(/\bMt\. /g, "Mount "));
      if (/\bSankt /.test(f)) push(f.replace(/\bSankt /g, "St. "));
      if (/\bSan /.test(f) && /\bSan [A-Z]/.test(f)) {
        /* keep as is */
      }
      // German umlaut transliteration (Bärnkastel → Baernkastel)
      if (/[äöüÄÖÜ]/.test(f)) {
        push(
          f
            .replace(/ä/g, "ae")
            .replace(/ö/g, "oe")
            .replace(/ü/g, "ue")
            .replace(/Ä/g, "Ae")
            .replace(/Ö/g, "Oe")
            .replace(/Ü/g, "Ue"),
        );
      }
    }
  }

  // second pass so transformed forms also get unaccented copies
  const expanded = variants.flatMap((v) => [v, stripDiacritics(v)]);
  return uniqCaseInsensitive(expanded, name);
}

/** Alternate names serialised the way the SQLite spec wants them (comma separated). */
export function serializeAlternates(alts: string[]): string | null {
  const cleaned = alts.map((a) => a.replace(/,/g, " ").replace(/\s+/g, " ").trim()).filter(Boolean);
  return cleaned.length ? cleaned.join(", ") : null;
}
