import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

/** Spec-shaped export row (mirrors the target SQLite schema + hierarchy meta). */
export interface ExportRow {
  id: number;
  country: string;
  region: string;
  sub_region: string | null;
  appellation_name: string;
  classification_system: string | null;
  official_code: string | null;
  alternate_names: string | null;
  continent?: string | null;
  level?: string | null;
  parent_id?: number | null;
  source?: string | null;
}

export const SQLITE_DDL = `
CREATE TABLE appellations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    country VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    sub_region VARCHAR(100),
    appellation_name VARCHAR(150) NOT NULL,
    classification_system VARCHAR(50), -- e.g., AOC, AVA, DOCG, DO, GI, WO, DAC, PDO
    official_code VARCHAR(20),
    alternate_names TEXT               -- Comma-separated alternative spellings / non-accented variants
);

CREATE VIRTUAL TABLE appellations_fts USING fts5(
    appellation_name,
    region,
    sub_region,
    country,
    alternate_names,
    tokenize='trigram'
);

-- Hierarchy / provenance side table (keeps the spec table untouched)
CREATE TABLE appellation_meta (
    appellation_id INTEGER PRIMARY KEY REFERENCES appellations(id),
    continent VARCHAR(40),
    level VARCHAR(20),          -- region | sub_region | appellation
    parent_id INTEGER REFERENCES appellations(id),
    source VARCHAR(80)
);

CREATE INDEX idx_appellations_country ON appellations(country);
CREATE INDEX idx_appellations_region ON appellations(country, region);
CREATE INDEX idx_appellations_name ON appellations(appellation_name);
CREATE INDEX idx_meta_parent ON appellation_meta(parent_id);
`;

// Minimal structural typing for node:sqlite so we don't depend on @types coverage.
interface SqliteStatement {
  run(...params: Array<string | number | null>): unknown;
  get(...params: Array<string | number | null>): unknown;
}
interface SqliteDatabase {
  exec(sql: string): void;
  prepare(sql: string): SqliteStatement;
  close(): void;
}
interface SqliteModule {
  DatabaseSync: new (path: string) => SqliteDatabase;
}

function loadSqlite(): SqliteModule {
  const getBuiltin = (process as unknown as { getBuiltinModule?: (id: string) => unknown }).getBuiltinModule;
  const mod = getBuiltin ? (getBuiltin("node:sqlite") as SqliteModule | undefined) : undefined;
  if (!mod) throw new Error("node:sqlite is not available in this Node.js runtime (requires Node >= 22.13)");
  return mod;
}

/** Build a complete SQLite database (spec schema + FTS5 trigram index) and return the file bytes. */
export function buildSqliteDatabase(rows: ExportRow[]): Buffer {
  const { DatabaseSync } = loadSqlite();
  const dir = mkdtempSync(join(tmpdir(), "wine-gazetteer-"));
  const file = join(dir, "wine_gazetteer.sqlite");
  const db = new DatabaseSync(file);
  try {
    db.exec("PRAGMA foreign_keys = OFF; PRAGMA journal_mode = MEMORY; PRAGMA synchronous = OFF;");
    db.exec(SQLITE_DDL);
    db.exec("BEGIN");
    const ins = db.prepare(
      `INSERT INTO appellations (id, country, region, sub_region, appellation_name, classification_system, official_code, alternate_names)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    );
    const meta = db.prepare(
      `INSERT INTO appellation_meta (appellation_id, continent, level, parent_id, source) VALUES (?, ?, ?, ?, ?)`,
    );
    for (const r of rows) {
      ins.run(
        r.id,
        r.country,
        r.region,
        r.sub_region,
        r.appellation_name,
        r.classification_system,
        r.official_code,
        r.alternate_names,
      );
    }
    for (const r of rows) {
      meta.run(r.id, r.continent ?? null, r.level ?? null, r.parent_id ?? null, r.source ?? null);
    }
    db.exec(
      `INSERT INTO appellations_fts (rowid, appellation_name, region, sub_region, country, alternate_names)
       SELECT id, appellation_name, region, sub_region, country, alternate_names FROM appellations`,
    );
    db.exec(
      `CREATE TABLE gazetteer_info (key TEXT PRIMARY KEY, value TEXT);
       INSERT INTO gazetteer_info VALUES ('generated_at', '${new Date().toISOString()}');
       INSERT INTO gazetteer_info VALUES ('row_count', '${rows.length}');
       INSERT INTO gazetteer_info VALUES ('fts', 'fts5 trigram');`,
    );
    db.exec("COMMIT");
    db.exec("VACUUM");
    db.close();
    return readFileSync(file);
  } finally {
    try {
      rmSync(dir, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }
}

function q(v: string | number | null | undefined): string {
  if (v === null || v === undefined) return "NULL";
  if (typeof v === "number") return String(v);
  return `'${v.replace(/'/g, "''")}'`;
}

/**
 * Generate an executable SQL batch (SQLite dialect, also valid for PostgreSQL
 * when `dialect === "postgres"`). Used for the per-country / per-continent
 * script downloads.
 */
export function buildSqlScript(
  rows: ExportRow[],
  opts: { title: string; includeSchema?: boolean; dialect?: "sqlite" | "postgres" } = { title: "Wine Gazetteer" },
): string {
  const dialect = opts.dialect ?? "sqlite";
  const lines: string[] = [];
  lines.push(`-- ${opts.title}`);
  lines.push(`-- Generated ${new Date().toISOString()} | ${rows.length} rows | dialect: ${dialect}`);
  lines.push(`-- Sources: eAmbrosia (EU), TTB 27 CFR Part 9, Wine Australia GI Register, IPONZ, SAWIS WO, INV, SAG, Wikidata`);
  lines.push("");
  if (opts.includeSchema !== false) {
    if (dialect === "sqlite") {
      lines.push(SQLITE_DDL.trim());
    } else {
      lines.push(`CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE TABLE IF NOT EXISTS appellations (
    id INTEGER PRIMARY KEY,
    country VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    sub_region VARCHAR(100),
    appellation_name VARCHAR(150) NOT NULL,
    classification_system VARCHAR(50),
    official_code VARCHAR(20),
    alternate_names TEXT
);
CREATE TABLE IF NOT EXISTS appellation_meta (
    appellation_id INTEGER PRIMARY KEY REFERENCES appellations(id),
    continent VARCHAR(40), level VARCHAR(20), parent_id INTEGER, source VARCHAR(80)
);
CREATE INDEX IF NOT EXISTS idx_appellations_name_trgm ON appellations USING gin (appellation_name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_appellations_alt_trgm ON appellations USING gin (alternate_names gin_trgm_ops);`);
    }
    lines.push("");
  }
  lines.push("BEGIN;");
  const BATCH = 200;
  for (let i = 0; i < rows.length; i += BATCH) {
    const chunk = rows.slice(i, i + BATCH);
    lines.push(
      "INSERT INTO appellations (id, country, region, sub_region, appellation_name, classification_system, official_code, alternate_names) VALUES",
    );
    lines.push(
      chunk
        .map(
          (r) =>
            `  (${r.id}, ${q(r.country)}, ${q(r.region)}, ${q(r.sub_region)}, ${q(r.appellation_name)}, ${q(r.classification_system)}, ${q(r.official_code)}, ${q(r.alternate_names)})`,
        )
        .join(",\n") + ";",
    );
  }
  for (let i = 0; i < rows.length; i += BATCH) {
    const chunk = rows.slice(i, i + BATCH);
    lines.push("INSERT INTO appellation_meta (appellation_id, continent, level, parent_id, source) VALUES");
    lines.push(
      chunk
        .map((r) => `  (${r.id}, ${q(r.continent)}, ${q(r.level)}, ${q(r.parent_id)}, ${q(r.source)})`)
        .join(",\n") + ";",
    );
  }
  if (dialect === "sqlite") {
    lines.push(
      "INSERT INTO appellations_fts (rowid, appellation_name, region, sub_region, country, alternate_names) SELECT id, appellation_name, region, sub_region, country, alternate_names FROM appellations;",
    );
  }
  lines.push("COMMIT;");
  lines.push("");
  return lines.join("\n");
}

export function buildCsv(rows: ExportRow[]): string {
  const cols = [
    "id",
    "country",
    "region",
    "sub_region",
    "appellation_name",
    "classification_system",
    "official_code",
    "alternate_names",
    "continent",
    "level",
    "parent_id",
    "source",
  ] as const;
  const esc = (v: unknown) => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n") + "\n";
}

export function slugify(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}
