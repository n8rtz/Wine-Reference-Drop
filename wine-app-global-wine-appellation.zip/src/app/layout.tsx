import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Wine Gazetteer — Global Appellation & GI Database",
  description:
    "Every legally defined wine appellation, region, sub-region and geographical indication in the world, with trigram-indexed fuzzy / OCR matching and SQLite (FTS5) exports.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#f7f3ee] text-stone-900 antialiased">{children}</body>
    </html>
  );
}
