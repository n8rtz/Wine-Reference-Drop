import GazetteerExplorer from "@/components/GazetteerExplorer";
import { COUNTRY_SOURCES } from "@/data";
import { getStats } from "@/lib/queries";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

const REGISTRIES = [
  { name: "EU eAmbrosia", scope: "PDO / PGI — France (AOC), Italy (DOC/DOCG/IGT), Spain (DO/DOCa/VP), Germany, Portugal, Austria (DAC), Greece, Hungary …", script: "pipeline/fetch_eambrosia.py" },
  { name: "US TTB · 27 CFR Part 9", scope: "Every established American Viticultural Area (AVA) via the eCFR API", script: "pipeline/fetch_ttb_avas.py" },
  { name: "Wine Australia GI Register", scope: "Zones, regions and sub-regions", script: "pipeline/fetch_oceania.py" },
  { name: "IPONZ GI Register", scope: "Registered New Zealand geographical indications", script: "pipeline/fetch_oceania.py" },
  { name: "SAWIS Wine of Origin", scope: "Geographical units, regions, districts and wards", script: "pipeline/fetch_south_africa.py" },
  { name: "INV Argentina · SAG Chile", scope: "IG / DOC register and DO zonificación decrees", script: "pipeline/fetch_south_america.py" },
  { name: "Wikidata SPARQL · Liv-ex LWIN", scope: "Fallback enrichment (wine region Q1341100 / appellation Q12857018)", script: "pipeline/fetch_wikidata.py" },
];

export default async function HomePage() {
  await ensureSeeded();
  const stats = await getStats();
  const topClasses = stats.classifications.slice(0, 14);

  return (
    <main className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
      <header className="relative overflow-hidden rounded-3xl bg-[#3b0f1c] px-7 py-9 text-white shadow-[0_24px_60px_rgba(59,15,28,0.35)] sm:px-10">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-[#8c2d45]/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-[#c98a3e]/20 blur-3xl" />
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#e8c9a0]">Wine Gazetteer · global appellation registry</p>
        <h1 className="mt-3 font-serif text-[clamp(2rem,4.5vw,3.4rem)] font-semibold leading-[1.05]">
          Every appellation, region &amp; GI — <span className="text-[#e8c9a0]">trigram-indexed</span> for OCR matching.
        </h1>
        <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-stone-200">
          A production gazetteer compiled from the primary legal registries (eAmbrosia, TTB, Wine Australia, IPONZ, SAWIS, INV, SAG) with
          accent-preserving names, unaccented alternates, explicit parent hierarchy, pg_trgm fuzzy search in PostgreSQL and one-click SQLite
          (FTS5 <code className="rounded bg-white/10 px-1 font-mono text-[13px]">tokenize=&apos;trigram&apos;</code>) exports.
        </p>
        <dl className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { k: "Entries", v: stats.total.toLocaleString() },
            { k: "Countries", v: String(stats.countries.length) },
            { k: "Classification systems", v: String(stats.classifications.length) },
            { k: "Continents", v: String(stats.continents.length) },
          ].map((s) => (
            <div key={s.k} className="rounded-2xl bg-white/10 px-4 py-3 ring-1 ring-white/15 backdrop-blur">
              <dt className="text-[11px] uppercase tracking-wider text-stone-300">{s.k}</dt>
              <dd className="mt-0.5 font-serif text-2xl font-semibold">{s.v}</dd>
            </div>
          ))}
        </dl>
      </header>

      <section className="mt-6 flex flex-wrap gap-1.5">
        {topClasses.map((c) => (
          <span key={c.classification} className="rounded-full border border-stone-300 bg-white px-2.5 py-1 text-xs text-stone-700">
            <span className="font-semibold text-[#5b1a2a]">{c.classification}</span> <span className="text-stone-400">{c.count}</span>
          </span>
        ))}
      </section>

      <section className="mt-6">
        <GazetteerExplorer countries={stats.countries} classifications={stats.classifications} continents={stats.continents} />
      </section>

      <section className="mt-12 grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-stone-200 bg-white p-6">
          <h2 className="font-serif text-xl font-semibold text-[#5b1a2a]">Primary registries &amp; acquisition scripts</h2>
          <p className="mt-1 text-sm text-stone-600">
            The <code className="font-mono text-xs">pipeline/</code> folder ships executable Python fetchers for each registry plus{" "}
            <code className="font-mono text-xs">build_sqlite.py</code>, which merges fetched records with this curated seed into the FTS5 database.
          </p>
          <ul className="mt-4 divide-y divide-stone-100">
            {REGISTRIES.map((r) => (
              <li key={r.name} className="flex flex-col gap-0.5 py-2.5 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold text-stone-800">{r.name}</span>
                  <code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-[11px] text-stone-600">{r.script}</code>
                </div>
                <span className="text-xs text-stone-500">{r.scope}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-stone-200 bg-white p-6">
          <h2 className="font-serif text-xl font-semibold text-[#5b1a2a]">Coverage by country</h2>
          <div className="mt-4 grid max-h-[460px] grid-cols-1 gap-x-6 gap-y-1 overflow-auto pr-1 text-sm sm:grid-cols-2">
            {stats.countries.map((c) => {
              const src = COUNTRY_SOURCES.find((s) => s.country === c.country)?.source ?? "";
              return (
                <div key={c.country} className="flex items-baseline justify-between gap-2 border-b border-dotted border-stone-200 py-1">
                  <span className="min-w-0">
                    <span className="font-medium text-stone-800">{c.country}</span>
                    <span className="ml-1.5 truncate text-[11px] text-stone-400">{src}</span>
                  </span>
                  <span className="font-mono text-xs text-stone-500">{c.count}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-stone-200 bg-white p-6">
        <h2 className="font-serif text-xl font-semibold text-[#5b1a2a]">Target SQLite schema (as exported)</h2>
        <pre className="mt-3 overflow-auto rounded-xl bg-stone-900 p-4 text-[12px] leading-relaxed text-stone-100">
{`CREATE TABLE appellations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    country VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    sub_region VARCHAR(100),
    appellation_name VARCHAR(150) NOT NULL,
    classification_system VARCHAR(50), -- AOC, AVA, DOCG, DO, GI, WO, DAC, PDO …
    official_code VARCHAR(20),
    alternate_names TEXT               -- comma-separated unaccented / alternate spellings
);

CREATE VIRTUAL TABLE appellations_fts USING fts5(
    appellation_name, region, sub_region, country, alternate_names,
    tokenize='trigram'
);

-- SELECT a.* FROM appellations_fts f JOIN appellations a ON a.id = f.rowid
--  WHERE appellations_fts MATCH 'neuf du pape';`}
        </pre>
      </section>

      <footer className="mt-10 pb-6 text-center text-xs text-stone-400">
        Names preserve official diacritics; alternates carry ASCII folds, hyphen/space and Saint↔St variants for robust trigram matching.
      </footer>
    </main>
  );
}
