import { NextRequest } from "next/server";
import { ensureSeeded } from "@/lib/seed";
import { matchOcrText } from "@/lib/queries";

export const dynamic = "force-dynamic";

async function handle(text: string, limit: number, threshold: number) {
  await ensureSeeded();
  const matches = await matchOcrText(text, limit, threshold);
  return Response.json({ text, threshold, matches });
}

/** GET /api/match?text=<ocr string> */
export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const text = (sp.get("text") || "").slice(0, 4000);
    if (!text.trim()) return Response.json({ error: "text is required" }, { status: 400 });
    return await handle(text, Number(sp.get("limit") || 15), Number(sp.get("threshold") || 0.7));
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}

/** POST /api/match  { "text": "<ocr string>", "limit": 15, "threshold": 0.62 } */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as { text?: string; limit?: number; threshold?: number };
    const text = (body.text || "").slice(0, 4000);
    if (!text.trim()) return Response.json({ error: "text is required" }, { status: 400 });
    return await handle(text, Number(body.limit || 15), Number(body.threshold || 0.7));
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}
