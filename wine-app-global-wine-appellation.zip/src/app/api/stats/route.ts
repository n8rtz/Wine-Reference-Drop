import { ensureSeeded } from "@/lib/seed";
import { getStats } from "@/lib/queries";
import { COUNTRY_SOURCES } from "@/data";

export const dynamic = "force-dynamic";

/** GET /api/stats → totals by country / classification / continent + registry provenance */
export async function GET() {
  try {
    await ensureSeeded();
    const stats = await getStats();
    return Response.json({ ...stats, sources: COUNTRY_SOURCES });
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}
