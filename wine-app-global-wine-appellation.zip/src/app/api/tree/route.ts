import { NextRequest } from "next/server";
import { ensureSeeded } from "@/lib/seed";
import { getTree } from "@/lib/queries";

export const dynamic = "force-dynamic";

/** GET /api/tree?country=France → nested hierarchy (region → sub-region → appellation) */
export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    const country = req.nextUrl.searchParams.get("country");
    if (!country) return Response.json({ error: "country is required" }, { status: 400 });
    const tree = await getTree(country);
    return Response.json({ country, tree });
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}
