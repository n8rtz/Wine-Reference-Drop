import { NextRequest } from "next/server";
import { ensureSeeded } from "@/lib/seed";
import { fetchExportRows } from "@/lib/queries";
import { buildCsv, buildSqlScript, buildSqliteDatabase, slugify } from "@/lib/sqlite-export";

export const dynamic = "force-dynamic";

/**
 * GET /api/export?format=sqlite|sql|csv|json[&country=France|&continent=Europe][&dialect=sqlite|postgres]
 *
 *  - sqlite : complete .sqlite file with the spec schema + FTS5 trigram index
 *  - sql    : executable INSERT batch script (per country / continent / whole world)
 *  - csv / json : flat exports for the Python pipeline or spreadsheets
 */
export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    const sp = req.nextUrl.searchParams;
    const format = (sp.get("format") || "sqlite").toLowerCase();
    const country = sp.get("country") || undefined;
    const continent = sp.get("continent") || undefined;
    const dialect = sp.get("dialect") === "postgres" ? "postgres" : "sqlite";
    const rows = await fetchExportRows({ country, continent });
    const scope = country ? slugify(country) : continent ? slugify(continent) : "world";
    const title = `Wine Gazetteer — ${country ?? continent ?? "World"}`;
    const stamp = new Date().toISOString().slice(0, 10);

    if (format === "sqlite" || format === "db") {
      const bytes = buildSqliteDatabase(rows);
      return new Response(new Uint8Array(bytes), {
        headers: {
          "Content-Type": "application/vnd.sqlite3",
          "Content-Disposition": `attachment; filename="wine_gazetteer_${scope}_${stamp}.sqlite"`,
          "Content-Length": String(bytes.length),
          "Cache-Control": "no-store",
        },
      });
    }
    if (format === "sql") {
      const script = buildSqlScript(rows, { title, dialect });
      return new Response(script, {
        headers: {
          "Content-Type": "application/sql; charset=utf-8",
          "Content-Disposition": `attachment; filename="wine_gazetteer_${scope}_${dialect}.sql"`,
          "Cache-Control": "no-store",
        },
      });
    }
    if (format === "csv") {
      return new Response(buildCsv(rows), {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="wine_gazetteer_${scope}.csv"`,
          "Cache-Control": "no-store",
        },
      });
    }
    if (format === "json") {
      return Response.json({ generated_at: new Date().toISOString(), count: rows.length, rows });
    }
    return Response.json({ error: "unknown format; use sqlite | sql | csv | json" }, { status: 400 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}
