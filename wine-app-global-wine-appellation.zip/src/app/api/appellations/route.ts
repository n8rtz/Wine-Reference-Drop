import { NextRequest } from "next/server";
import { ensureSeeded } from "@/lib/seed";
import { listAppellations, searchAppellations, type Filters } from "@/lib/queries";

export const dynamic = "force-dynamic";

function filtersFrom(sp: URLSearchParams): Filters {
  return {
    country: sp.get("country") || undefined,
    continent: sp.get("continent") || undefined,
    region: sp.get("region") || undefined,
    classification: sp.get("classification") || undefined,
    level: sp.get("level") || undefined,
  };
}

/**
 * GET /api/appellations?q=chateauneuf&country=France&classification=AOC&limit=50&offset=0
 * Fuzzy (pg_trgm) search when `q` is present, otherwise a filtered listing.
 */
export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    const sp = req.nextUrl.searchParams;
    const q = (sp.get("q") || "").trim();
    const limit = Math.min(Math.max(Number(sp.get("limit") || 50), 1), 500);
    const offset = Math.max(Number(sp.get("offset") || 0), 0);
    const filters = filtersFrom(sp);
    const result = q
      ? await searchAppellations(q, filters, limit, offset)
      : await listAppellations(filters, limit, offset);
    return Response.json({ query: q, filters, limit, offset, ...result });
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}
