import { NextRequest } from "next/server";
import { ensureSeeded } from "@/lib/seed";
import { getAppellation } from "@/lib/queries";

export const dynamic = "force-dynamic";

/** GET /api/appellations/:id → record + ancestor chain + direct children */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeeded();
    const { id } = await ctx.params;
    const numeric = Number(id);
    if (!Number.isInteger(numeric) || numeric <= 0) {
      return Response.json({ error: "invalid id" }, { status: 400 });
    }
    const row = await getAppellation(numeric);
    if (!row) return Response.json({ error: "not found" }, { status: 404 });
    return Response.json(row);
  } catch (err) {
    console.error(err);
    return Response.json({ error: (err as Error).message }, { status: 500 });
  }
}
