import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * PostgreSQL mirror of the Wine Gazetteer.
 *
 * The first eight columns are a 1:1 mirror of the target SQLite schema
 * (`appellations`). The remaining columns are enrichment fields used for
 * hierarchy navigation and pg_trgm fuzzy / OCR matching. The SQLite export
 * only emits the spec columns (+ an `appellation_meta` side table).
 */
export const appellations = pgTable(
  "appellations",
  {
    id: serial("id").primaryKey(),
    country: varchar("country", { length: 100 }).notNull(),
    region: varchar("region", { length: 100 }).notNull(),
    subRegion: varchar("sub_region", { length: 100 }),
    appellationName: varchar("appellation_name", { length: 150 }).notNull(),
    classificationSystem: varchar("classification_system", { length: 50 }),
    officialCode: varchar("official_code", { length: 20 }),
    alternateNames: text("alternate_names"),

    // --- enrichment (not part of the SQLite spec table) ---
    continent: varchar("continent", { length: 40 }).notNull(),
    level: varchar("level", { length: 20 }).notNull(), // region | sub_region | appellation
    parentId: integer("parent_id"),
    source: varchar("source", { length: 60 }).notNull(),
    nameNorm: text("name_norm").notNull(), // lower-cased, unaccented appellation_name
    altNorm: text("alt_norm"), // lower-cased, unaccented alternates, comma separated
    searchText: text("search_text").notNull(), // name + alternates + region + sub_region + country (normalised)
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("appellations_natural_key").on(t.country, t.region, t.appellationName),
    index("appellations_country_idx").on(t.country),
    index("appellations_region_idx").on(t.country, t.region),
    index("appellations_classification_idx").on(t.classificationSystem),
    index("appellations_parent_idx").on(t.parentId),
  ],
);

export type Appellation = typeof appellations.$inferSelect;
export type NewAppellation = typeof appellations.$inferInsert;
