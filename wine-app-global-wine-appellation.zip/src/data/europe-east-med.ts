import { defineCountry } from "./parse";

export const GREECE = defineCountry(
  "Greece",
  "PDO",
  "eAmbrosia (EU) / Greek Ministry of Rural Development",
  `
@ Macedonia | PDO
Macedonia | PGI | | Makedonia; Macedonian
Naoussa | PDO | | Naousa; Νάουσα
Amyndeon | PDO | | Amynteo; Amyntaio; Amyndaio
Goumenissa | PDO
Slopes of Meliton | PDO | | Plagies Melitona; Côtes de Meliton
Drama | PGI
Epanomi | PGI
Florina | PGI
Halkidiki | PGI | | Chalkidiki
Kavala | PGI
Pangeon | PGI | | Pangaion; Mount Pangeon
Imathia | PGI
Pella | PGI
Pieria | PGI
Serres | PGI
Kilkis | PGI
Grevena | PGI
Kozani | PGI
Siatista | PGI
Velvento | PGI
Kastoria | PGI
Thessaloniki | PGI
@ Thrace | PGI
Thrace | PGI | | Thraki
Avdira | PGI
Ismaros | PGI
Evros | PGI
@ Epirus | PGI
Epirus | PGI | | Ipiros
Zitsa | PDO
Metsovo | PGI
Ioannina | PGI
@ Thessaly | PGI
Thessaly | PGI | | Thessalia
Rapsani | PDO
Anchialos | PDO | | Nea Anchialos
Messenikola | PDO
Tyrnavos | PGI
Karditsa | PGI
Krania | PGI
Magnesia | PGI
Larissa | PGI
Meteora | PGI
@ Central Greece | PGI
Central Greece | PGI | | Sterea Ellada
Attiki | PGI | | Attica
Markopoulo | PGI
Pallini | PGI
Koropi | PGI
Evia | PGI | | Euboea
Ritsona | PGI
Thiva | PGI | | Thebes
Fthiotida | PGI
Evritania | PGI
Opountia Lokris | PGI
Atalanti Valley | PGI | | Koilada Atalantis
@ Peloponnese | PGI
Peloponnese | PGI | | Peloponnisos
Nemea | PDO | | Nemean
Mantinia | PDO | | Mantineia
Patras | PDO | | Patra
Muscat of Patras | PDO | | Moschatos Patron
Muscat of Rio Patras | PDO | | Moschatos Riou Patron
Mavrodaphne of Patras | PDO | | Mavrodafni Patron; Mavrodaphne Patras
Monemvasia-Malvasia | PDO | | Monemvasia Malvasia; Μονεμβασία-Malvasia
Achaia | PGI | | Achaea
Corinth | PGI | | Korinthos
Arcadia | PGI | | Arkadia
Tegea | PGI
Lakonia | PGI | | Laconia
Monemvasia | PGI
Ilia | PGI | | Elis
Letrina | PGI
Pisatis | PGI
Messinia | PGI | | Messenia
Trifilia | PGI
Pylia | PGI
Klimenti | PGI
Aigialeia | PGI | | Slopes of Aigialeia
Argolida | PGI
@ Ionian Islands | PGI
Ionian Islands | PGI | | Ionia Nisia
Robola of Kefalonia | PDO | | Kefalonia Robola; Robola Kefallinias
Muscat of Kefalonia | PDO | | Moschatos Kefallinias
Mavrodaphne of Kefalonia | PDO | | Mavrodafni Kefallinias
Kefalonia | PGI | | Cephalonia; Kefallinia
Zakynthos | PGI | | Zante
Lefkada | PGI | | Lefkas
Kerkyra | PGI | | Corfu
@ Aegean Islands | PGI
Aegean Sea | PGI | | Aigaio Pelagos
Santorini | PDO | | Santorin; Thira
Samos | PDO | | Muscat of Samos; Moschatos Samou
Lemnos | PDO | | Limnos
Muscat of Lemnos | PDO | | Moschatos Limnou
Paros | PDO
Malvasia Paros | PDO
Muscat of Rhodes | PDO | | Moschatos Rodou
Rhodes | PDO | | Rodos
Cyclades | PGI | | Kyklades
Lesvos | PGI | | Lesbos; Mytilene
Chios | PGI
Ikaria | PGI
Kos | PGI
Dodecanese | PGI | | Dodekanisos
Tinos | PGI
Mykonos | PGI
Naxos | PGI
Sifnos | PGI
@ Crete | PGI
Crete | PGI | | Kriti
Archanes | PDO | | Arhanes
Dafnes | PDO
Peza | PDO
Sitia | PDO
Candia | PDO | | Chandakas-Candia; Malvasia Chandakas-Candia; Malvasia Candia
Malvasia Sitia | PDO
Heraklion | PGI | | Iraklio
Lasithi | PGI
Chania | PGI
Rethymno | PGI
Kissamos | PGI
`,
);

export const ROMANIA = defineCountry(
  "Romania",
  "DOC",
  "eAmbrosia (EU) / ONVPV",
  `
@ Moldova (Romania) | DOC
Dealurile Moldovei | PGI | | Moldavian Hills
Cotnari | DOC
Iași | DOC | | Iasi
Huși | DOC | | Husi
Bohotin | DOC
Odobești | DOC | | Odobesti
Panciu | DOC
Cotești | DOC | | Cotesti
Dealurile Vrancei | PGI
Nicorești | DOC | | Nicoresti
Iana | DOC
Dealu Bujorului | DOC
Dealurile Vasluiului | PGI
@ Muntenia | DOC
Dealurile Munteniei | PGI
Dealu Mare | DOC
Pietroasa | DOC | | Pietroasele
Ștefănești | DOC | | Stefanesti; Ștefănești-Argeș
Sâmburești | DOC | | Samburesti
Drăgășani | DOC | | Dragasani
Dealurile Olteniei | PGI
Segarcea | DOC
Banu Mărăcine | DOC | | Banu Maracine
Mehedinți | DOC | | Mehedinti
Oltenia | PGI
Terasele Dunării | PGI | | Terasele Dunarii
@ Dobrogea | DOC
Colinele Dobrogei | PGI
Murfatlar | DOC
Sarica Niculițel | DOC | | Sarica Niculitel
Babadag | DOC
Oltina | DOC
Adamclisi | DOC
Însurăței | DOC | | Insuratei
@ Transilvania | DOC
Dealurile Transilvaniei | PGI
Târnave | DOC | | Tarnave
Jidvei | Sub-region
Alba Iulia | DOC
Aiud | DOC
Lechința | DOC | | Lechinta
Sebeș-Apold | DOC | | Sebes-Apold
@ Banat & Crișana | DOC
Recaș | DOC | | Recas
Banat | DOC
Viile Timișului | PGI | | Viile Timisului
Viile Carașului | PGI | | Viile Carasului
Miniș | DOC | | Minis
Crișana | DOC | | Crisana
Dealurile Crișanei | PGI
Dealurile Zarandului | PGI
Dealurile Sătmarului | PGI | | Dealurile Satmarului
`,
);

export const BULGARIA = defineCountry(
  "Bulgaria",
  "PDO",
  "eAmbrosia (EU) / EAVW",
  `
@ Thracian Lowlands | PGI
Thracian Lowlands | PGI | | Trakiyska nizina; Thracian Valley; Тракийска низина
Asenovgrad | PDO
Brestnik | PDO
Plovdiv | PDO
Pazardjik | PDO | | Pazardzhik
Perushtitsa | PDO
Septemvri | PDO
Karlovo | PDO
Hisarya | PDO | | Hisar
Stara Zagora | PDO
Nova Zagora | PDO
Sliven | PDO
Shivachevo | PDO
Yambol | PDO
Elenovo | PDO
Haskovo | PDO
Stambolovo | PDO
Ivaylovgrad | PDO
Sakar | PDO
Lyubimets | PDO
Strandja | PDO | | Strandzha
Bolyarovo | PDO
Sungurlare | PDO
Karnobat | PDO
Slavyantsi | PDO
Pomorie | PDO
Varna | PDO | | Evksinograd
Melnik | PDO | | Harsovo; Struma Valley
Sandanski | PDO
Petrich | PDO
@ Danubian Plain | PGI
Danubian Plain | PGI | | Dunavska ravnina; Дунавска равнина
Pleven | PDO
Suhindol | PDO
Lozitsa | PDO
Pavlikeni | PDO
Lyaskovets | PDO
Svishtov | PDO
Rousse | PDO | | Ruse
Cherven | PDO
Novo Selo | PDO
Vidin | PDO
Lom | PDO
Vratsa | PDO
Montana | PDO | | Cherna Gora
Oryahovitsa | PDO
Shumen | PDO
Khan Krum | PDO | | Han Krum
Novi Pazar | PDO
Targovishte | PDO
Dragoevo | PDO
Nikopol | PDO
Lovech | PDO
`,
);

export const CYPRUS = defineCountry(
  "Cyprus",
  "PDO",
  "eAmbrosia (EU)",
  `
@ Cyprus | PDO
Commandaria | PDO | | Koumandaria; Κουμανδαρία
Krasochoria Lemesou | PDO | | Krasohoria Lemesou; Wine Villages of Limassol
Krasochoria Lemesou-Afames | PDO | | Afames
Krasochoria Lemesou-Laona | PDO | | Laona Lemesou
Laona Akama | PDO | | Laona Akamas
Pitsilia | PDO
Vouni Panagias-Ambelitis | PDO | | Vouni Panayias-Ambelitis
Lemesos | PGI | | Limassol
Pafos | PGI | | Paphos
Larnaka | PGI | | Larnaca
Lefkosia | PGI | | Nicosia
`,
);

export const MALTA = defineCountry(
  "Malta",
  "DOK",
  "eAmbrosia (EU)",
  `
@ Malta | DOK
Malta | DOK | | Malta DOK; Denominazzjoni ta' Origini Kontrollata Malta
Gozo | DOK | | Għawdex; Ghawdex; Gozo DOK
Maltese Islands | IĠT | | Gżejjer Maltin; Gzejjer Maltin; IGT Maltese Islands
`,
);

export const UNITED_KINGDOM = defineCountry(
  "United Kingdom",
  "PDO",
  "UK GI Schemes (DEFRA)",
  `
@ England | PDO
English Wine | PDO | | English Quality Sparkling Wine; English Quality Wine
English Regional Wine | PGI | | English Regional
Sussex | PDO | | Sussex Wine
Darnibole | PDO | | Darnibole Vineyard
Kent | Sub-region
Hampshire | Sub-region
Essex | Sub-region | | Crouch Valley
Surrey | Sub-region
Cornwall | Sub-region
@ Wales | PDO
Welsh Wine | PDO | | Welsh Quality Wine; Gwin Cymru
Welsh Regional Wine | PGI
`,
);

export const GEORGIA = defineCountry(
  "Georgia",
  "PDO",
  "Sakpatenti GI Register / eAmbrosia",
  `
@ Kakheti | PDO
Kakheti | PDO | | Kakhuri; Kakhetian; კახეთი
Tsinandali | PDO | | წინანდალი
Mukuzani | PDO
Napareuli | PDO
Kindzmarauli | PDO | | Kindzmarauli
Akhasheni | PDO
Gurjaani | PDO
Vazisubani | PDO
Manavi | PDO | | Manavis Mtsvane
Kardenakhi | PDO | | Kardanakhi
Tibaani | PDO
Kotekhi | PDO
Kvareli | PDO
Teliani | PDO
Khashmi | PDO | | Khashmi Saperavi
Akhmeta | PDO
Kakhuri Mtsvivani | PDO
Kakhuri Mtsvane | Sub-region
Alazani Valley | Sub-region | | Alazanis Veli
Tsarapi | PDO
Kondoli | PDO
@ Kartli | PDO
Kartli | PDO | | Kartuli
Ateni | PDO | | Atenuri
Bolnisi | PDO
Gori | Sub-region
@ Imereti | PDO
Imereti | PDO | | Imeretian
Sviri | PDO
Tsitska-Tsolikouri | Sub-region
@ Racha-Lechkhumi | PDO
Racha | PDO
Khvanchkara | PDO
Tvishi | PDO
Lechkhumi | Sub-region
@ Western Georgia | PDO
Salkhino | PDO
Samegrelo | Sub-region | | Mingrelia
Guria | Sub-region
Adjara | Sub-region | | Ajara
Abkhazia | Sub-region
Meskheti | Sub-region | | Samtskhe-Javakheti
`,
);

export const MOLDOVA = defineCountry(
  "Moldova",
  "PGI",
  "ONVV Moldova / eAmbrosia",
  `
@ Moldova | PGI
Codru | PGI | | IGP Codru
Ștefan Vodă | PGI | | Stefan Voda; IGP Stefan Voda
Valul lui Traian | PGI | | IGP Valul lui Traian; Trajan's Wall
Ciumai | PDO | | Ciumai DOP
Romănești | PDO | | Romanesti; Romănești DOP
Purcari | Sub-region
Cricova | Sub-region
Mileștii Mici | Sub-region | | Milestii Mici
`,
);

export const UKRAINE = defineCountry(
  "Ukraine",
  "Region",
  "Wikidata / national register",
  `
@ Ukraine | Region
Shabo | Region
Odesa | Region | | Odessa
Kherson | Region
Mykolaiv | Region | | Nikolaev
Zakarpattia | Region | | Transcarpathia; Zakarpattya
Bessarabia | Region | | Bessarabia
`,
);

export const TURKEY = defineCountry(
  "Turkey",
  "Region",
  "Wikidata / Turkish Patent Office GI",
  `
@ Turkey | Region
Thrace | Region | | Trakya; Thrace (Turkey)
Marmara | Region
Aegean | Region | | Ege
Central Anatolia | Region | | İç Anadolu
Cappadocia | Region | | Kapadokya
Eastern Anatolia | Region | | Doğu Anadolu; Elazığ
Southeastern Anatolia | Region | | Güneydoğu Anadolu; Diyarbakır
Mediterranean | Region | | Akdeniz
Black Sea | Region | | Karadeniz
Bozcaada | Region | | Tenedos
Urla | Region
Denizli | Region | | Güney
`,
);

export const ISRAEL = defineCountry(
  "Israel",
  "Region",
  "Israel Wine & Grapes Board (IWGB) regions",
  `
@ Galilee | Region
Galilee | Region | | Galil
Upper Galilee | Region | | Galil Elyon
Lower Galilee | Region | | Galil Tachton
Golan Heights | Region | | Golan; Ramat HaGolan
Tabor | Region
@ Shomron | Region
Shomron | Region | | Samaria
Mount Carmel | Region | | Carmel
Sharon | Region
@ Samson | Region
Samson | Region | | Shimshon
Judean Lowlands | Region | | Shfela
@ Judean Hills | Region
Judean Hills | Region | | Judea; Harei Yehuda
Jerusalem | Region
@ Negev | Region
Negev | Region | | Ramat Arad; Mitzpe Ramon
`,
);

export const LEBANON = defineCountry(
  "Lebanon",
  "Region",
  "Wikidata / UVL",
  `
@ Lebanon | Region
Bekaa Valley | Region | | Beqaa Valley; Bekaa; Beqaa
West Bekaa | Region
Mount Lebanon | Region
Batroun | Region
Jezzine | Region
Zahlé | Region | | Zahle
Kefraya | Region
`,
);

export const ARMENIA = defineCountry(
  "Armenia",
  "Region",
  "Wikidata",
  `
@ Armenia | Region
Vayots Dzor | Region | | Vayots Dzor
Areni | Region
Ararat Valley | Region | | Ararat
Armavir | Region
Aragatsotn | Region
Tavush | Region
`,
);
