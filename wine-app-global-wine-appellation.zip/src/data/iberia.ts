import { defineCountry } from "./parse";

export const SPAIN = defineCountry(
  "Spain",
  "DO",
  "eAmbrosia (EU) / MAPA",
  `
# ───────────── RIOJA / NAVARRA / ARAGÓN ─────────────
@ La Rioja | DOCa
Rioja | DOCa | | DOCa Rioja; Rioja DOC
@@ Rioja
Rioja Alta | Sub-region
Rioja Alavesa | Sub-region
Rioja Oriental | Sub-region | | Rioja Baja
@@
Valles de Sadacia | VdlT
@ Navarra | DO
Navarra | DO | | Navarre
Pago de Arínzano | VP | | Pago de Arinzano; Arínzano
Prado de Irache | VP | | Prado Irache
Pago de Otazu | VP | | Otazu
Finca Bolandin | VP | | Pago Finca Bolandin; Bolandin
Ribera del Queiles | VdlT
3 Riberas | VdlT | | Tres Riberas
@ Aragón | DO
Calatayud | DO
Campo de Borja | DO
Cariñena | DO | | Carinena
Somontano | DO
Aylés | VP | | Pago Ayles
Bajo Aragón | VdlT | | Bajo Aragon
Ribera del Gállego-Cinco Villas | VdlT | | Ribera del Gallego - Cinco Villas
Valdejalón | VdlT | | Valdejalon
Valle del Cinca | VdlT
Ribera del Jiloca | VdlT

# ───────────── CATALUÑA ─────────────
@ Cataluña | DO
Catalunya | DO | | Cataluña; Catalonia
Priorat | DOCa | | Priorato; DOQ Priorat
Alella | DO
Conca de Barberà | DO | | Conca de Barbera
Costers del Segre | DO
Empordà | DO | | Emporda; Ampurdán; Empordà-Costa Brava
Montsant | DO
Penedès | DO | | Penedes
Pla de Bages | DO
Tarragona | DO
Terra Alta | DO
Cava | DO
Clàssic Penedès | Sub-region | | Classic Penedes
Corpinnat | Sub-region

# ───────────── CASTILLA Y LEÓN ─────────────
@ Castilla y León | DO
Castilla y León | VdlT | | Castilla y Leon; Vino de la Tierra de Castilla y León
Ribera del Duero | DO
Rueda | DO
Toro | DO
Bierzo | DO | | El Bierzo
Cigales | DO
Arlanza | DO
Arribes | DO | | Arribes del Duero
Tierra de León | DO | | León; Tierra de Leon
Tierra del Vino de Zamora | DO
Cebreros | DO
Sierra de Salamanca | DO | | Vino de Calidad Sierra de Salamanca
Valles de Benavente | DO | | Vino de Calidad Valles de Benavente
Valtiendas | DO | | Vino de Calidad de Valtiendas
Abadía Retuerta | VP | | Abadia Retuerta
Dehesa Peñalba | VP | | Dehesa Penalba
Urueña | VP | | Pago de Uruena; Urueña
Sardón de Duero | Sub-region | | Sardon de Duero

# ───────────── GALICIA / ASTURIAS / CANTABRIA / PAÍS VASCO ─────────────
@ Galicia | DO
Rías Baixas | DO | | Rias Baixas
Ribeira Sacra | DO
Ribeiro | DO
Valdeorras | DO
Monterrei | DO
@@ Rías Baixas
Val do Salnés | Sub-region | | Val do Salnes; Salnés
O Rosal | Sub-region
Condado do Tea | Sub-region
Soutomaior | Sub-region
Ribeira do Ulla | Sub-region
@@
Barbanza e Iria | VdlT
Betanzos | VdlT
Valle del Miño-Ourense | VdlT | | Val do Miño-Ourense
Ribeiras do Morrazo | VdlT
@ Asturias | DO
Cangas | DO | | Vino de Calidad de Cangas
@ Cantabria | VdlT
Costa de Cantabria | VdlT
Liébana | VdlT | | Liebana
@ País Vasco | DO
Getariako Txakolina | DO | | Txakoli de Getaria; Chacolí de Guetaria
Bizkaiko Txakolina | DO | | Txakoli de Bizkaia; Chacolí de Vizcaya
Arabako Txakolina | DO | | Txakoli de Álava; Txakoli de Alava

# ───────────── CASTILLA-LA MANCHA / MADRID / EXTREMADURA ─────────────
@ Castilla-La Mancha | DO
Castilla | VdlT | | Vino de la Tierra de Castilla
La Mancha | DO
Valdepeñas | DO | | Valdepenas
Almansa | DO
Manchuela | DO
Méntrida | DO | | Mentrida
Mondéjar | DO | | Mondejar
Ribera del Júcar | DO | | Ribera del Jucar
Uclés | DO | | Ucles
Jumilla | DO
Dominio de Valdepusa | VP
Finca Élez | VP | | Finca Elez
Guijoso | VP | | Pago Guijoso
Dehesa del Carrizal | VP
Campo de la Guardia | VP
Pago Florentino | VP
Casa del Blanco | VP
Calzadilla | VP | | Pago Calzadilla
La Jaraba | VP
El Vicario | VP
Los Cerrillos | VP
Pago de Vallegarcía | VP | | Vallegarcia
Pago de la Jaraba | VP
Pozohondo | VdlT
Sierra de Alcaraz | VdlT
@ Madrid | DO
Vinos de Madrid | DO | | Madrid
Arganda | Sub-region
Navalcarnero | Sub-region
San Martín de Valdeiglesias | Sub-region | | San Martin de Valdeiglesias
El Molar | Sub-region
@ Extremadura | DO
Ribera del Guadiana | DO
Extremadura | VdlT | | Vino de la Tierra de Extremadura
Tierra de Barros | Sub-region
Matanegra | Sub-region
Cañamero | Sub-region | | Canamero
Montánchez | Sub-region | | Montanchez
Ribera Alta | Sub-region
Ribera Baja | Sub-region

# ───────────── VALENCIA / MURCIA ─────────────
@ Comunidad Valenciana | DO
Valencia | DO
Alicante | DO
Utiel-Requena | DO | | Utiel Requena
El Terrerazo | VP | | Pago El Terrerazo
Los Balagueses | VP | | Pago Los Balagueses
Chozas Carrascal | VP | | Pago Chozas Carrascal
Vera de Estenas | VP | | Pago Vera de Estenas
Castellón | VdlT | | Castellon; Castelló
@ Murcia | DO
Jumilla | DO
Yecla | DO
Bullas | DO
Murcia | VdlT
Campo de Cartagena | VdlT
Abanilla | VdlT

# ───────────── ANDALUCÍA ─────────────
@ Andalucía | DO
Jerez-Xérès-Sherry | DO | | Jerez; Xeres; Sherry; Jerez-Xeres-Sherry
Manzanilla-Sanlúcar de Barrameda | DO | | Manzanilla; Manzanilla Sanlucar de Barrameda
Montilla-Moriles | DO | | Montilla Moriles
Málaga | DO | | Malaga
Sierras de Málaga | DO | | Sierras de Malaga
Condado de Huelva | DO
Granada | DO
Lebrija | DO | | Vino de Calidad de Lebrija
Cádiz | VdlT | | Cadiz
Córdoba | VdlT | | Cordoba
Sierra Norte de Sevilla | VdlT
Los Palacios | VdlT
Altiplano de Sierra Nevada | VdlT
Cumbres del Guadalfeo | VdlT
Laderas del Genil | VdlT
Laujar-Alpujarra | VdlT
Norte de Almería | VdlT | | Norte de Almeria
Desierto de Almería | VdlT | | Desierto de Almeria
Ribera del Andarax | VdlT
Sierras de las Estancias y los Filabres | VdlT
Villaviciosa de Córdoba | VdlT | | Villaviciosa de Cordoba
Torreperogil | VdlT
Bailén | VdlT | | Bailen
Ronda | Sub-region

# ───────────── BALEARES / CANARIAS ─────────────
@ Islas Baleares | DO
Binissalem | DO | | Binissalem-Mallorca
Pla i Llevant | DO
Mallorca | VdlT
Illes Balears | VdlT
Ibiza | VdlT | | Eivissa
Formentera | VdlT
Serra de Tramuntana-Costa Nord | VdlT
Isla de Menorca | VdlT | | Menorca
@ Islas Canarias | DO
Islas Canarias | DO | | Canary Islands; Canarias
Abona | DO
El Hierro | DO
Gran Canaria | DO
La Gomera | DO
La Palma | DO
Lanzarote | DO
Tacoronte-Acentejo | DO
Valle de Güímar | DO | | Valle de Guimar
Valle de la Orotava | DO
Ycoden-Daute-Isora | DO
`,
);

export const PORTUGAL = defineCountry(
  "Portugal",
  "DOC",
  "eAmbrosia (EU) / IVV",
  `
@ Minho | DOC
Vinho Verde | DOC | | Vinhos Verdes
Vinho Verde Monção e Melgaço | DOC | | Moncao e Melgaco; Monção
Vinho Verde Lima | DOC | | Lima
Vinho Verde Cávado | DOC | | Cavado
Vinho Verde Ave | DOC | | Ave
Vinho Verde Basto | DOC | | Basto
Vinho Verde Sousa | DOC | | Sousa
Vinho Verde Amarante | DOC | | Amarante
Vinho Verde Baião | DOC | | Baiao
Vinho Verde Paiva | DOC | | Paiva
Minho | IGP | | Vinho Regional Minho
@ Douro | DOC
Douro | DOC
Porto | DOC | | Port; Oporto; Vinho do Porto; Port Wine
@@ Douro
Baixo Corgo | Sub-region
Cima Corgo | Sub-region
Douro Superior | Sub-region
@@
Duriense | IGP | | Vinho Regional Duriense
@ Trás-os-Montes | DOC
Trás-os-Montes | DOC | | Tras-os-Montes
Trás-os-Montes Chaves | DOC | | Chaves
Trás-os-Montes Valpaços | DOC | | Valpacos
Trás-os-Montes Planalto Mirandês | DOC | | Planalto Mirandes
Transmontano | IGP | | Vinho Regional Transmontano
@ Beiras | DOC
Dão | DOC | | Dao
Dão Alva | DOC | | Alva
Dão Besteiros | DOC | | Besteiros
Dão Castendo | DOC | | Castendo
Dão Serra da Estrela | DOC | | Serra da Estrela
Dão Silgueiros | DOC | | Silgueiros
Dão Terras de Azurara | DOC | | Terras de Azurara
Dão Terras de Senhorim | DOC | | Terras de Senhorim
Lafões | DOC | | Lafoes
Bairrada | DOC
Beira Interior | DOC
Beira Interior Castelo Rodrigo | DOC | | Castelo Rodrigo
Beira Interior Cova da Beira | DOC | | Cova da Beira
Beira Interior Pinhel | DOC | | Pinhel
Távora-Varosa | DOC | | Tavora-Varosa
Terras do Dão | IGP | | Terras do Dao
Terras da Beira | IGP
Beira Atlântico | IGP | | Beira Atlantico
Terras de Cister | IGP
@ Lisboa | DOC
Lisboa | IGP | | Vinho Regional Lisboa; Estremadura
Alenquer | DOC
Arruda | DOC
Bucelas | DOC
Carcavelos | DOC
Colares | DOC
Encostas d'Aire | DOC
Encostas d'Aire Alcobaça | DOC | | Alcobaca
Encostas d'Aire Ourém | DOC | | Ourem
Lourinhã | DOC | | Lourinha
Óbidos | DOC | | Obidos
Torres Vedras | DOC
@ Tejo | DOC
Tejo | IGP | | Ribatejo; Vinho Regional Tejo
Do Tejo | DOC | | Tejo DOC; DoTejo
Do Tejo Almeirim | DOC | | Almeirim
Do Tejo Cartaxo | DOC | | Cartaxo
Do Tejo Chamusca | DOC | | Chamusca
Do Tejo Coruche | DOC | | Coruche
Do Tejo Santarém | DOC | | Santarem
Do Tejo Tomar | DOC | | Tomar
@ Península de Setúbal | DOC
Península de Setúbal | IGP | | Peninsula de Setubal; Terras do Sado
Palmela | DOC
Setúbal | DOC | | Setubal; Moscatel de Setúbal; Moscatel de Setubal
@ Alentejo | DOC
Alentejo | DOC
Alentejano | IGP | | Vinho Regional Alentejano
Alentejo Borba | DOC | | Borba
Alentejo Évora | DOC | | Evora
Alentejo Granja-Amareleja | DOC | | Granja-Amareleja
Alentejo Moura | DOC | | Moura
Alentejo Portalegre | DOC | | Portalegre
Alentejo Redondo | DOC | | Redondo
Alentejo Reguengos | DOC | | Reguengos; Reguengos de Monsaraz
Alentejo Vidigueira | DOC | | Vidigueira
@ Algarve | DOC
Algarve | IGP | | Vinho Regional Algarve
Lagoa | DOC
Lagos | DOC
Portimão | DOC | | Portimao
Tavira | DOC
@ Madeira | DOC
Madeira | DOC | | Madère; Madera; Vinho da Madeira
Madeirense | DOC
Terras Madeirenses | IGP
@ Açores | DOC
Açores | IGP | | Azores; Acores
Pico | DOC
Biscoitos | DOC
Graciosa | DOC
`,
);
