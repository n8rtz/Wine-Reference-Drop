import { defineCountry } from "./parse";

export const FRANCE = defineCountry(
  "France",
  "AOC",
  "eAmbrosia (EU) / INAO",
  `
# ───────────── BORDEAUX ─────────────
@ Bordeaux | AOC
Bordeaux | AOC | | Bordeaux AOP; Vin de Bordeaux
Bordeaux Supérieur | AOC | | Bordeaux Superieur
Bordeaux Clairet | AOC
Bordeaux Rosé | AOC
Crémant de Bordeaux | AOC | | Cremant de Bordeaux
Bordeaux Haut-Benauge | AOC
Côtes de Bordeaux | AOC | | Cotes de Bordeaux
Blaye Côtes de Bordeaux | AOC | | Blaye Cotes de Bordeaux; Premières Côtes de Blaye
Cadillac Côtes de Bordeaux | AOC | | Cadillac Cotes de Bordeaux; Premières Côtes de Bordeaux
Castillon Côtes de Bordeaux | AOC | | Castillon Cotes de Bordeaux; Côtes de Castillon
Francs Côtes de Bordeaux | AOC | | Francs Cotes de Bordeaux; Bordeaux Côtes de Francs; Côtes de Francs
Sainte-Foy Côtes de Bordeaux | AOC | | Sainte-Foy-Bordeaux; Ste-Foy Bordeaux
Côtes de Bordeaux-Saint-Macaire | AOC | | Cotes de Bordeaux Saint Macaire
Premières Côtes de Bordeaux | AOC | | Premieres Cotes de Bordeaux
Entre-Deux-Mers | AOC | | Entre Deux Mers
Entre-Deux-Mers Haut-Benauge | AOC
Graves de Vayres | AOC
Blaye | AOC
Côtes de Blaye | AOC | | Cotes de Blaye
Côtes de Bourg | AOC | | Cotes de Bourg; Bourg; Bourgeais
Cadillac | AOC
Loupiac | AOC
Sainte-Croix-du-Mont | AOC | | Ste-Croix-du-Mont
Cérons | AOC | | Cerons
@ Bordeaux > Graves | AOC
Graves | AOC
Graves Supérieures | AOC | | Graves Superieures
Pessac-Léognan | AOC | | Pessac Leognan
@ Bordeaux > Sauternais | AOC
Sauternes | AOC
Barsac | AOC
@ Bordeaux > Médoc | AOC
Médoc | AOC | | Medoc; Bas-Médoc
Haut-Médoc | AOC | | Haut Medoc
Listrac-Médoc | AOC | | Listrac Medoc; Listrac
Moulis-en-Médoc | AOC | | Moulis en Medoc; Moulis
Margaux | AOC
Pauillac | AOC
Saint-Julien | AOC | | St-Julien; St Julien
Saint-Estèphe | AOC | | St-Estephe; Saint Estephe
@ Bordeaux > Libournais | AOC
Saint-Émilion | AOC | | Saint-Emilion; St-Emilion; St. Emilion
Saint-Émilion Grand Cru | AOC | | Saint-Emilion Grand Cru; St-Emilion Grand Cru
Lussac-Saint-Émilion | AOC | | Lussac Saint-Emilion; Lussac St-Emilion
Montagne-Saint-Émilion | AOC | | Montagne Saint-Emilion; Montagne St-Emilion
Puisseguin-Saint-Émilion | AOC | | Puisseguin Saint-Emilion
Saint-Georges-Saint-Émilion | AOC | | Saint-Georges Saint-Emilion; St-Georges St-Emilion
Pomerol | AOC
Lalande-de-Pomerol | AOC | | Lalande de Pomerol
Fronsac | AOC
Canon-Fronsac | AOC | | Canon Fronsac

# ───────────── BOURGOGNE ─────────────
@ Bourgogne | AOC
Bourgogne | AOC | | Burgundy; Bourgogne AOP
Bourgogne Aligoté | AOC | | Bourgogne Aligote
Bourgogne Passe-Tout-Grains | AOC | | Bourgogne Passetoutgrain; Passe-Tout-Grains
Bourgogne Mousseux | AOC
Crémant de Bourgogne | AOC | | Cremant de Bourgogne
Coteaux Bourguignons | AOC | | Bourgogne Grand Ordinaire; Bourgogne Ordinaire
Bourgogne Côte d'Or | AOC | | Bourgogne Cote d'Or
Bourgogne Hautes-Côtes de Nuits | AOC | | Hautes-Cotes de Nuits; Hautes Côtes de Nuits
Bourgogne Hautes-Côtes de Beaune | AOC | | Hautes-Cotes de Beaune; Hautes Côtes de Beaune
Bourgogne Côte Chalonnaise | AOC | | Cote Chalonnaise
Bourgogne Côtes d'Auxerre | AOC | | Cotes d'Auxerre
Bourgogne Chitry | AOC
Bourgogne Coulanges-la-Vineuse | AOC
Bourgogne Épineuil | AOC | | Bourgogne Epineuil
Bourgogne Tonnerre | AOC
Bourgogne Côte Saint-Jacques | AOC | | Cote Saint-Jacques
Bourgogne Côtes du Couchois | AOC | | Cotes du Couchois
Bourgogne Montrecul | AOC | | Montre-Cul; Bourgogne Montre-Cul
Bourgogne La Chapelle Notre-Dame | AOC
Bourgogne Le Chapitre | AOC
@ Bourgogne > Chablis | AOC
Chablis | AOC
Petit Chablis | AOC
Chablis Premier Cru | AOC | | Chablis 1er Cru
Chablis Grand Cru | AOC | | Chablis Grand Cru Les Clos; Chablis Grand Cru Vaudésir; Chablis Grand Cru Valmur; Chablis Grand Cru Blanchot; Chablis Grand Cru Bougros; Chablis Grand Cru Grenouilles; Chablis Grand Cru Preuses
@ Bourgogne > Auxerrois | AOC
Irancy | AOC
Saint-Bris | AOC | | Saint Bris; Sauvignon de Saint-Bris
Vézelay | AOC | | Vezelay; Bourgogne Vézelay
@ Bourgogne > Côte de Nuits | AOC
Côte de Nuits-Villages | AOC | | Cote de Nuits Villages
Marsannay | AOC
Fixin | AOC
Gevrey-Chambertin | AOC | | Gevrey Chambertin
Chambertin | AOC
Chambertin-Clos de Bèze | AOC | | Chambertin Clos de Beze; Clos de Bèze
Chapelle-Chambertin | AOC
Charmes-Chambertin | AOC
Griotte-Chambertin | AOC
Latricières-Chambertin | AOC | | Latricieres-Chambertin
Mazis-Chambertin | AOC | | Mazy-Chambertin
Mazoyères-Chambertin | AOC | | Mazoyeres-Chambertin
Ruchottes-Chambertin | AOC
Morey-Saint-Denis | AOC | | Morey St-Denis; Morey Saint Denis
Clos de la Roche | AOC
Clos Saint-Denis | AOC | | Clos St-Denis
Clos des Lambrays | AOC
Clos de Tart | AOC
Bonnes-Mares | AOC | | Bonnes Mares
Chambolle-Musigny | AOC | | Chambolle Musigny
Musigny | AOC
Vougeot | AOC
Clos de Vougeot | AOC | | Clos Vougeot
Vosne-Romanée | AOC | | Vosne Romanee
Romanée-Conti | AOC | | Romanee-Conti
La Romanée | AOC | | La Romanee
Romanée-Saint-Vivant | AOC | | Romanee-Saint-Vivant; Romanée St-Vivant
Richebourg | AOC
La Tâche | AOC | | La Tache
La Grande Rue | AOC
Échezeaux | AOC | | Echezeaux
Grands Échezeaux | AOC | | Grands Echezeaux
Nuits-Saint-Georges | AOC | | Nuits St-Georges; Nuits Saint Georges
@ Bourgogne > Côte de Beaune | AOC
Côte de Beaune | AOC | | Cote de Beaune
Côte de Beaune-Villages | AOC | | Cote de Beaune Villages
Ladoix | AOC | | Ladoix-Serrigny
Aloxe-Corton | AOC | | Aloxe Corton
Corton | AOC
Corton-Charlemagne | AOC | | Corton Charlemagne
Charlemagne | AOC
Pernand-Vergelesses | AOC | | Pernand Vergelesses
Chorey-lès-Beaune | AOC | | Chorey-les-Beaune; Chorey
Savigny-lès-Beaune | AOC | | Savigny-les-Beaune; Savigny
Beaune | AOC
Pommard | AOC
Volnay | AOC
Monthélie | AOC | | Monthelie
Auxey-Duresses | AOC | | Auxey Duresses
Saint-Romain | AOC | | St-Romain
Meursault | AOC
Blagny | AOC
Puligny-Montrachet | AOC | | Puligny Montrachet
Chassagne-Montrachet | AOC | | Chassagne Montrachet
Montrachet | AOC | | Le Montrachet
Chevalier-Montrachet | AOC
Bâtard-Montrachet | AOC | | Batard-Montrachet
Bienvenues-Bâtard-Montrachet | AOC | | Bienvenues Batard Montrachet
Criots-Bâtard-Montrachet | AOC | | Criots Batard Montrachet
Saint-Aubin | AOC | | St-Aubin
Santenay | AOC
Maranges | AOC
@ Bourgogne > Côte Chalonnaise | AOC
Bouzeron | AOC
Rully | AOC
Mercurey | AOC
Givry | AOC
Montagny | AOC
@ Bourgogne > Mâconnais | AOC
Mâcon | AOC | | Macon
Mâcon-Villages | AOC | | Macon-Villages; Mâcon Villages
Viré-Clessé | AOC | | Vire-Clesse
Pouilly-Fuissé | AOC | | Pouilly Fuisse
Pouilly-Loché | AOC | | Pouilly Loche
Pouilly-Vinzelles | AOC
Saint-Véran | AOC | | Saint-Veran; St-Véran

# ───────────── BEAUJOLAIS ─────────────
@ Beaujolais | AOC
Beaujolais | AOC | | Beaujolais Nouveau
Beaujolais-Villages | AOC | | Beaujolais Villages
Brouilly | AOC
Côte de Brouilly | AOC | | Cote de Brouilly
Chénas | AOC | | Chenas
Chiroubles | AOC
Fleurie | AOC
Juliénas | AOC | | Julienas
Morgon | AOC
Moulin-à-Vent | AOC | | Moulin a Vent
Régnié | AOC | | Regnie
Saint-Amour | AOC | | St-Amour

# ───────────── CHAMPAGNE ─────────────
@ Champagne | AOC
Champagne | AOC
Coteaux Champenois | AOC
Rosé des Riceys | AOC | | Rose des Riceys
@@ Champagne
Montagne de Reims | Sub-region
Vallée de la Marne | Sub-region | | Vallee de la Marne
Côte des Blancs | Sub-region | | Cote des Blancs
Côte de Sézanne | Sub-region | | Cote de Sezanne
Côte des Bar | Sub-region | | Cote des Bar; Aube
Grande Vallée de la Marne | Sub-region

# ───────────── ALSACE ─────────────
@ Alsace | AOC
Alsace | AOC | | Vin d'Alsace
Crémant d'Alsace | AOC | | Cremant d'Alsace
Alsace Grand Cru | AOC
Alsace Grand Cru Altenberg de Bergbieten | AOC | | Altenberg de Bergbieten
Alsace Grand Cru Altenberg de Bergheim | AOC | | Altenberg de Bergheim
Alsace Grand Cru Altenberg de Wolxheim | AOC | | Altenberg de Wolxheim
Alsace Grand Cru Brand | AOC | | Brand
Alsace Grand Cru Bruderthal | AOC | | Bruderthal
Alsace Grand Cru Eichberg | AOC | | Eichberg
Alsace Grand Cru Engelberg | AOC | | Engelberg
Alsace Grand Cru Florimont | AOC | | Florimont
Alsace Grand Cru Frankstein | AOC | | Frankstein
Alsace Grand Cru Froehn | AOC | | Froehn
Alsace Grand Cru Furstentum | AOC | | Furstentum
Alsace Grand Cru Geisberg | AOC | | Geisberg
Alsace Grand Cru Gloeckelberg | AOC | | Gloeckelberg
Alsace Grand Cru Goldert | AOC | | Goldert
Alsace Grand Cru Hatschbourg | AOC | | Hatschbourg
Alsace Grand Cru Hengst | AOC | | Hengst
Alsace Grand Cru Kaefferkopf | AOC | | Kaefferkopf
Alsace Grand Cru Kanzlerberg | AOC | | Kanzlerberg
Alsace Grand Cru Kastelberg | AOC | | Kastelberg
Alsace Grand Cru Kessler | AOC | | Kessler
Alsace Grand Cru Kirchberg de Barr | AOC | | Kirchberg de Barr
Alsace Grand Cru Kirchberg de Ribeauvillé | AOC | | Kirchberg de Ribeauville
Alsace Grand Cru Kitterlé | AOC | | Kitterle
Alsace Grand Cru Mambourg | AOC | | Mambourg
Alsace Grand Cru Mandelberg | AOC | | Mandelberg
Alsace Grand Cru Marckrain | AOC | | Marckrain
Alsace Grand Cru Moenchberg | AOC | | Moenchberg
Alsace Grand Cru Muenchberg | AOC | | Muenchberg
Alsace Grand Cru Ollwiller | AOC | | Ollwiller
Alsace Grand Cru Osterberg | AOC | | Osterberg
Alsace Grand Cru Pfersigberg | AOC | | Pfersigberg
Alsace Grand Cru Pfingstberg | AOC | | Pfingstberg
Alsace Grand Cru Praelatenberg | AOC | | Praelatenberg
Alsace Grand Cru Rangen | AOC | | Rangen; Rangen de Thann
Alsace Grand Cru Rosacker | AOC | | Rosacker
Alsace Grand Cru Saering | AOC | | Saering
Alsace Grand Cru Schlossberg | AOC | | Schlossberg
Alsace Grand Cru Schoenenbourg | AOC | | Schoenenbourg
Alsace Grand Cru Sommerberg | AOC | | Sommerberg
Alsace Grand Cru Sonnenglanz | AOC | | Sonnenglanz
Alsace Grand Cru Spiegel | AOC | | Spiegel
Alsace Grand Cru Sporen | AOC | | Sporen
Alsace Grand Cru Steinert | AOC | | Steinert
Alsace Grand Cru Steingrubler | AOC | | Steingrubler
Alsace Grand Cru Steinklotz | AOC | | Steinklotz
Alsace Grand Cru Vorbourg | AOC | | Vorbourg
Alsace Grand Cru Wiebelsberg | AOC | | Wiebelsberg
Alsace Grand Cru Wineck-Schlossberg | AOC | | Wineck Schlossberg
Alsace Grand Cru Winzenberg | AOC | | Winzenberg
Alsace Grand Cru Zinnkoepflé | AOC | | Zinnkoepfle
Alsace Grand Cru Zotzenberg | AOC | | Zotzenberg
Alsace Klevener de Heiligenstein | AOC | | Klevener de Heiligenstein

# ───────────── LOIRE ─────────────
@ Loire | AOC
Val de Loire | IGP | | Vin de Pays du Val de Loire; Jardin de la France
Crémant de Loire | AOC | | Cremant de Loire
Rosé de Loire | AOC | | Rose de Loire
@ Loire > Pays Nantais | AOC
Muscadet | AOC
Muscadet Sèvre et Maine | AOC | | Muscadet Sevre et Maine; Muscadet de Sèvre-et-Maine; Muscadet Sèvre-et-Maine
Muscadet Coteaux de la Loire | AOC
Muscadet Côtes de Grandlieu | AOC | | Muscadet Cotes de Grandlieu
Gros Plant du Pays Nantais | AOC | | Gros Plant
Coteaux d'Ancenis | AOC
Fiefs Vendéens | AOC | | Fiefs Vendeens
@ Loire > Anjou-Saumur | AOC
Anjou | AOC
Anjou-Villages | AOC | | Anjou Villages
Anjou-Villages Brissac | AOC | | Anjou Villages Brissac; Anjou Brissac
Anjou Coteaux de la Loire | AOC
Anjou Mousseux | AOC
Rosé d'Anjou | AOC | | Rose d'Anjou
Cabernet d'Anjou | AOC
Savennières | AOC | | Savennieres
Savennières Roche aux Moines | AOC | | Roche aux Moines
Savennières Coulée de Serrant | AOC | | Coulee de Serrant; Coulée de Serrant
Coteaux du Layon | AOC
Coteaux du Layon Premier Cru Chaume | AOC | | Chaume; Coteaux du Layon Chaume
Quarts de Chaume | AOC | | Quarts de Chaume Grand Cru
Bonnezeaux | AOC
Coteaux de l'Aubance | AOC
Saumur | AOC
Saumur-Champigny | AOC | | Saumur Champigny
Saumur Puy-Notre-Dame | AOC
Coteaux de Saumur | AOC
Cabernet de Saumur | AOC
Saumur Mousseux | AOC | | Saumur Brut
Haut-Poitou | AOC | | Haut Poitou
@ Loire > Touraine | AOC
Touraine | AOC
Touraine Amboise | AOC
Touraine Azay-le-Rideau | AOC
Touraine Mesland | AOC
Touraine Chenonceaux | AOC
Touraine Oisly | AOC
Touraine Noble Joué | AOC | | Noble Joue
Bourgueil | AOC
Saint-Nicolas-de-Bourgueil | AOC | | St-Nicolas-de-Bourgueil
Chinon | AOC
Vouvray | AOC
Montlouis-sur-Loire | AOC | | Montlouis
Cheverny | AOC
Cour-Cheverny | AOC
Valençay | AOC | | Valencay
Coteaux du Vendômois | AOC | | Coteaux du Vendomois
Coteaux du Loir | AOC
Jasnières | AOC | | Jasnieres
Orléans | AOC | | Orleans
Orléans-Cléry | AOC | | Orleans-Clery
@ Loire > Centre-Loire | AOC
Sancerre | AOC
Pouilly-Fumé | AOC | | Pouilly Fume; Blanc Fumé de Pouilly
Pouilly-sur-Loire | AOC
Menetou-Salon | AOC | | Menetou Salon
Quincy | AOC
Reuilly | AOC
Coteaux du Giennois | AOC
Châteaumeillant | AOC | | Chateaumeillant
@ Loire > Auvergne | AOC
Saint-Pourçain | AOC | | Saint-Pourcain; St-Pourçain
Côtes d'Auvergne | AOC | | Cotes d'Auvergne
Côte Roannaise | AOC | | Cote Roannaise
Côtes du Forez | AOC | | Cotes du Forez

# ───────────── RHÔNE ─────────────
@ Rhône | AOC
Côtes du Rhône | AOC | | Cotes du Rhone; Côtes-du-Rhône
Côtes du Rhône Villages | AOC | | Cotes du Rhone Villages; Côtes-du-Rhône Villages
Côtes du Rhône Villages Cairanne | AOC
Côtes du Rhône Villages Chusclan | AOC | | Chusclan
Côtes du Rhône Villages Gadagne | AOC | | Gadagne
Côtes du Rhône Villages Laudun | AOC | | Laudun
Côtes du Rhône Villages Massif d'Uchaux | AOC | | Massif d'Uchaux
Côtes du Rhône Villages Nyons | AOC | | Nyons
Côtes du Rhône Villages Plan de Dieu | AOC | | Plan de Dieu
Côtes du Rhône Villages Puyméras | AOC | | Puymeras
Côtes du Rhône Villages Roaix | AOC | | Roaix
Côtes du Rhône Villages Rochegude | AOC | | Rochegude
Côtes du Rhône Villages Rousset-les-Vignes | AOC | | Rousset-les-Vignes
Côtes du Rhône Villages Sablet | AOC | | Sablet
Côtes du Rhône Villages Saint-Andéol | AOC | | Saint-Andeol
Côtes du Rhône Villages Saint-Gervais | AOC | | Saint-Gervais
Côtes du Rhône Villages Saint-Maurice | AOC | | Saint-Maurice
Côtes du Rhône Villages Saint-Pantaléon-les-Vignes | AOC | | Saint-Pantaleon-les-Vignes
Côtes du Rhône Villages Sainte-Cécile | AOC | | Sainte-Cecile
Côtes du Rhône Villages Séguret | AOC | | Seguret
Côtes du Rhône Villages Signargues | AOC | | Signargues
Côtes du Rhône Villages Suze-la-Rousse | AOC | | Suze-la-Rousse
Côtes du Rhône Villages Vaison-la-Romaine | AOC | | Vaison-la-Romaine
Côtes du Rhône Villages Valréas | AOC | | Valreas
Côtes du Rhône Villages Visan | AOC | | Visan
@ Rhône > Northern Rhône | AOC
Côte-Rôtie | AOC | | Cote-Rotie; Côte Rôtie
Condrieu | AOC
Château-Grillet | AOC | | Chateau-Grillet
Saint-Joseph | AOC | | St-Joseph
Crozes-Hermitage | AOC | | Crozes Hermitage
Hermitage | AOC | | Ermitage
Cornas | AOC
Saint-Péray | AOC | | Saint-Peray; St-Péray
Clairette de Die | AOC
Crémant de Die | AOC | | Cremant de Die
Coteaux de Die | AOC
Châtillon-en-Diois | AOC | | Chatillon-en-Diois
@ Rhône > Southern Rhône | AOC
Châteauneuf-du-Pape | AOC | | Chateauneuf-du-Pape; Chateauneuf du Pape
Gigondas | AOC
Vacqueyras | AOC
Rasteau | AOC
Cairanne | AOC
Vinsobres | AOC
Beaumes-de-Venise | AOC | | Beaumes de Venise
Muscat de Beaumes-de-Venise | AOC | | Muscat de Beaumes de Venise
Lirac | AOC
Tavel | AOC
Ventoux | AOC | | Côtes du Ventoux; Cotes du Ventoux
Luberon | AOC | | Côtes du Luberon; Cotes du Luberon
Costières de Nîmes | AOC | | Costieres de Nimes
Grignan-les-Adhémar | AOC | | Grignan-les-Adhemar; Coteaux du Tricastin
Côtes du Vivarais | AOC | | Cotes du Vivarais
Duché d'Uzès | AOC | | Duche d'Uzes
Clairette de Bellegarde | AOC

# ───────────── PROVENCE ─────────────
@ Provence | AOC
Côtes de Provence | AOC | | Cotes de Provence
Côtes de Provence Sainte-Victoire | AOC | | Sainte-Victoire
Côtes de Provence Fréjus | AOC | | Frejus
Côtes de Provence La Londe | AOC | | La Londe
Côtes de Provence Pierrefeu | AOC | | Pierrefeu
Côtes de Provence Notre-Dame des Anges | AOC | | Notre-Dame des Anges
Coteaux d'Aix-en-Provence | AOC | | Coteaux d'Aix en Provence
Coteaux Varois en Provence | AOC | | Coteaux Varois
Bandol | AOC
Cassis | AOC
Bellet | AOC | | Vin de Bellet
Palette | AOC
Les Baux-de-Provence | AOC | | Les Baux de Provence; Baux de Provence
Pierrevert | AOC | | Coteaux de Pierrevert

# ───────────── LANGUEDOC ─────────────
@ Languedoc | AOC
Languedoc | AOC | | Coteaux du Languedoc
Languedoc Grès de Montpellier | AOC | | Gres de Montpellier
Languedoc Pézenas | AOC | | Pezenas
Languedoc Sommières | AOC | | Sommieres
Languedoc Montpeyroux | AOC | | Montpeyroux
Languedoc Saint-Saturnin | AOC | | Saint-Saturnin
Languedoc Cabrières | AOC | | Cabrieres
Languedoc Quatourze | AOC | | Quatourze
Languedoc Saint-Christol | AOC | | Saint-Christol
Languedoc Saint-Drézéry | AOC | | Saint-Drezery
Languedoc Saint-Georges-d'Orques | AOC | | Saint-Georges-d'Orques
Languedoc La Méjanelle | AOC | | La Mejanelle
Terrasses du Larzac | AOC
Pic Saint-Loup | AOC | | Pic St-Loup
La Clape | AOC
Picpoul de Pinet | AOC | | Piquepoul de Pinet
Clairette du Languedoc | AOC
Faugères | AOC | | Faugeres
Saint-Chinian | AOC | | St-Chinian
Saint-Chinian-Berlou | AOC | | Berlou
Saint-Chinian-Roquebrun | AOC | | Roquebrun
Minervois | AOC
Minervois-La Livinière | AOC | | La Liviniere; Minervois La Livinière
Corbières | AOC | | Corbieres
Corbières-Boutenac | AOC | | Corbieres Boutenac; Boutenac
Fitou | AOC
Cabardès | AOC | | Cabardes
Malepère | AOC | | Malepere
Limoux | AOC
Blanquette de Limoux | AOC
Blanquette méthode ancestrale | AOC | | Blanquette methode ancestrale
Crémant de Limoux | AOC | | Cremant de Limoux
Muscat de Frontignan | AOC | | Frontignan; Vin de Frontignan
Muscat de Lunel | AOC
Muscat de Mireval | AOC
Muscat de Saint-Jean-de-Minervois | AOC
Pays d'Oc | IGP | | Vin de Pays d'Oc
Côtes de Thongue | IGP | | Cotes de Thongue
Côtes de Thau | IGP | | Cotes de Thau
Pays d'Hérault | IGP | | Pays d'Herault; Hérault
Coteaux de Béziers | IGP | | Coteaux de Beziers
Saint-Guilhem-le-Désert | IGP | | Saint-Guilhem-le-Desert
Vicomté d'Aumelas | IGP | | Vicomte d'Aumelas
Côtes du Brian | IGP | | Cotes du Brian
Cité de Carcassonne | IGP | | Cite de Carcassonne
Coteaux de Peyriac | IGP
Haute Vallée de l'Aude | IGP | | Haute Vallee de l'Aude
Haute Vallée de l'Orb | IGP | | Haute Vallee de l'Orb
Aude | IGP | | Pays d'Aude
Gard | IGP | | Pays du Gard
Cévennes | IGP | | Cevennes
Coteaux du Pont du Gard | IGP
Sable de Camargue | IGP | | Sables du Golfe du Lion
Côtes Catalanes | IGP | | Cotes Catalanes
@ Roussillon | AOC
Côtes du Roussillon | AOC | | Cotes du Roussillon
Côtes du Roussillon Villages | AOC | | Cotes du Roussillon Villages
Côtes du Roussillon Villages Caramany | AOC | | Caramany
Côtes du Roussillon Villages Latour-de-France | AOC | | Latour-de-France
Côtes du Roussillon Villages Lesquerde | AOC | | Lesquerde
Côtes du Roussillon Villages Tautavel | AOC | | Tautavel
Côtes du Roussillon Les Aspres | AOC | | Les Aspres
Collioure | AOC
Banyuls | AOC
Banyuls Grand Cru | AOC
Maury | AOC
Maury Sec | AOC
Rivesaltes | AOC
Muscat de Rivesaltes | AOC
Grand Roussillon | AOC
Côte Vermeille | IGP | | Cote Vermeille

# ───────────── SUD-OUEST ─────────────
@ Sud-Ouest | AOC
Comté Tolosan | IGP | | Comte Tolosan
Atlantique | IGP
Côtes de Gascogne | IGP | | Cotes de Gascogne; Vin de Pays des Côtes de Gascogne
Landes | IGP
Charentais | IGP
Périgord | IGP | | Perigord
Agenais | IGP
Thézac-Perricard | IGP | | Thezac-Perricard
Côtes du Lot | IGP | | Cotes du Lot
Côtes du Tarn | IGP | | Cotes du Tarn
Ariège | IGP | | Ariege
Aveyron | IGP
Coteaux de Glanes | IGP
Lavilledieu | IGP
Gers | IGP
@ Sud-Ouest > Bergerac et Duras | AOC
Bergerac | AOC
Côtes de Bergerac | AOC | | Cotes de Bergerac
Monbazillac | AOC
Pécharmant | AOC | | Pecharmant
Rosette | AOC
Saussignac | AOC
Montravel | AOC
Haut-Montravel | AOC
Côtes de Montravel | AOC | | Cotes de Montravel
Côtes de Duras | AOC | | Cotes de Duras
@ Sud-Ouest > Garonne | AOC
Buzet | AOC | | Côtes de Buzet
Côtes du Marmandais | AOC | | Cotes du Marmandais
Brulhois | AOC | | Côtes du Brulhois
Fronton | AOC | | Côtes du Frontonnais
Saint-Sardos | AOC
@ Sud-Ouest > Lot et Tarn | AOC
Cahors | AOC
Gaillac | AOC
Gaillac Premières Côtes | AOC | | Gaillac Premieres Cotes
Coteaux du Quercy | AOC
Marcillac | AOC
Entraygues-Le Fel | AOC | | Entraygues - Le Fel
Estaing | AOC
Côtes de Millau | AOC | | Cotes de Millau
@ Sud-Ouest > Gascogne et Pyrénées | AOC
Madiran | AOC
Pacherenc du Vic-Bilh | AOC | | Pacherenc du Vic Bilh
Saint-Mont | AOC | | Côtes de Saint-Mont
Tursan | AOC
Jurançon | AOC | | Jurancon
Jurançon Sec | AOC | | Jurancon Sec
Béarn | AOC | | Bearn; Béarn-Bellocq
Irouléguy | AOC | | Irouleguy
Floc de Gascogne | AOC

# ───────────── JURA / SAVOIE / BUGEY ─────────────
@ Jura | AOC
Côtes du Jura | AOC | | Cotes du Jura
Arbois | AOC
Arbois Pupillin | AOC | | Pupillin
Château-Chalon | AOC | | Chateau-Chalon
L'Étoile | AOC | | L'Etoile; Etoile
Crémant du Jura | AOC | | Cremant du Jura
Macvin du Jura | AOC
Franche-Comté | IGP | | Franche-Comte
@ Savoie | AOC
Vin de Savoie | AOC | | Savoie
Vin de Savoie Apremont | AOC | | Apremont
Vin de Savoie Abymes | AOC | | Abymes; Les Abymes
Vin de Savoie Chignin | AOC | | Chignin
Vin de Savoie Chignin-Bergeron | AOC | | Chignin-Bergeron
Vin de Savoie Arbin | AOC | | Arbin
Vin de Savoie Jongieux | AOC | | Jongieux
Vin de Savoie Cruet | AOC | | Cruet
Vin de Savoie Montmélian | AOC | | Montmelian
Vin de Savoie Ripaille | AOC | | Ripaille
Vin de Savoie Marignan | AOC | | Marignan
Vin de Savoie Marin | AOC | | Marin
Vin de Savoie Crépy | AOC | | Crepy
Vin de Savoie Ayze | AOC | | Ayze
Vin de Savoie Chautagne | AOC | | Chautagne
Vin de Savoie Saint-Jean-de-la-Porte | AOC | | Saint-Jean-de-la-Porte
Vin de Savoie Saint-Jeoire-Prieuré | AOC | | Saint-Jeoire-Prieure
Roussette de Savoie | AOC
Roussette de Savoie Frangy | AOC | | Frangy
Roussette de Savoie Marestel | AOC | | Marestel
Roussette de Savoie Monterminod | AOC | | Monterminod
Roussette de Savoie Monthoux | AOC | | Monthoux
Seyssel | AOC
Crémant de Savoie | AOC | | Cremant de Savoie
Vin des Allobroges | IGP | | Allobroges
Isère | IGP | | Isere
@ Bugey | AOC
Bugey | AOC | | Vin du Bugey
Bugey Cerdon | AOC | | Cerdon
Bugey Montagnieu | AOC | | Montagnieu
Bugey Manicle | AOC | | Manicle
Roussette du Bugey | AOC

# ───────────── CORSE ─────────────
@ Corse | AOC
Corse | AOC | | Vin de Corse; Corsica
Ajaccio | AOC
Patrimonio | AOC
Corse Calvi | AOC | | Vin de Corse Calvi; Calvi
Corse Sartène | AOC | | Corse Sartene; Sartène
Corse Figari | AOC | | Figari
Corse Porto-Vecchio | AOC | | Porto-Vecchio
Corse Coteaux du Cap Corse | AOC | | Coteaux du Cap Corse
Muscat du Cap Corse | AOC
Île de Beauté | IGP | | Ile de Beaute

# ───────────── LORRAINE / OTHER ─────────────
@ Lorraine | AOC
Côtes de Toul | AOC | | Cotes de Toul
Moselle | AOC | | Vin de Moselle
@ Provence | IGP
Méditerranée | IGP | | Mediterranee; Vin de Pays de la Méditerranée
Var | IGP | | Pays du Var
Alpilles | IGP
Bouches-du-Rhône | IGP | | Bouches du Rhone; Pays des Bouches-du-Rhône
Alpes-de-Haute-Provence | IGP | | Alpes de Haute Provence
Alpes-Maritimes | IGP | | Alpes Maritimes
Maures | IGP
Mont Caume | IGP
Vaucluse | IGP
@ Rhône | IGP
Comtés Rhodaniens | IGP | | Comtes Rhodaniens
Collines Rhodaniennes | IGP
Ardèche | IGP | | Ardeche; Coteaux de l'Ardèche
Drôme | IGP | | Drome
Coteaux des Baronnies | IGP
Urfé | IGP | | Urfe
Puy-de-Dôme | IGP | | Puy de Dome
@ Bourgogne | IGP
Yonne | IGP
Sainte-Marie-la-Blanche | IGP
Coteaux de l'Auxois | IGP
Coteaux de Tannay | IGP
Saône-et-Loire | IGP | | Saone-et-Loire
@ Loire | IGP
Calvados | IGP
Côtes de la Charité | IGP | | Cotes de la Charite
Coteaux du Cher et de l'Arnon | IGP
Vienne | IGP
`,
);
