import { defineCountry } from "./parse";

export const ARGENTINA = defineCountry(
  "Argentina",
  "IG",
  "INV Indicaciones Geográficas (Ley 25.163)",
  `
@ Argentina | IG
Patagonia Argentina | IG | | Patagonia
Cuyo | IG
Noroeste Argentino | IG | | NOA
Centro | IG
# ───────────── MENDOZA ─────────────
@ Mendoza | IG
Mendoza | IG
Luján de Cuyo | DOC | | Lujan de Cuyo
San Rafael | DOC
Maipú | IG | | Maipu
Valle de Uco | IG | | Uco Valley
Tupungato | IG
Tunuyán | IG | | Tunuyan
San Carlos | IG
General Alvear | IG
Rivadavia | IG
San Martín | IG | | San Martin
Junín | IG | | Junin
Santa Rosa | IG
La Paz | IG
Lavalle | IG
Las Heras | IG
Guaymallén | IG | | Guaymallen
Godoy Cruz | IG
Primera Zona | IG | | Zona Alta del Río Mendoza
Este de Mendoza | IG
Sur de Mendoza | IG
Norte de Mendoza | IG
@ Mendoza > Luján de Cuyo | IG
Agrelo | IG
Perdriel | IG
Las Compuertas | IG
Vistalba | IG
Chacras de Coria | IG
Ugarteche | IG
Mayor Drummond | IG
Carrodilla | IG
El Carrizal | IG
Anchoris | IG
@ Mendoza > Maipú | IG
Barrancas | IG
Cruz de Piedra | IG
Lunlunta | IG
Russell | IG
Coquimbito | IG
Fray Luis Beltrán | IG | | Fray Luis Beltran
Rodeo del Medio | IG
Las Barrancas | IG
@ Mendoza > Valle de Uco | IG
Gualtallary | IG
San José (Tupungato) | IG | | San Jose; San José
El Peral | IG
La Arboleda | IG
Villa Bastías | IG | | Villa Bastias
Los Chacayes | IG
Vista Flores | IG
Los Árboles | IG | | Los Arboles
Villa Seca | IG
Campo de los Andes | IG
Colonia Las Rosas | IG
Paraje Altamira | IG
La Consulta | IG
Pampa El Cepillo | IG | | El Cepillo
Eugenio Bustos | IG
Chilecito (San Carlos) | IG
Los Indios | IG
Los Sauces | IG
Tres Esquinas | IG
Chacayes | Sub-region
@ Mendoza > San Rafael | IG
Las Paredes | IG
Cuadro Benegas | IG
Cañada Seca | IG | | Canada Seca
Rama Caída | IG | | Rama Caida
Villa Atuel | IG
Goudge | IG
Monte Comán | IG | | Monte Coman

# ───────────── SAN JUAN ─────────────
@ San Juan | IG
San Juan | IG
Valle de Tulum | IG
Valle de Zonda | IG | | Zonda
Valle de Ullum | IG | | Ullum
Valle de Pedernal | IG | | Pedernal; Valle del Pedernal
Valle de Calingasta | IG | | Calingasta
Barreal | IG
Valle Fértil | IG | | Valle Fertil
Jáchal | IG | | Jachal
Pocito | IG
Rawson | IG
Caucete | IG
25 de Mayo (San Juan) | IG | | 25 de Mayo; Veinticinco de Mayo
Albardón | IG | | Albardon
Angaco | IG
Sarmiento (San Juan) | IG | | Sarmiento
Santa Lucía | IG | | Santa Lucia
San Martín (San Juan) | IG
9 de Julio | IG | | Nueve de Julio
Rivadavia (San Juan) | IG
Chimbas | IG
Iglesia | IG

# ───────────── NOROESTE ─────────────
@ Salta | IG
Salta | IG
Valles Calchaquíes | IG | | Valles Calchaquies; Calchaquí Valleys
Cafayate | IG
Molinos | IG
Cachi | IG
San Carlos (Salta) | IG
Animaná | IG | | Animana
Tolombón | IG | | Tolombon
Payogasta | IG
Angastaco | IG
Seclantás | IG | | Seclantas
Yacochuya | IG
Colomé | Sub-region | | Colome
@ Catamarca | IG
Catamarca | IG
Tinogasta | IG
Fiambalá | IG | | Fiambala
Santa María | IG | | Santa Maria
Belén | IG | | Belen
Andalgalá | IG | | Andalgala
Pomán | IG | | Poman
Valle de Abaucán | IG | | Valle de Abaucan
@ La Rioja (Argentina) | IG
La Rioja Argentina | IG | | La Rioja (Argentina)
Valle de Famatina | IG | | Famatina; Valles del Famatina
Chilecito | IG
Castro Barros | IG
Sanagasta | IG
Arauco | IG
Felipe Varela | IG
Vinchina | IG
Anguinán | IG | | Anguinan
Nonogasta | IG
@ Tucumán | IG
Tucumán | IG | | Tucuman
Amaicha del Valle | IG
Colalao del Valle | IG
Tafí del Valle | IG | | Tafi del Valle
Valles Calchaquíes (Tucumán) | IG
@ Jujuy | IG
Jujuy | IG
Quebrada de Humahuaca | IG
Valles Templados de Jujuy | IG | | Valles Templados
Maimará | IG | | Maimara
Tilcara | IG

# ───────────── PATAGONIA ─────────────
@ Neuquén | IG
Neuquén | IG | | Neuquen
San Patricio del Chañar | IG | | San Patricio del Chanar
Añelo | IG | | Anelo
Confluencia | IG
Picún Leufú | IG | | Picun Leufu
Centenario | IG
@ Río Negro | IG
Río Negro | IG | | Rio Negro
Alto Valle del Río Negro | IG | | Alto Valle del Rio Negro; Alto Valle
General Roca | IG
Valle Medio | IG
Río Colorado | IG | | Rio Colorado
Avellaneda | IG
Valle Azul | IG
Mainqué | IG | | Mainque
Pichimahuida | IG
@ Chubut | IG
Chubut | IG
Trevelin | IG
Sarmiento (Chubut) | IG
Valle Inferior del Río Chubut | IG | | Valle Inferior del Rio Chubut; Gaiman
El Hoyo | IG
Paso del Sapo | IG
@ La Pampa | IG
La Pampa | IG
25 de Mayo (La Pampa) | IG
Casa de Piedra | IG

# ───────────── CENTRO / BUENOS AIRES ─────────────
@ Córdoba | IG
Córdoba (Argentina) | IG | | Cordoba
Colonia Caroya | IG
Traslasierra | IG
Calamuchita | IG
Valle de Punilla | IG
Sierras Chicas | IG
@ Buenos Aires | IG
Buenos Aires | IG
Chapadmalal | IG
Médanos | IG | | Medanos
Sierra de la Ventana | IG | | Tornquist
Villa Ventana | IG
@ Entre Ríos | IG
Entre Ríos | IG | | Entre Rios
Victoria (Entre Ríos) | IG | | Victoria
`,
);

export const CHILE = defineCountry(
  "Chile",
  "DO",
  "SAG Decreto 464 (Zonificación Vitícola)",
  `
@ Chile | DO
Costa | DO | | Chile Costa
Entre Cordilleras | DO
Andes | DO | | Chile Andes
Secano Interior | DO
@ Atacama | DO
Atacama | DO | | Región de Atacama
Valle de Copiapó | DO | | Copiapo Valley; Copiapó
Valle del Huasco | DO | | Huasco Valley; Huasco
@ Coquimbo | DO
Coquimbo | DO | | Región de Coquimbo
Valle del Elqui | DO | | Elqui Valley; Elqui
Vicuña | DO | | Vicuna
Paihuano | DO
Valle del Limarí | DO | | Limari Valley; Limarí; Limari
Ovalle | DO
Monte Patria | DO
Punitaqui | DO
Río Hurtado | DO | | Rio Hurtado
Valle del Choapa | DO | | Choapa Valley; Choapa
Salamanca | DO
Illapel | DO
@ Aconcagua | DO
Aconcagua | DO | | Aconcagua Region
Valle de Aconcagua | DO | | Aconcagua Valley
Panquehue | DO
Hijuelas | DO
Quillota | DO
San Felipe | DO
Catemu | DO
Llay Llay | DO | | Llaillay
Valle de Casablanca | DO | | Casablanca Valley; Casablanca
Valle de San Antonio | DO | | San Antonio Valley; San Antonio
Valle de Leyda | DO | | Leyda Valley; Leyda
Lo Abarca | DO
Algarrobo | DO
Cartagena | DO
Valle del Marga-Marga | DO | | Marga Marga; Valle de Marga Marga
@ Valle Central | DO
Valle Central | DO | | Central Valley
@ Valle Central > Valle del Maipo | DO
Valle del Maipo | DO | | Maipo Valley; Maipo
Santiago | DO
Pirque | DO
Puente Alto | DO
Buin | DO
Isla de Maipo | DO
Talagante | DO
Melipilla | DO
Alhué | DO | | Alhue
María Pinto | DO | | Maria Pinto
Colina | DO
Calera de Tango | DO
Til Til | DO
Alto Maipo | Sub-region | | Maipo Alto
@ Valle Central > Valle del Rapel | DO
Valle del Rapel | DO | | Rapel Valley; Rapel
Valle del Cachapoal | DO | | Cachapoal Valley; Cachapoal
Rancagua | DO
Requínoa | DO | | Requinoa
Rengo | DO
Peumo | DO
Coltauco | DO
Valle de Colchagua | DO | | Colchagua Valley; Colchagua
San Fernando | DO
Chimbarongo | DO
Nancagua | DO
Santa Cruz | DO
Palmilla | DO
Peralillo | DO
Lolol | DO
Marchigüe | DO | | Marchigue
Apalta | DO
Paredones | DO
Pumanque | DO
Litueche | DO
La Estrella | DO
Chépica | DO | | Chepica
@ Valle Central > Valle de Curicó | DO
Valle de Curicó | DO | | Curico Valley; Curicó; Curico
Valle del Teno | DO | | Teno Valley; Teno
Rauco | DO
Romeral | DO
Valle del Lontué | DO | | Lontue Valley; Lontué; Lontue
Molina | DO
Sagrada Familia | DO
Licantén | DO | | Licanten
Vichuquén | DO | | Vichuquen
@ Valle Central > Valle del Maule | DO
Valle del Maule | DO | | Maule Valley; Maule
Valle del Claro | DO | | Claro Valley
Talca | DO
Pencahue | DO
San Clemente | DO
San Rafael (Chile) | DO | | San Rafael
Valle del Loncomilla | DO | | Loncomilla Valley; Loncomilla
San Javier | DO
Villa Alegre | DO
Parral | DO
Linares | DO
Retiro | DO
Longaví | DO | | Longavi
Valle del Tutuvén | DO | | Tutuven Valley; Tutuvén; Tutuven
Cauquenes | DO
Empedrado | DO
Chanco | DO
Sauzal | DO
@ Sur | DO
Sur | DO | | Southern Region; Región del Sur
Valle del Itata | DO | | Itata Valley; Itata
Chillán | DO | | Chillan
Quillón | DO | | Quillon
Portezuelo | DO
Coelemu | DO
Ránquil | DO | | Ranquil
Guarilihue | DO
Valle del Bío-Bío | DO | | Bio Bio Valley; Bío Bío; Biobío; Bio-Bio
Yumbel | DO
Mulchén | DO | | Mulchen
Nacimiento | DO
Negrete | DO
Valle del Malleco | DO | | Malleco Valley; Malleco
Traiguén | DO | | Traiguen
Angol | DO
Purén | DO | | Puren
Collipulli | DO
@ Austral | DO
Austral | DO | | Región Austral
Valle del Cautín | DO | | Cautin Valley; Cautín; Cautin
Perquenco | DO
Galvarino | DO
Valle de Osorno | DO | | Osorno Valley; Osorno
Río Bueno | DO | | Rio Bueno
Lago Ranco | DO
Chile Chico | Sub-region | | Patagonia Chilena
`,
);

export const CANADA = defineCountry(
  "Canada",
  "VQA",
  "VQA Ontario / BC Wine Authority GIs",
  `
@ Ontario | VQA
Ontario | VQA | | VQA Ontario
Niagara Peninsula | VQA
Lake Erie North Shore | VQA
South Islands | VQA | | Pelee Island
Prince Edward County | VQA
@ Ontario > Niagara Peninsula | VQA
Niagara Escarpment (Ontario) | VQA | | Niagara Escarpment
Niagara-on-the-Lake | VQA
Beamsville Bench | VQA
Creek Shores | VQA
Four Mile Creek | VQA
Lincoln Lakeshore | VQA
Niagara Lakeshore | VQA
Niagara River | VQA
Short Hills Bench | VQA
St. David's Bench | VQA | | St Davids Bench
Twenty Mile Bench | VQA
Vinemount Ridge | VQA
@ British Columbia | GI
British Columbia | GI | | BC; BC VQA
Okanagan Valley | GI
Similkameen Valley | GI
Fraser Valley | GI
Vancouver Island | GI
Gulf Islands | GI
Thompson Valley | GI
Shuswap | GI
Lillooet | GI
Kootenays | GI
Cowichan Valley | GI
@ British Columbia > Okanagan Valley | GI
Golden Mile Bench | GI
Golden Mile Slopes | GI
Okanagan Falls | GI
Naramata Bench | GI
Skaha Bench | GI
East Kelowna Slopes | GI
South Kelowna Slopes | GI
Lake Country | GI
Summerland Bench | GI
Summerland Lakefront | GI
Summerland Valleys | GI
Black Sage Bench | Sub-region
Osoyoos | Sub-region
Oliver | Sub-region
@ Nova Scotia | Region
Nova Scotia | Region
Annapolis Valley | Region
Gaspereau Valley | Region
Tidal Bay | Appellation
@ Quebec | IGP
Vin du Québec | IGP | | Vin du Quebec; Québec; Quebec
`,
);

export const URUGUAY = defineCountry(
  "Uruguay",
  "Region",
  "INAVI",
  `
@ Uruguay | Region
Canelones | Region
Montevideo | Region
Maldonado | Region
Garzón | Region | | Garzon; Pueblo Garzón
José Ignacio | Region | | Jose Ignacio
Colonia | Region
Carmelo | Region
San José | Region | | San Jose
Juanicó | Region | | Juanico
Las Violetas | Region
Progreso | Region
Salto | Region
Rivera | Region
Paysandú | Region | | Paysandu
Durazno | Region
Atlántida | Region | | Atlantida
`,
);

export const BRAZIL = defineCountry(
  "Brazil",
  "IP",
  "INPI Indicações Geográficas",
  `
@ Rio Grande do Sul | IP
Serra Gaúcha | Region | | Serra Gaucha
Vale dos Vinhedos | DO | | Vale dos Vinhedos DO
Pinto Bandeira | DO | | Altos de Pinto Bandeira
Altos Montes | IP
Monte Belo | IP | | Monte Belo do Sul
Farroupilha | IP
Campanha Gaúcha | IP | | Campanha Gaucha; Campanha
Campos de Cima da Serra | IP
Serra do Sudeste | Region
Vale do Rio do Peixe | Region
@ Santa Catarina | IP
Vales da Uva Goethe | IP | | Urussanga
Planalto Catarinense | Region | | São Joaquim
@ Nordeste | Region
Vale do São Francisco | Region | | Vale do Sao Francisco; São Francisco Valley
@ São Paulo | Region
São Roque | Region | | Sao Roque
Espírito Santo do Pinhal | Region | | Espirito Santo do Pinhal
`,
);

export const MEXICO = defineCountry(
  "Mexico",
  "Region",
  "Consejo Mexicano Vitivinícola",
  `
@ Baja California | Region
Baja California | Region
Valle de Guadalupe | Region | | Guadalupe Valley
Valle de Calafia | Region
Valle de San Antonio de las Minas | Region | | San Antonio de las Minas
Valle de Ojos Negros | Region | | Ojos Negros
Valle de Santo Tomás | Region | | Valle de Santo Tomas; Santo Tomás
Valle de San Vicente | Region | | San Vicente
Valle de la Grulla | Region | | La Grulla
Ensenada | Region
Tecate | Region
@ Coahuila | Region
Coahuila | Region
Valle de Parras | Region | | Parras; Parras de la Fuente
Cuatro Ciénegas | Region | | Cuatro Cienegas
Arteaga | Region
@ Querétaro | Region
Querétaro | Region | | Queretaro
Tequisquiapan | Region
Ezequiel Montes | Region
@ Centro | Region
Aguascalientes | Region
Zacatecas | Region
Guanajuato | Region
San Luis Potosí | Region | | San Luis Potosi
Chihuahua | Region
Sonora | Region
`,
);

export const PERU_BOLIVIA = defineCountry(
  "Peru",
  "Region",
  "INDECOPI / Wikidata",
  `
@ Peru | Region
Ica | Region
Lima | Region
Arequipa | Region
Moquegua | Region
Tacna | Region
Cañete | Region | | Canete
`,
);

export const BOLIVIA = defineCountry(
  "Bolivia",
  "Region",
  "Wikidata",
  `
@ Bolivia | Region
Tarija | Region
Valle Central de Tarija | Region | | Tarija Central Valley
Valle de Cinti | Region | | Cinti; Los Cintis
Samaipata | Region
`,
);

export const JAPAN = defineCountry(
  "Japan",
  "GI",
  "NTA Geographical Indications (Japan)",
  `
@ Japan | GI
Yamanashi | GI | | GI Yamanashi; 山梨
Hokkaido | GI | | GI Hokkaido; 北海道
Yamagata | GI | | GI Yamagata; 山形
Nagano | GI | | GI Nagano; 長野
Osaka | GI | | GI Osaka; 大阪
Katsunuma | Sub-region | | Koshu Valley
Yoichi | Sub-region
Shiojiri | Sub-region | | Kikyogahara
`,
);

export const CHINA = defineCountry(
  "China",
  "GI",
  "CNIPA Geographical Indications",
  `
@ Ningxia | GI
Ningxia | GI | | Ningxia Hui Autonomous Region
Helan Mountain East Foothills | GI | | Helan Shan Dong Lu; Eastern Foothills of Helan Mountain; 贺兰山东麓
@ Shandong | GI
Shandong | GI
Yantai | GI | | 烟台
Penglai | GI | | 蓬莱
@ Hebei | GI
Hebei | GI
Changli | GI | | 昌黎
Huailai | GI | | Shacheng; 怀来
@ Xinjiang | GI
Xinjiang | GI
Yanqi | GI | | Yanqi Basin; 焉耆
Turpan | GI | | Turfan; 吐鲁番
Manas | GI | | 玛纳斯
@ Yunnan | GI
Yunnan | GI
Shangri-La | GI | | Shangri-La; 香格里拉; Deqin
Mile | GI | | 弥勒
@ Shanxi | GI
Shanxi | GI
Xiangning | GI | | 乡宁
@ Jilin | GI
Jilin | GI
Tonghua | GI | | 通化
@ Gansu | GI
Gansu | GI
Hexi Corridor | GI | | Hexi Zoulang; 河西走廊; Wuwei
`,
);

export const INDIA = defineCountry(
  "India",
  "GI",
  "Indian GI Registry",
  `
@ Maharashtra | GI
Nashik Valley | GI | | Nashik; Nasik Valley
Sangli | Region
Pune | Region
Akluj | Region
@ Karnataka | Region
Nandi Hills | Region
Bangalore | Region | | Bengaluru
Hampi Hills | Region
`,
);
