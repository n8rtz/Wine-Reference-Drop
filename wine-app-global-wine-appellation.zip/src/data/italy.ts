import { defineCountry } from "./parse";

export const ITALY = defineCountry(
  "Italy",
  "DOC",
  "eAmbrosia (EU) / MASAF",
  `
# ───────────── PIEMONTE ─────────────
@ Piemonte | DOC
Piemonte | DOC | | Piedmont
Alta Langa | DOCG
Asti | DOCG | | Asti Spumante; Moscato d'Asti
Barbaresco | DOCG
Barbera d'Asti | DOCG
Barbera del Monferrato Superiore | DOCG
Barolo | DOCG
Brachetto d'Acqui | DOCG | | Acqui
Canelli | DOCG
Dogliani | DOCG | | Dolcetto di Dogliani
Dolcetto di Diano d'Alba | DOCG | | Diano d'Alba
Dolcetto di Ovada Superiore | DOCG | | Ovada
Erbaluce di Caluso | DOCG | | Caluso
Gattinara | DOCG
Gavi | DOCG | | Cortese di Gavi
Ghemme | DOCG
Nizza | DOCG
Roero | DOCG
Ruchè di Castagnole Monferrato | DOCG | | Ruche di Castagnole Monferrato
Terre Alfieri | DOCG
Alba | DOC
Albugnano | DOC
Barbera d'Alba | DOC
Barbera del Monferrato | DOC
Boca | DOC
Bramaterra | DOC
Calosso | DOC
Canavese | DOC
Carema | DOC
Cisterna d'Asti | DOC
Colli Tortonesi | DOC | | Timorasso Colli Tortonesi
Collina Torinese | DOC
Colline Novaresi | DOC
Colline Saluzzesi | DOC
Cortese dell'Alto Monferrato | DOC
Coste della Sesia | DOC
Dolcetto d'Acqui | DOC
Dolcetto d'Alba | DOC
Dolcetto d'Asti | DOC
Dolcetto di Ovada | DOC
Fara | DOC
Freisa d'Asti | DOC
Freisa di Chieri | DOC
Gabiano | DOC
Grignolino d'Asti | DOC
Grignolino del Monferrato Casalese | DOC
Langhe | DOC | | Langhe Nebbiolo; Langhe Rosso
Lessona | DOC
Loazzolo | DOC
Malvasia di Casorzo d'Asti | DOC | | Casorzo
Malvasia di Castelnuovo Don Bosco | DOC
Monferrato | DOC
Nebbiolo d'Alba | DOC
Piemonte Moscato | DOC
Pinerolese | DOC
Rubino di Cantavenna | DOC
Sizzano | DOC
Strevi | DOC
Terre Alfieri | DOC
Valli Ossolane | DOC
Valsusa | DOC
Verduno Pelaverga | DOC | | Verduno

# ───────────── VALLE D'AOSTA ─────────────
@ Valle d'Aosta | DOC
Valle d'Aosta | DOC | | Vallée d'Aoste; Vallee d'Aoste; Aosta Valley
Valle d'Aosta Donnas | DOC | | Donnas
Valle d'Aosta Enfer d'Arvier | DOC | | Enfer d'Arvier
Valle d'Aosta Torrette | DOC | | Torrette
Valle d'Aosta Nus | DOC | | Nus
Valle d'Aosta Chambave | DOC | | Chambave
Valle d'Aosta Arnad-Montjovet | DOC | | Arnad-Montjovet
Valle d'Aosta Blanc de Morgex et de La Salle | DOC | | Blanc de Morgex et de La Salle

# ───────────── LIGURIA ─────────────
@ Liguria | DOC
Cinque Terre | DOC | | Cinque Terre Sciacchetrà
Colli di Luni | DOC
Colline di Levanto | DOC
Golfo del Tigullio-Portofino | DOC | | Portofino
Ormeasco di Pornassio | DOC | | Pornassio
Riviera Ligure di Ponente | DOC
Rossese di Dolceacqua | DOC | | Dolceacqua
Val Polcèvera | DOC | | Val Polcevera
Colline Savonesi | IGT
Liguria di Levante | IGT

# ───────────── LOMBARDIA ─────────────
@ Lombardia | DOC
Franciacorta | DOCG
Oltrepò Pavese Metodo Classico | DOCG | | Oltrepo Pavese Metodo Classico
Scanzo | DOCG | | Moscato di Scanzo
Sforzato di Valtellina | DOCG | | Sfursat di Valtellina; Sfurzat
Valtellina Superiore | DOCG | | Valtellina Superiore Sassella; Valtellina Superiore Grumello; Valtellina Superiore Inferno; Valtellina Superiore Valgella; Valtellina Superiore Maroggia
Bonarda dell'Oltrepò Pavese | DOC | | Bonarda dell'Oltrepo Pavese
Botticino | DOC
Buttafuoco dell'Oltrepò Pavese | DOC | | Buttafuoco
Capriano del Colle | DOC
Casteggio | DOC
Cellatica | DOC
Curtefranca | DOC | | Terre di Franciacorta
Garda | DOC
Garda Colli Mantovani | DOC
Lambrusco Mantovano | DOC
Lugana | DOC
Oltrepò Pavese | DOC | | Oltrepo Pavese
Oltrepò Pavese Pinot Grigio | DOC
Pinot Nero dell'Oltrepò Pavese | DOC
Riviera del Garda Classico | DOC | | Riviera del Garda Bresciano
Rosso di Valtellina | DOC | | Valtellina Rosso
San Colombano al Lambro | DOC | | San Colombano
San Martino della Battaglia | DOC
Sangue di Giuda dell'Oltrepò Pavese | DOC | | Sangue di Giuda
Valcalepio | DOC
Valtènesi | DOC | | Valtenesi
Alpi Retiche | IGT
Bergamasca | IGT
Provincia di Pavia | IGT
Terre Lariane | IGT

# ───────────── TRENTINO-ALTO ADIGE ─────────────
@ Trentino-Alto Adige | DOC
Alto Adige | DOC | | Südtirol; Sudtirol; South Tyrol; Südtiroler
Alto Adige Terlano | DOC | | Terlano; Terlaner
Alto Adige Valle Isarco | DOC | | Eisacktal; Valle Isarco
Alto Adige Valle Venosta | DOC | | Vinschgau
Alto Adige Santa Maddalena | DOC | | St. Magdalener; Santa Maddalena
Alto Adige Colli di Bolzano | DOC | | Bozner Leiten
Alto Adige Meranese | DOC | | Meraner
Lago di Caldaro | DOC | | Kalterersee; Caldaro
Trentino | DOC
Trentino Superiore | DOC
Trento | DOC | | Trentodoc
Teroldego Rotaliano | DOC
Casteller | DOC
Valdadige | DOC | | Etschtaler
Valdadige Terradeiforti | DOC | | Terra dei Forti
Delle Venezie | DOC | | Pinot Grigio delle Venezie
Vigneti delle Dolomiti | IGT | | Weinberg Dolomiten
Mitterberg | IGT
Vallagarina | IGT

# ───────────── VENETO ─────────────
@ Veneto | DOC
Veneto | IGT
Amarone della Valpolicella | DOCG | | Amarone
Recioto della Valpolicella | DOCG
Bardolino Superiore | DOCG
Soave Superiore | DOCG
Recioto di Soave | DOCG
Recioto di Gambellara | DOCG
Colli di Conegliano | DOCG
Conegliano Valdobbiadene Prosecco | DOCG | | Conegliano Valdobbiadene; Valdobbiadene Prosecco Superiore; Prosecco Superiore; Cartizze
Asolo Prosecco | DOCG | | Colli Asolani Prosecco; Asolo Prosecco Superiore
Lison | DOCG | | Lison Classico
Montello Rosso | DOCG | | Montello
Piave Malanotte | DOCG | | Malanotte del Piave
Friularo di Bagnoli | DOCG | | Bagnoli Friularo
Colli Euganei Fior d'Arancio | DOCG | | Fior d'Arancio Colli Euganei
Prosecco | DOC
Valpolicella | DOC | | Valpolicella Classico
Valpolicella Ripasso | DOC | | Ripasso
Soave | DOC | | Soave Classico
Bardolino | DOC | | Bardolino Chiaretto
Custoza | DOC | | Bianco di Custoza
Gambellara | DOC
Breganze | DOC
Colli Berici | DOC
Colli Euganei | DOC
Lessini Durello | DOC | | Monti Lessini; Durello
Monti Lessini | DOC
Arcole | DOC
Bagnoli di Sopra | DOC | | Bagnoli
Corti Benedettine del Padovano | DOC
Merlara | DOC
Montello - Colli Asolani | DOC | | Montello e Colli Asolani; Asolo Montello
Piave | DOC | | Vini del Piave
Lison-Pramaggiore | DOC
Riviera del Brenta | DOC
Venezia | DOC
Vicenza | DOC
Valdadige | DOC
Garda | DOC
Lugana | DOC
San Martino della Battaglia | DOC
Colli Trevigiani | IGT
Marca Trevigiana | IGT
Verona | IGT | | Veronese; Provincia di Verona
Vigneti della Serenissima | DOC | | Serenissima
Delle Venezie | DOC
Trevenezie | IGT | | Tre Venezie

# ───────────── FRIULI-VENEZIA GIULIA ─────────────
@ Friuli-Venezia Giulia | DOC
Friuli | DOC | | Friuli Venezia Giulia DOC
Ramandolo | DOCG
Colli Orientali del Friuli Picolit | DOCG | | Picolit
Rosazzo | DOCG
Lison | DOCG
Collio Goriziano | DOC | | Collio
Friuli Colli Orientali | DOC | | Colli Orientali del Friuli
Friuli Grave | DOC | | Grave del Friuli
Friuli Isonzo | DOC | | Isonzo del Friuli; Isonzo
Friuli Aquileia | DOC | | Aquileia
Friuli Latisana | DOC | | Latisana
Friuli Annia | DOC
Carso | DOC | | Carso - Kras; Kras
Prosecco | DOC
Delle Venezie | DOC
Venezia Giulia | IGT
Alto Livenza | IGT

# ───────────── EMILIA-ROMAGNA ─────────────
@ Emilia-Romagna | DOC
Emilia | IGT | | Dell'Emilia
Colli Bolognesi Classico Pignoletto | DOCG | | Colli Bolognesi Pignoletto
Romagna Albana | DOCG | | Albana di Romagna
Romagna | DOC | | Romagna Sangiovese; Sangiovese di Romagna
Colli Bolognesi | DOC
Colli di Faenza | DOC
Colli di Imola | DOC | | Colli d'Imola
Colli di Parma | DOC
Colli di Rimini | DOC | | Rimini
Colli di Scandiano e di Canossa | DOC
Colli Piacentini | DOC
Colli Romagna Centrale | DOC
Gutturnio | DOC
Lambrusco di Sorbara | DOC
Lambrusco Grasparossa di Castelvetro | DOC
Lambrusco Salamino di Santa Croce | DOC
Modena | DOC | | Lambrusco di Modena
Ortrugo dei Colli Piacentini | DOC | | Ortrugo
Pignoletto | DOC
Reggiano | DOC | | Lambrusco Reggiano
Reno | DOC
Bosco Eliceo | DOC
Rubicone | IGT
Ravenna | IGT
Forlì | IGT | | Forli

# ───────────── TOSCANA ─────────────
@ Toscana | DOC
Toscana | IGT | | Toscano; Tuscany
Brunello di Montalcino | DOCG
Carmignano | DOCG
Chianti | DOCG | | Chianti Rufina; Chianti Colli Senesi; Chianti Colli Fiorentini; Chianti Colli Aretini; Chianti Colline Pisane; Chianti Montalbano; Chianti Montespertoli
Chianti Classico | DOCG | | Chianti Classico Gran Selezione
Elba Aleatico Passito | DOCG | | Aleatico Passito dell'Elba
Montecucco Sangiovese | DOCG
Morellino di Scansano | DOCG
Rosso della Val di Cornia | DOCG | | Val di Cornia Rosso
Suvereto | DOCG
Vernaccia di San Gimignano | DOCG
Vino Nobile di Montepulciano | DOCG
Ansonica Costa dell'Argentario | DOC
Barco Reale di Carmignano | DOC
Bianco dell'Empolese | DOC
Bianco di Pitigliano | DOC
Bolgheri | DOC | | Bolgheri Superiore; Bolgheri Rosso
Bolgheri Sassicaia | DOC | | Sassicaia
Candia dei Colli Apuani | DOC
Capalbio | DOC
Colli dell'Etruria Centrale | DOC
Colli di Luni | DOC
Colline Lucchesi | DOC
Cortona | DOC
Elba | DOC
Grance Senesi | DOC
Maremma Toscana | DOC
Montecarlo | DOC
Montecucco | DOC
Monteregio di Massa Marittima | DOC
Montescudaio | DOC
Moscadello di Montalcino | DOC
Orcia | DOC
Parrina | DOC
Pomino | DOC
Rosso di Montalcino | DOC
Rosso di Montepulciano | DOC
San Gimignano | DOC
San Torpè | DOC | | San Torpe
Sant'Antimo | DOC
Sovana | DOC
Terratico di Bibbona | DOC
Terre di Casole | DOC
Terre di Pisa | DOC
Val d'Arbia | DOC
Val d'Arno di Sopra | DOC | | Valdarno di Sopra
Val di Cornia | DOC
Valdichiana Toscana | DOC
Valdinievole | DOC
Vin Santo del Chianti | DOC
Vin Santo del Chianti Classico | DOC
Vin Santo di Carmignano | DOC
Vin Santo di Montepulciano | DOC
Alta Valle della Greve | IGT
Colli della Toscana Centrale | IGT
Costa Toscana | IGT
Montecastelli | IGT
Val di Magra | IGT

# ───────────── UMBRIA ─────────────
@ Umbria | DOC
Umbria | IGT
Montefalco Sagrantino | DOCG | | Sagrantino di Montefalco
Torgiano Rosso Riserva | DOCG
Amelia | DOC
Assisi | DOC
Colli Altotiberini | DOC
Colli del Trasimeno | DOC | | Trasimeno
Colli Martani | DOC
Colli Perugini | DOC
Lago di Corbara | DOC
Montefalco | DOC
Orvieto | DOC | | Orvieto Classico
Rosso Orvietano | DOC
Spoleto | DOC
Todi | DOC
Torgiano | DOC
Allerona | IGT
Spello | IGT

# ───────────── MARCHE ─────────────
@ Marche | DOC
Marche | IGT
Castelli di Jesi Verdicchio Riserva | DOCG
Conero | DOCG | | Rosso Conero Riserva
Offida | DOCG | | Offida Pecorino; Offida Rosso
Verdicchio di Matelica Riserva | DOCG
Vernaccia di Serrapetrona | DOCG
Bianchello del Metauro | DOC
Colli Maceratesi | DOC
Colli Pesaresi | DOC
Esino | DOC
Falerio | DOC | | Falerio dei Colli Ascolani
I Terreni di Sanseverino | DOC
Lacrima di Morro d'Alba | DOC | | Lacrima di Morro
Pergola | DOC
Rosso Conero | DOC
Rosso Piceno | DOC | | Piceno
San Ginesio | DOC
Serrapetrona | DOC
Terre di Offida | DOC
Verdicchio dei Castelli di Jesi | DOC | | Castelli di Jesi
Verdicchio di Matelica | DOC

# ───────────── LAZIO ─────────────
@ Lazio | DOC
Lazio | IGT
Cannellino di Frascati | DOCG
Cesanese del Piglio | DOCG | | Piglio
Frascati Superiore | DOCG
Aleatico di Gradoli | DOC
Aprilia | DOC
Atina | DOC
Bianco Capena | DOC
Castelli Romani | DOC
Cerveteri | DOC
Cesanese di Affile | DOC
Cesanese di Olevano Romano | DOC
Circeo | DOC
Colli Albani | DOC
Colli della Sabina | DOC
Colli Etruschi Viterbesi | DOC | | Tuscia
Colli Lanuvini | DOC
Cori | DOC
Est! Est!! Est!!! di Montefiascone | DOC | | Est Est Est di Montefiascone
Frascati | DOC
Genazzano | DOC
Marino | DOC
Montecompatri Colonna | DOC
Nettuno | DOC
Orvieto | DOC
Roma | DOC
Tarquinia | DOC
Terracina | DOC | | Moscato di Terracina
Velletri | DOC
Vignanello | DOC
Zagarolo | DOC

# ───────────── ABRUZZO ─────────────
@ Abruzzo | DOC
Abruzzo | DOC
Montepulciano d'Abruzzo Colline Teramane | DOCG | | Colline Teramane; Colline Teramane Montepulciano d'Abruzzo
Tullum | DOCG | | Terre Tollesi
Montepulciano d'Abruzzo | DOC
Trebbiano d'Abruzzo | DOC
Cerasuolo d'Abruzzo | DOC
Controguerra | DOC
Villamagna | DOC
Colline Pescaresi | IGT
Colli Aprutini | IGT
Terre di Chieti | IGT
Histonium | IGT

# ───────────── MOLISE ─────────────
@ Molise | DOC
Molise | DOC | | Del Molise
Biferno | DOC
Pentro di Isernia | DOC | | Pentro
Tintilia del Molise | DOC
Osco | IGT | | Terre degli Osci
Rotae | IGT

# ───────────── CAMPANIA ─────────────
@ Campania | DOC
Campania | IGT
Aglianico del Taburno | DOCG | | Taburno
Fiano di Avellino | DOCG
Greco di Tufo | DOCG
Taurasi | DOCG
Aversa | DOC | | Asprinio di Aversa
Campi Flegrei | DOC
Capri | DOC
Casavecchia di Pontelatone | DOC
Castel San Lorenzo | DOC
Cilento | DOC
Costa d'Amalfi | DOC | | Costa d'Amalfi Furore; Costa d'Amalfi Ravello; Costa d'Amalfi Tramonti
Falanghina del Sannio | DOC
Falerno del Massico | DOC
Galluccio | DOC
Irpinia | DOC
Ischia | DOC
Lacryma Christi del Vesuvio | DOC | | Vesuvio; Lacrima Christi
Penisola Sorrentina | DOC
Sannio | DOC
Vesuvio | DOC
Beneventano | IGT | | Benevento
Colli di Salerno | IGT
Paestum | IGT
Terre del Volturno | IGT
Pompeiano | IGT

# ───────────── BASILICATA ─────────────
@ Basilicata | DOC
Basilicata | IGT
Aglianico del Vulture Superiore | DOCG
Aglianico del Vulture | DOC
Grottino di Roccanova | DOC
Matera | DOC
Terre dell'Alta Val d'Agri | DOC

# ───────────── PUGLIA ─────────────
@ Puglia | DOC
Puglia | IGT | | Apulia
Castel del Monte Bombino Nero | DOCG
Castel del Monte Nero di Troia Riserva | DOCG
Castel del Monte Rosso Riserva | DOCG
Primitivo di Manduria Dolce Naturale | DOCG
Aleatico di Puglia | DOC
Alezio | DOC
Barletta | DOC
Brindisi | DOC
Cacc'e Mmitte di Lucera | DOC
Castel del Monte | DOC
Colline Joniche Tarantine | DOC
Copertino | DOC
Galatina | DOC
Gioia del Colle | DOC
Gravina | DOC
Leverano | DOC
Lizzano | DOC
Locorotondo | DOC
Martina Franca | DOC | | Martina
Matino | DOC
Moscato di Trani | DOC
Nardò | DOC | | Nardo
Negroamaro di Terra d'Otranto | DOC
Orta Nova | DOC
Ostuni | DOC
Primitivo di Manduria | DOC
Rosso di Cerignola | DOC
Salice Salentino | DOC
San Severo | DOC
Squinzano | DOC
Tavoliere delle Puglie | DOC | | Tavoliere
Terra d'Otranto | DOC
Salento | IGT
Daunia | IGT
Murgia | IGT
Tarantino | IGT
Valle d'Itria | IGT

# ───────────── CALABRIA ─────────────
@ Calabria | DOC
Calabria | IGT
Bivongi | DOC
Cirò | DOC | | Ciro
Greco di Bianco | DOC
Lamezia | DOC
Melissa | DOC
Savuto | DOC
Scavigna | DOC
Terre di Cosenza | DOC
Sant'Anna di Isola Capo Rizzuto | DOC | | S. Anna di Isola Capo Rizzuto
Val di Neto | IGT
Locride | IGT

# ───────────── SICILIA ─────────────
@ Sicilia | DOC
Sicilia | DOC | | Sicily
Cerasuolo di Vittoria | DOCG
Alcamo | DOC
Contea di Sclafani | DOC
Contessa Entellina | DOC
Delia Nivolelli | DOC
Eloro | DOC
Erice | DOC
Etna | DOC | | Etna Rosso; Etna Bianco
Faro | DOC
Malvasia delle Lipari | DOC
Mamertino di Milazzo | DOC | | Mamertino
Marsala | DOC
Menfi | DOC
Monreale | DOC
Noto | DOC
Pantelleria | DOC | | Passito di Pantelleria; Moscato di Pantelleria
Riesi | DOC
Salaparuta | DOC
Sambuca di Sicilia | DOC
Santa Margherita di Belice | DOC
Sciacca | DOC
Siracusa | DOC
Vittoria | DOC
Terre Siciliane | IGT
Salemi | IGT
Fontanarossa di Cerda | IGT

# ───────────── SARDEGNA ─────────────
@ Sardegna | DOC
Isola dei Nuraghi | IGT | | Sardegna IGT
Vermentino di Gallura | DOCG | | Gallura
Alghero | DOC
Arborea | DOC
Cagliari | DOC
Campidano di Terralba | DOC | | Terralba
Cannonau di Sardegna | DOC | | Cannonau
Carignano del Sulcis | DOC
Girò di Cagliari | DOC
Malvasia di Bosa | DOC
Mandrolisai | DOC
Monica di Sardegna | DOC
Moscato di Sardegna | DOC
Moscato di Sorso-Sennori | DOC
Nasco di Cagliari | DOC
Nuragus di Cagliari | DOC
Sardegna Semidano | DOC
Vermentino di Sardegna | DOC
Vernaccia di Oristano | DOC
Colli del Limbara | IGT
Romangia | IGT
Barbagia | IGT
`,
);
