import { defineCountry } from "./parse";

export const GERMANY = defineCountry(
  "Germany",
  "Anbaugebiet",
  "eAmbrosia (EU) / BMEL Weingesetz",
  `
@ Ahr | Anbaugebiet
Ahr | Anbaugebiet | | Ahrtal
Walporzheim/Ahrtal | Bereich | | Walporzheim; Bereich Walporzheim-Ahrtal
Ahrtaler Landwein | Landwein
@ Baden | Anbaugebiet
Baden | Anbaugebiet
Tauberfranken | Bereich
Badische Bergstraße | Bereich | | Badische Bergstrasse
Kraichgau | Bereich
Ortenau | Bereich
Breisgau | Bereich
Kaiserstuhl | Bereich
Tuniberg | Bereich
Markgräflerland | Bereich | | Markgraflerland; Markgräfler Land
Bodensee | Bereich
Badischer Landwein | Landwein
Landwein Oberrhein | Landwein
@ Franken | Anbaugebiet
Franken | Anbaugebiet | | Franconia
Mainviereck | Bereich
Maindreieck | Bereich
Steigerwald | Bereich
Würzburger Stein | Einzellage | | Wurzburger Stein; Stein
Escherndorfer Lump | Einzellage
Iphöfer Julius-Echter-Berg | Einzellage | | Iphofer Julius-Echter-Berg
Landwein Main | Landwein | | Fränkischer Landwein
@ Hessische Bergstraße | Anbaugebiet
Hessische Bergstraße | Anbaugebiet | | Hessische Bergstrasse
Starkenburg | Bereich
Umstadt | Bereich
Starkenburger Landwein | Landwein
@ Mittelrhein | Anbaugebiet
Mittelrhein | Anbaugebiet | | Middle Rhine
Loreley | Bereich
Siebengebirge | Bereich
Bacharacher Hahn | Einzellage
Rheinburgen-Landwein | Landwein
@ Mosel | Anbaugebiet
Mosel | Anbaugebiet | | Mosel-Saar-Ruwer; Moselle
Bernkastel | Bereich | | Bereich Bernkastel; Mittelmosel
Burg Cochem | Bereich | | Zell/Mosel; Terrassenmosel; Untermosel
Saar | Bereich
Ruwertal | Bereich | | Ruwer
Obermosel | Bereich
Moseltor | Bereich
Bernkasteler Doctor | Einzellage | | Bernkasteler Doktor
Wehlener Sonnenuhr | Einzellage
Ürziger Würzgarten | Einzellage | | Urziger Wurzgarten; Uerziger Wuerzgarten
Erdener Treppchen | Einzellage
Erdener Prälat | Einzellage | | Erdener Pralat
Brauneberger Juffer | Einzellage | | Brauneberger Juffer Sonnenuhr
Piesporter Goldtröpfchen | Einzellage | | Piesporter Goldtropfchen
Graacher Himmelreich | Einzellage
Zeltinger Sonnenuhr | Einzellage
Scharzhofberg | Einzellage | | Scharzhofberger
Ockfener Bockstein | Einzellage
Ayler Kupp | Einzellage
Kanzemer Altenberg | Einzellage
Wiltinger Braune Kupp | Einzellage
Maximin Grünhaus | Einzellage | | Maximin Grunhaus; Maximin Grünhäuser Abtsberg
Kaseler Nies'chen | Einzellage
Winninger Uhlen | Einzellage
Landwein der Mosel | Landwein
Landwein der Saar | Landwein
Landwein der Ruwer | Landwein
@ Nahe | Anbaugebiet
Nahe | Anbaugebiet
Nahetal | Bereich
Niederhäuser Hermannshöhle | Einzellage | | Niederhauser Hermannshohle
Schlossböckelheimer Kupfergrube | Einzellage | | Schlossbockelheimer Kupfergrube
Nahegauer Landwein | Landwein
@ Pfalz | Anbaugebiet
Pfalz | Anbaugebiet | | Palatinate; Rheinpfalz
Mittelhaardt-Deutsche Weinstraße | Bereich | | Mittelhaardt; Mittelhaardt Deutsche Weinstrasse
Südliche Weinstraße | Bereich | | Sudliche Weinstrasse
Forster Jesuitengarten | Einzellage
Forster Kirchenstück | Einzellage | | Forster Kirchenstuck
Forster Ungeheuer | Einzellage
Deidesheimer Hohenmorgen | Einzellage
Kallstadter Saumagen | Einzellage
Birkweiler Kastanienbusch | Einzellage
Pfälzer Landwein | Landwein | | Pfalzer Landwein
@ Rheingau | Anbaugebiet
Rheingau | Anbaugebiet
Johannisberg | Bereich | | Bereich Johannisberg
Schloss Johannisberg | Einzellage
Schloss Vollrads | Einzellage
Steinberg | Einzellage | | Steinberger
Rüdesheimer Berg Schlossberg | Einzellage | | Rudesheimer Berg Schlossberg
Rauenthaler Baiken | Einzellage
Erbacher Marcobrunn | Einzellage | | Marcobrunn
Hochheimer Domdechaney | Einzellage
Rheingauer Landwein | Landwein
@ Rheinhessen | Anbaugebiet
Rheinhessen | Anbaugebiet | | Rhenish Hesse
Bingen | Bereich
Nierstein | Bereich
Wonnegau | Bereich
Roter Hang | Sub-region
Niersteiner Pettenthal | Einzellage
Niersteiner Hipping | Einzellage
Nackenheimer Rothenberg | Einzellage
Westhofener Morstein | Einzellage
Westhofener Kirchspiel | Einzellage
Dalsheimer Hubacker | Einzellage
Rheinischer Landwein | Landwein
@ Saale-Unstrut | Anbaugebiet
Saale-Unstrut | Anbaugebiet | | Saale Unstrut
Schloss Neuenburg | Bereich
Thüringen | Bereich | | Thuringen
Mansfelder Seen | Bereich
Mitteldeutscher Landwein | Landwein
@ Sachsen | Anbaugebiet
Sachsen | Anbaugebiet | | Saxony
Meißen | Bereich | | Meissen
Elstertal | Bereich
Sächsischer Landwein | Landwein | | Sachsischer Landwein
@ Württemberg | Anbaugebiet
Württemberg | Anbaugebiet | | Wurttemberg; Wuerttemberg
Remstal-Stuttgart | Bereich
Württembergisch Unterland | Bereich | | Wurttembergisch Unterland
Kocher-Jagst-Tauber | Bereich
Oberer Neckar | Bereich
Württembergischer Bodensee | Bereich
Bayerischer Bodensee | Bereich
Schwäbischer Landwein | Landwein | | Schwabischer Landwein
Landwein Neckar | Landwein
@ Deutscher Wein | Landwein
Deutscher Wein | Wein | | Deutscher Tafelwein
Landwein Rhein | Landwein
Landwein Rhein-Neckar | Landwein
Brandenburger Landwein | Landwein
Mecklenburger Landwein | Landwein
Schleswig-Holsteinischer Landwein | Landwein
Regensburger Landwein | Landwein
Saarländischer Landwein | Landwein | | Saarlandischer Landwein
Taubertäler Landwein | Landwein | | Taubertaler Landwein
Landwein Bayerischer Bodensee | Landwein | | Bayerischer Bodensee-Landwein
`,
);

export const AUSTRIA = defineCountry(
  "Austria",
  "DAC",
  "eAmbrosia (EU) / ÖWM",
  `
@ Weinland Österreich | Landwein
Weinland Österreich | Landwein | | Weinland Osterreich; Weinland
Steirerland | Landwein
Bergland | Landwein
@ Niederösterreich | DAC
Niederösterreich | Generic | | Niederosterreich; Lower Austria
Wachau | DAC | | Wachau DAC
Kremstal | DAC | | Kremstal DAC
Kamptal | DAC | | Kamptal DAC
Traisental | DAC | | Traisental DAC
Wagram | DAC | | Wagram DAC; Donauland
Weinviertel | DAC | | Weinviertel DAC
Carnuntum | DAC | | Carnuntum DAC
Thermenregion | DAC | | Thermenregion DAC
Steinfeder | Sub-region | | Wachau Steinfeder
Federspiel | Sub-region | | Wachau Federspiel
Smaragd | Sub-region | | Wachau Smaragd
@ Burgenland | DAC
Burgenland | Generic
Neusiedlersee | DAC | | Neusiedlersee DAC
Leithaberg | DAC | | Leithaberg DAC; Neusiedlersee-Hügelland
Rosalia | DAC | | Rosalia DAC
Mittelburgenland | DAC | | Mittelburgenland DAC
Eisenberg | DAC | | Eisenberg DAC; Südburgenland; Sudburgenland
Ruster Ausbruch | DAC | | Ruster Ausbruch DAC; Rust
@ Steiermark | DAC
Steiermark | Generic | | Styria
Südsteiermark | DAC | | Sudsteiermark; Südsteiermark DAC; South Styria
Vulkanland Steiermark | DAC | | Vulkanland Steiermark DAC; Südoststeiermark
Weststeiermark | DAC | | Weststeiermark DAC; Schilcherland
@ Wien | DAC
Wien | Generic | | Vienna
Wiener Gemischter Satz | DAC | | Wiener Gemischter Satz DAC
@ Bergland | Generic
Kärnten | Generic | | Karnten; Carinthia
Oberösterreich | Generic | | Oberosterreich; Upper Austria
Salzburg | Generic
Tirol | Generic | | Tyrol
Vorarlberg | Generic
`,
);

export const SWITZERLAND = defineCountry(
  "Switzerland",
  "AOC",
  "OFAG / Cantonal AOC ordinances",
  `
@ Valais | AOC
Valais | AOC | | Wallis; AOC Valais
Fully | AOC | | Fully Grand Cru
Chamoson | AOC | | Chamoson Grand Cru
Sion | AOC
Sierre | AOC
Vétroz | AOC | | Vetroz; Vétroz Grand Cru
Salgesch | AOC | | Salquenen
Visperterminen | AOC
Saint-Léonard | AOC | | Saint-Leonard
Leytron | AOC
Dôle | AOC | | Dole du Valais
Fendant | AOC | | Fendant du Valais
@ Vaud | AOC
Vaud | AOC | | AOC Vaud
Lavaux | AOC
Dézaley | AOC | | Dezaley; Dézaley Grand Cru
Calamin | AOC | | Calamin Grand Cru
Epesses | AOC
Saint-Saphorin | AOC | | St-Saphorin
Lutry | AOC
Villette | AOC
Chardonne | AOC
Vevey-Montreux | AOC
La Côte | AOC | | La Cote
Féchy | AOC | | Fechy
Mont-sur-Rolle | AOC
Morges | AOC
Nyon | AOC
Vinzel | AOC
Luins | AOC
Chablais | AOC | | Chablais Vaudois
Aigle | AOC
Yvorne | AOC
Ollon | AOC
Bex | AOC
Villeneuve | AOC
Côtes de l'Orbe | AOC | | Cotes de l'Orbe
Bonvillars | AOC
Vully | AOC
@ Genève | AOC
Genève | AOC | | Geneva; Genf
Dardagny | AOC
Satigny | AOC
Peissy | AOC
Russin | AOC
@ Neuchâtel | AOC
Neuchâtel | AOC | | Neuchatel; Neuenburg
Auvernier | AOC
Cortaillod | AOC
Trois Lacs | AOC | | Drei Seen
@ Ticino | DOC
Ticino | DOC | | Tessin
Sopraceneri | Sub-region
Sottoceneri | Sub-region
Mendrisiotto | Sub-region
@ Deutschschweiz | AOC
Deutschschweiz | AOC | | German Switzerland
Zürich | AOC | | Zurich; Zürichsee
Schaffhausen | AOC | | Hallau
Graubünden | AOC | | Graubunden; Grisons
Bündner Herrschaft | AOC | | Bundner Herrschaft; Herrschaft
Malans | AOC
Fläsch | AOC | | Flasch
Jenins | AOC
Maienfeld | AOC
Thurgau | AOC
Aargau | AOC
St. Gallen | AOC | | Sankt Gallen
Bern | AOC
Bielersee | AOC | | Lac de Bienne
Thunersee | AOC
Basel-Landschaft | AOC | | Baselland
Luzern | AOC | | Lucerne
Schwyz | AOC
Glarus | AOC
`,
);

export const LUXEMBOURG = defineCountry(
  "Luxembourg",
  "AOP",
  "eAmbrosia (EU)",
  `
@ Moselle Luxembourgeoise | AOP
Moselle Luxembourgeoise | AOP | | Moselle luxembourgeoise; Luxembourg Moselle
Crémant de Luxembourg | AOP | | Cremant de Luxembourg
Remich | Sub-region
Grevenmacher | Sub-region
Wormeldange | Sub-region
Schengen | Sub-region
`,
);

export const HUNGARY = defineCountry(
  "Hungary",
  "PDO",
  "eAmbrosia (EU) / NÉBIH",
  `
@ Tokaj | PDO
Tokaj | PDO | | Tokaji; Tokaj-Hegyalja; Tokay
Zemplén | PGI | | Zemplen
@ Észak-Magyarország | PDO
Felső-Magyarország | PGI | | Felso-Magyarorszag; Upper Hungary
Eger | PDO | | Egri; Egri Bikavér; Egri Bikaver
Bükk | PDO | | Bukk
Mátra | PDO | | Matra
Debrői Hárslevelű | PDO | | Debroi Harslevelu
@ Dunántúl | PDO
Dunántúl | PGI | | Dunantul; Transdanubia
Badacsony | PDO
Balaton | PDO | | Balatoni
Balaton-felvidék | PDO | | Balaton-felvidek; Balaton Uplands
Balatonboglár | PDO | | Balatonboglar; Dél-Balaton
Balatonfüred-Csopak | PDO | | Balatonfured-Csopak; Csopak
Etyek-Buda | PDO | | Etyek
Káli | PDO | | Kali
Mór | PDO | | Mor
Nagy-Somló | PDO | | Nagy-Somlo; Somló; Somlo; Somlói
Neszmély | PDO | | Neszmely
Pannon | PDO
Pannonhalma | PDO | | Pannonhalmi
Pécs | PDO | | Pecs
Sopron | PDO | | Soproni
Szekszárd | PDO | | Szekszard; Szekszárdi
Tihany | PDO
Tolna | PDO
Villány | PDO | | Villany; Villányi
Zala | PDO
Balatonmelléki | PGI | | Balatonmelleki
@ Alföld | PDO
Duna | PDO | | Duna-Tisza közi; Alföld
Duna-Tisza közi | PGI | | Duna-Tisza kozi
Csongrád | PDO | | Csongrad
Hajós-Baja | PDO | | Hajos-Baja
Kunság | PDO | | Kunsag
Izsáki Arany Sárfehér | PDO | | Izsaki Arany Sarfeher
Monor | PDO
Soltvadkerti | PDO | | Soltvadkert
`,
);

export const CZECHIA = defineCountry(
  "Czechia",
  "PDO",
  "eAmbrosia (EU)",
  `
@ Morava | PDO
Morava | PDO | | Moravia; Moravské
Mikulovská | PDO | | Mikulovska; Mikulov
Slovácká | PDO | | Slovacka; Slovácko
Velkopavlovická | PDO | | Velkopavlovicka; Velké Pavlovice
Znojemská | PDO | | Znojemska; Znojmo
Moravské zemské víno | PGI | | Moravske zemske vino
@ Čechy | PDO
Čechy | PDO | | Cechy; Bohemia
Mělnická | PDO | | Melnicka; Mělník
Litoměřická | PDO | | Litomericka; Litoměřice
České zemské víno | PGI | | Ceske zemske vino; české
`,
);

export const SLOVAKIA = defineCountry(
  "Slovakia",
  "PDO",
  "eAmbrosia (EU)",
  `
@ Slovakia | PDO
Malokarpatská | PDO | | Malokarpatska; Malé Karpaty; Small Carpathians
Južnoslovenská | PDO | | Juznoslovenska; Southern Slovakia
Nitrianska | PDO | | Nitra
Stredoslovenská | PDO | | Stredoslovenska; Central Slovakia
Východoslovenská | PDO | | Vychodoslovenska; Eastern Slovakia
Vinohradnícka oblasť Tokaj | PDO | | Tokaj (Slovakia); Slovak Tokaj; Tokajská
Slovenské | PGI | | Slovenske
`,
);

export const SLOVENIA = defineCountry(
  "Slovenia",
  "PDO",
  "eAmbrosia (EU)",
  `
@ Primorska | PDO
Primorska | PDO | | Primorje; Slovenian Littoral
Goriška Brda | PDO | | Goriska Brda; Brda
Vipavska dolina | PDO | | Vipava Valley; Vipava
Kras | PDO | | Karst; Teran
Slovenska Istra | PDO | | Slovenian Istria; Koper
Teran | PDO | | Kraški teran
@ Podravje | PDO
Podravje | PDO
Štajerska Slovenija | PDO | | Stajerska Slovenija; Slovenian Styria; Štajerska
Prekmurje | PDO
Jeruzalem | Sub-region | | Ljutomer-Ormož
Haloze | Sub-region
Maribor | Sub-region
Radgona-Kapela | Sub-region
@ Posavje | PDO
Posavje | PDO
Bizeljsko-Sremič | PDO | | Bizeljsko-Sremic; Bizeljsko
Dolenjska | PDO | | Cviček; Cvicek
Bela krajina | PDO | | White Carniola
Cviček | PDO | | Cvicek
Metliška črnina | PDO | | Metliska crnina
`,
);

export const CROATIA = defineCountry(
  "Croatia",
  "PDO",
  "eAmbrosia (EU)",
  `
@ Dalmacija | PDO
Dalmatinska zagora | PDO | | Dalmatian Hinterland
Sjeverna Dalmacija | PDO | | Northern Dalmatia
Srednja i Južna Dalmacija | PDO | | Srednja i Juzna Dalmacija; Central and Southern Dalmatia
Dingač | PDO | | Dingac; Pelješac Dingač
Postup | PDO
Pelješac | Sub-region | | Peljesac
Hvar | Sub-region
Korčula | Sub-region | | Korcula
Brač | Sub-region | | Brac
Komarna | Sub-region
Kaštela | Sub-region | | Kastela
Primošten | Sub-region | | Primosten
@ Istra i Kvarner | PDO
Hrvatska Istra | PDO | | Croatian Istria; Istria
Hrvatsko primorje | PDO | | Croatian Littoral; Kvarner
Muškat momjanski | PDO | | Muskat momjanski; Momjan Muscat
Krk | Sub-region
Vrbnik | Sub-region | | Vrbnička žlahtina
@ Kontinentalna Hrvatska | PDO
Slavonija | PDO | | Slavonia
Hrvatsko Podunavlje | PDO | | Croatian Danube
Moslavina | PDO
Plešivica | PDO | | Plesivica
Pokuplje | PDO
Prigorje-Bilogora | PDO
Zagorje-Međimurje | PDO | | Zagorje-Medimurje; Zagorje; Međimurje
Istočna kontinentalna Hrvatska | PGI | | Istocna kontinentalna Hrvatska
Zapadna kontinentalna Hrvatska | PGI | | Zapadna kontinentalna Hrvatska
Kutjevo | Sub-region
Ilok | Sub-region | | Srijem
Baranja | Sub-region
Erdut | Sub-region
`,
);
