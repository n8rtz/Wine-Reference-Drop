/**
 * Tiny line-oriented DSL so the curated registry data stays compact and
 * reviewable.
 *
 *   # comment
 *   @ Region                       -> region=Region, sub_region=null
 *   @ Region > Sub-region          -> region=Region, sub_region=Sub-region
 *   @ Region > Sub-region | CLASS  -> ... and default classification CLASS
 *   Name | CLASS | OFFICIAL_CODE | alt one; alt two
 *
 * Every field after Name is optional. An empty CLASS falls back to the block
 * default, then to the country default.
 */

export interface RawEntry {
  country: string;
  region: string;
  subRegion: string | null;
  name: string;
  classification: string;
  code: string | null;
  manualAlternates: string[];
  source: string;
  /** Explicit parent (set with `@@ Parent Name`), overrides region/sub-region linking. */
  parentHint: string | null;
}

export interface CountryBlock {
  country: string;
  source: string;
  entries: RawEntry[];
}

export function defineCountry(
  country: string,
  defaultClass: string,
  source: string,
  text: string,
): CountryBlock {
  const entries: RawEntry[] = [];
  let region = country;
  let subRegion: string | null = null;
  let blockClass = defaultClass;
  let parentHint: string | null = null;

  for (const rawLine of text.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;

    // `@@ Parent Name` nests following entries under Parent; bare `@@` resets.
    if (line.startsWith("@@")) {
      parentHint = line.slice(2).trim() || null;
      continue;
    }

    if (line.startsWith("@")) {
      const [scope, cls] = line.slice(1).split("|").map((s) => s.trim());
      const [r, s] = scope.split(">").map((x) => x.trim());
      region = r || country;
      subRegion = s || null;
      blockClass = cls || defaultClass;
      parentHint = null;
      continue;
    }

    const parts = line.split("|").map((p) => p.trim());
    const name = parts[0];
    if (!name) continue;
    const classification = parts[1] || blockClass;
    const code = parts[2] || null;
    const manualAlternates = (parts[3] || "")
      .split(";")
      .map((a) => a.trim())
      .filter(Boolean);

    entries.push({
      country,
      region,
      subRegion,
      name,
      classification,
      code,
      manualAlternates,
      source,
      parentHint,
    });
  }

  return { country, source, entries };
}
