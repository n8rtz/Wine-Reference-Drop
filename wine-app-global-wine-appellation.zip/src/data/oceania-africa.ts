import { defineCountry } from "./parse";

export const AUSTRALIA = defineCountry(
  "Australia",
  "GI",
  "Wine Australia Register of Protected GIs",
  `
@ Australia | GI
South Eastern Australia | GI | | South-Eastern Australia; SE Australia
# ───────────── SOUTH AUSTRALIA ─────────────
@ South Australia | GI
South Australia | GI | | SA
Adelaide | Zone | | Adelaide Super Zone
Barossa | Zone
Fleurieu | Zone
Limestone Coast | Zone
Lower Murray | Zone
Mount Lofty Ranges | Zone
The Peninsulas | Zone
Far North | Zone
@ South Australia > Barossa | GI
Barossa Valley | GI
Eden Valley | GI
@@ Eden Valley
High Eden | Sub-region
@@
@ South Australia > Fleurieu | GI
McLaren Vale | GI
Langhorne Creek | GI
Currency Creek | GI
Kangaroo Island | GI
Southern Fleurieu | GI
@ South Australia > Limestone Coast | GI
Coonawarra | GI
Padthaway | GI
Wrattonbully | GI
Mount Benson | GI
Mount Gambier | GI
Robe | GI
@ South Australia > Lower Murray | GI
Riverland | GI
@ South Australia > Mount Lofty Ranges | GI
Adelaide Hills | GI
@@ Adelaide Hills
Lenswood | Sub-region
@@
@@ Adelaide Hills
Piccadilly Valley | Sub-region
@@
Adelaide Plains | GI
Clare Valley | GI
@ South Australia > Far North | GI
Southern Flinders Ranges | GI

# ───────────── VICTORIA ─────────────
@ Victoria | GI
Victoria | GI | | VIC
Central Victoria | Zone
Gippsland | Zone
North East Victoria | Zone
North West Victoria | Zone
Port Phillip | Zone
Western Victoria | Zone
@ Victoria > Central Victoria | GI
Bendigo | GI
Goulburn Valley | GI
@@ Goulburn Valley
Nagambie Lakes | Sub-region
@@
Heathcote | GI
Strathbogie Ranges | GI
Upper Goulburn | GI
@ Victoria > North East Victoria | GI
Alpine Valleys | GI
Beechworth | GI
Glenrowan | GI
King Valley | GI
Rutherglen | GI
@ Victoria > North West Victoria | GI
Murray Darling | GI
Swan Hill | GI
@ Victoria > Port Phillip | GI
Geelong | GI
Macedon Ranges | GI
Mornington Peninsula | GI
Sunbury | GI
Yarra Valley | GI
@ Victoria > Western Victoria | GI
Grampians | GI
@@ Grampians
Great Western | Sub-region
@@
Henty | GI
Pyrenees | GI

# ───────────── NEW SOUTH WALES ─────────────
@ New South Wales | GI
New South Wales | GI | | NSW
Big Rivers | Zone
Central Ranges | Zone
Hunter Valley | Zone
Northern Rivers | Zone
Northern Slopes | Zone
South Coast | Zone
Southern New South Wales | Zone
Western Plains | Zone
@ New South Wales > Big Rivers | GI
Murray Darling | GI
Perricoota | GI
Riverina | GI
Swan Hill | GI
@ New South Wales > Central Ranges | GI
Cowra | GI
Mudgee | GI
Orange | GI
@ New South Wales > Hunter Valley | GI
Hunter | GI | | Hunter Valley
@@ Hunter
Broke Fordwich | Sub-region
@@
@@ Hunter
Pokolbin | Sub-region
@@
@@ Hunter
Upper Hunter Valley | Sub-region | | Upper Hunter
@@
@ New South Wales > Northern Rivers | GI
Hastings River | GI
@ New South Wales > Northern Slopes | GI
New England Australia | GI | | New England
@ New South Wales > South Coast | GI
Shoalhaven Coast | GI
Southern Highlands | GI
@ New South Wales > Southern New South Wales | GI
Canberra District | GI | | Canberra
Gundagai | GI
Hilltops | GI
Tumbarumba | GI
@ Australian Capital Territory | GI
Australian Capital Territory | GI | | ACT

# ───────────── WESTERN AUSTRALIA ─────────────
@ Western Australia | GI
Western Australia | GI | | WA
Central Western Australia | Zone
Eastern Plains, Inland and North of Western Australia | Zone
Greater Perth | Zone
South West Australia | Zone
West Australian South East Coastal | Zone
@ Western Australia > Greater Perth | GI
Peel | GI
Perth Hills | GI
Swan District | GI
@@ Swan District
Swan Valley | Sub-region
@@
@ Western Australia > South West Australia | GI
Blackwood Valley | GI
Geographe | GI
Great Southern | GI
@@ Great Southern
Albany | Sub-region
@@
@@ Great Southern
Denmark | Sub-region
@@
@@ Great Southern
Frankland River | Sub-region
@@
@@ Great Southern
Mount Barker | Sub-region
@@
@@ Great Southern
Porongurup | Sub-region
@@
Manjimup | GI
Margaret River | GI
Pemberton | GI

# ───────────── TASMANIA / QUEENSLAND / NT ─────────────
@ Tasmania | GI
Tasmania | GI | | TAS
Tamar Valley | Sub-region
Pipers River | Sub-region
Coal River Valley | Sub-region
Derwent Valley | Sub-region
East Coast Tasmania | Sub-region | | East Coast
Huon Valley | Sub-region
North West Tasmania | Sub-region
@ Queensland | GI
Queensland | GI | | QLD
Granite Belt | GI
South Burnett | GI
@ Northern Territory | GI
Northern Territory | GI | | NT
`,
);

export const NEW_ZEALAND = defineCountry(
  "New Zealand",
  "GI",
  "IPONZ Geographical Indications Register",
  `
@ New Zealand | GI
New Zealand | GI | | NZ; Aotearoa
North Island | GI
South Island | GI
@ North Island | GI
Northland | GI
Auckland | GI
@@ Auckland
Kumeu | GI
Matakana | GI
Waiheke Island | GI | | Waiheke
@@
Gisborne | GI
Hawke's Bay | GI | | Hawkes Bay; Hawke's Bay
@@ Hawke's Bay
Central Hawke's Bay | GI | | Central Hawkes Bay
Gimblett Gravels | Sub-region
Bridge Pa Triangle | Sub-region
@@
Wairarapa | GI
@@ Wairarapa
Gladstone | GI
Martinborough | GI
@@
@ South Island | GI
Nelson | GI
Marlborough | GI
Canterbury | GI
@@ Canterbury
North Canterbury | GI
@@ North Canterbury
Waipara Valley | GI | | Waipara
@@
Waitaki Valley North Otago | GI | | Waitaki Valley; Waitaki
Central Otago | GI
@@ Central Otago
Bannockburn | GI
Gibbston | Sub-region
Cromwell Basin | Sub-region
Bendigo (NZ) | Sub-region | | Bendigo
Alexandra | Sub-region
Wanaka | Sub-region
@@ Marlborough
Awatere Valley | Sub-region
Wairau Valley | Sub-region
Southern Valleys | Sub-region
@@
`,
);

export const SOUTH_AFRICA = defineCountry(
  "South Africa",
  "WO",
  "SAWIS Wine of Origin Scheme",
  `
@ Western Cape | WO
Western Cape | Geographical Unit
Coastal Region | Region
Breede River Valley | Region
Cape South Coast | Region
Klein Karoo | Region | | Little Karoo
Olifants River | Region
Boberg | Region
Cape Coast | Region
Cederberg | District
Ceres Plateau | District
Prince Albert | District
Lamberts Bay | Ward
Nieuwoudtville | Ward
Swartberg-Kannaland | District
@ Western Cape > Coastal Region | WO
@@
Cape Town | District
@@ Cape Town
Constantia | Ward
Durbanville | Ward
Hout Bay | Ward
Philadelphia | Ward
@@
Darling | District
@@ Darling
Groenekloof | Ward
@@
Franschhoek Valley | District | | Franschhoek
@@ Franschhoek Valley
@@
Paarl | District
@@ Paarl
Agter-Paarl | Ward | | Agter Paarl
Simonsberg-Paarl | Ward
Voor Paardeberg | Ward
@@
Stellenbosch | District
@@ Stellenbosch
Banghoek | Ward
Bottelary | Ward
Devon Valley | Ward
Jonkershoek Valley | Ward
Papegaaiberg | Ward
Polkadraai Hills | Ward
Simonsberg-Stellenbosch | Ward
Vlottenburg | Ward
Helderberg | Sub-region
@@
Swartland | District
@@ Swartland
Malmesbury | Ward
Riebeekberg | Ward
Riebeeksrivier | Ward
Paardeberg | Ward
Paardeberg South | Ward
St Helena Bay | Ward | | St. Helena Bay
Piket-Bo-Berg | Ward
Porseleinberg | Ward
@@
Tulbagh | District
@@ Tulbagh
@@
Tygerberg | District
@@ Tygerberg
@@
Wellington | District
@@ Wellington
Blouvlei | Ward
Bovlei | Ward
Groenberg | Ward
Limietberg | Ward
Mid-Berg River | Ward
@@
Lutzville Valley | District
@@ Lutzville Valley
Koekenaap | Ward
Bamboes Bay | Ward
@ Western Cape > Breede River Valley | WO
@@
Breedekloof | District
@@ Breedekloof
Goudini | Ward
Slanghoek | Ward
@@
Robertson | District
@@ Robertson
Agterkliphoogte | Ward
Ashton | Ward
Boesmansrivier | Ward
Bonnievale | Ward
Eilandia | Ward
Goree | Ward
Goudmyn | Ward
Hoopsrivier | Ward
Klaasvoogds | Ward
Le Chasseur | Ward
McGregor | Ward
Vinkrivier | Ward
Zandrivier | Ward
@@
Worcester | District
@@ Worcester
Hex River Valley | Ward
Nuy | Ward
Scherpenheuvel | Ward
Stettyn | Ward
Aan-de-Doorns | Ward
@ Western Cape > Cape South Coast | WO
@@
Cape Agulhas | District
@@ Cape Agulhas
Elim | Ward
@@
Elgin | District
@@ Elgin
@@
Overberg | District
@@ Overberg
Elandskloof | Ward
Greyton | Ward
Klein River | Ward
Theewater | Ward
@@
Plettenberg Bay | District
@@ Plettenberg Bay
@@
Swellendam | District
@@ Swellendam
Buffeljags | Ward
Malgas | Ward
Stormsvlei | Ward
@@
Walker Bay | District
@@ Walker Bay
Bot River | Ward
Hemel-en-Aarde Valley | Ward | | Hemel en Aarde Valley
Upper Hemel-en-Aarde Valley | Ward
Hemel-en-Aarde Ridge | Ward
Sunday's Glen | Ward | | Sundays Glen
Stanford Foothills | Ward
Springfontein Rim | Ward
Herbertsdale | Ward
Napier | Ward
Stilbaai East | Ward
Lower Duivenhoks River | Ward
@ Western Cape > Klein Karoo | WO
Calitzdorp | District
@@ Calitzdorp
Cango Valley | Ward
Groenfontein | Ward
@@
Langeberg-Garcia | District
Montagu | Ward
Tradouw | Ward
Tradouw Highlands | Ward
Upper Langkloof | Ward
Outeniqua | Ward
Koo Plateau | Ward
@ Western Cape > Olifants River | WO
@@
Citrusdal Mountain | District
@@ Citrusdal Mountain
Piekenierskloof | Ward
@@
Citrusdal Valley | District
@@
Vredendal | Ward
Spruitdrift | Ward
@ Northern Cape | WO
Northern Cape | Geographical Unit
Douglas | District
Central Orange River | District
Sutherland-Karoo | District
Hartswater | Ward
@@ Central Orange River
Groblershoop | Ward
Grootdrink | Ward
Kakamas | Ward
Keimoes | Ward
Upington | Ward
@@
Prieska | Ward
@ Eastern Cape | WO
Eastern Cape | Geographical Unit
St Francis Bay | Ward
@ KwaZulu-Natal | WO
KwaZulu-Natal | Geographical Unit
Central Drakensberg | Ward
Lions River | Ward
@ Limpopo | WO
Limpopo | Geographical Unit
@ Free State | WO
Free State | Geographical Unit
Rietrivier FS | Ward | | Rietrivier
`,
);
