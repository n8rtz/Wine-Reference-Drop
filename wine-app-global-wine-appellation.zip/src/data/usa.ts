import { defineCountry } from "./parse";

export const USA = defineCountry(
  "United States",
  "AVA",
  "TTB 27 CFR Part 9",
  `
# ───────────── CALIFORNIA ─────────────
@ California | AVA
California | State AO | | CA
North Coast | AVA
Central Coast | AVA
South Coast | AVA
Sierra Foothills | AVA
San Francisco Bay | AVA
Napa Valley | AVA | | Napa
Sonoma County | County AO | | Sonoma
Mendocino County | County AO | | Mendocino
Lake County | County AO
Monterey County | County AO
Santa Barbara County | County AO
San Luis Obispo County | County AO
Santa Clara County | County AO
Amador County | County AO
El Dorado County | County AO
Solano County | County AO
Yolo County | County AO
Contra Costa County | County AO
Alameda County | County AO
Riverside County | County AO
San Diego County | County AO
Los Angeles County | County AO
Clear Lake | AVA
Guenoc Valley | AVA
Benmore Valley | AVA
High Valley | AVA
Red Hills Lake County | AVA | | Red Hills
Big Valley District-Lake County | AVA | | Big Valley District
Kelsey Bench-Lake County | AVA | | Kelsey Bench
Upper Lake Valley | AVA
Long Valley-Lake County | AVA
Solano County Green Valley | AVA | | Green Valley of Solano County
Suisun Valley | AVA
Wild Horse Valley | AVA
Livermore Valley | AVA
Santa Clara Valley | AVA
Santa Cruz Mountains | AVA
Ben Lomond Mountain | AVA
Pacheco Pass | AVA
San Ysidro District | AVA
Lamorinda | AVA
Mount Harlan | AVA | | Mt. Harlan
Cienega Valley | AVA
Lime Kiln Valley | AVA
Paicines | AVA
San Benito | AVA
Gabilan Mountains | AVA
Monterey | AVA
Santa Lucia Highlands | AVA
Arroyo Seco | AVA
Carmel Valley | AVA
Chalone | AVA
Hames Valley | AVA
San Lucas | AVA
San Bernabe | AVA
San Antonio Valley | AVA
Paso Robles | AVA | | Paso Robles Wine Country
York Mountain | AVA
Edna Valley | AVA
Arroyo Grande Valley | AVA
San Luis Obispo Coast | AVA | | SLO Coast
Santa Maria Valley | AVA
Santa Ynez Valley | AVA
Sta. Rita Hills | AVA | | Santa Rita Hills
Happy Canyon of Santa Barbara | AVA | | Happy Canyon
Ballard Canyon | AVA
Los Olivos District | AVA
Alisos Canyon | AVA
Temecula Valley | AVA | | Temecula
Malibu Coast | AVA
Malibu-Newton Canyon | AVA
Saddle Rock-Malibu | AVA
Leona Valley | AVA
Antelope Valley of the California High Desert | AVA | | Antelope Valley
Sierra Pelona Valley | AVA
San Pasqual Valley | AVA
Ramona Valley | AVA
Cucamonga Valley | AVA
Palos Verdes Peninsula | AVA
Tehachapi Mountains | AVA
Lodi | AVA
Clarksburg | AVA
Merritt Island | AVA
Dunnigan Hills | AVA
Capay Valley | AVA
Madera | AVA
River Junction | AVA
Tracy Hills | AVA
Salado Creek | AVA
Diablo Grande | AVA
Squaw Valley-Miramonte | AVA
Inwood Valley | AVA
Manton Valley | AVA
Seiad Valley | AVA
Willow Creek | AVA
Trinity Lakes | AVA
Contra Costa | Sub-region | | Contra Costa County
@ California > Napa Valley | AVA
Los Carneros | AVA | | Carneros
Howell Mountain | AVA
Stags Leap District | AVA | | Stag's Leap District
Mount Veeder | AVA | | Mt. Veeder
Atlas Peak | AVA
Spring Mountain District | AVA | | Spring Mountain
Oakville | AVA
Rutherford | AVA
St. Helena | AVA | | Saint Helena; St Helena
Chiles Valley | AVA | | Chiles Valley District
Yountville | AVA
Diamond Mountain District | AVA | | Diamond Mountain
Oak Knoll District of Napa Valley | AVA | | Oak Knoll District; Oak Knoll
Calistoga | AVA
Coombsville | AVA
Crystal Springs of Napa Valley | AVA | | Crystal Springs
@ California > Sonoma County | AVA
Sonoma Valley | AVA
Sonoma Coast | AVA
West Sonoma Coast | AVA
Fort Ross-Seaview | AVA
Petaluma Gap | AVA
Alexander Valley | AVA
Dry Creek Valley | AVA
Rockpile | AVA
Russian River Valley | AVA
Green Valley of Russian River Valley | AVA | | Green Valley; Sonoma County Green Valley
Chalk Hill | AVA
Knights Valley | AVA
Northern Sonoma | AVA
Bennett Valley | AVA
Sonoma Mountain | AVA
Moon Mountain District Sonoma County | AVA | | Moon Mountain District
Fountaingrove District | AVA
Pine Mountain-Cloverdale Peak | AVA
@ California > Mendocino County | AVA
Mendocino | AVA
Anderson Valley | AVA
Mendocino Ridge | AVA
Potter Valley | AVA
Redwood Valley | AVA
McDowell Valley | AVA
Cole Ranch | AVA
Yorkville Highlands | AVA
Covelo | AVA
Dos Rios | AVA
Eagle Peak Mendocino County | AVA | | Eagle Peak
Comptche | AVA
@ California > Paso Robles | AVA
Adelaida District | AVA
Creston District | AVA
El Pomar District | AVA
Paso Robles Estrella District | AVA | | Estrella District
Paso Robles Geneseo District | AVA | | Geneseo District
Paso Robles Highlands District | AVA
Paso Robles Willow Creek District | AVA | | Willow Creek District
San Juan Creek | AVA
San Miguel District | AVA
Santa Margarita Ranch | AVA
Templeton Gap District | AVA | | Templeton Gap
@ California > Lodi | AVA
Alta Mesa | AVA
Borden Ranch | AVA
Clements Hills | AVA
Cosumnes River | AVA
Jahant | AVA
Mokelumne River | AVA
Sloughhouse | AVA
@ California > Sierra Foothills | AVA
El Dorado | AVA
Fair Play | AVA
California Shenandoah Valley | AVA | | Shenandoah Valley (California); Shenandoah Valley of California
Fiddletown | AVA
North Yuba | AVA

# ───────────── OREGON ─────────────
@ Oregon | AVA
Oregon | State AO | | OR
Willamette Valley | AVA
Southern Oregon | AVA
Umpqua Valley | AVA
Red Hill Douglas County | AVA | | Red Hill Douglas County, Oregon
Elkton Oregon | AVA | | Elkton
Rogue Valley | AVA
Applegate Valley | AVA
Columbia Gorge | AVA
Snake River Valley | AVA
@ Oregon > Willamette Valley | AVA
Dundee Hills | AVA
Eola-Amity Hills | AVA | | Eola Amity Hills
McMinnville | AVA
Ribbon Ridge | AVA
Yamhill-Carlton | AVA | | Yamhill-Carlton District
Chehalem Mountains | AVA
Van Duzer Corridor | AVA
Laurelwood District | AVA
Tualatin Hills | AVA
Lower Long Tom | AVA
Mount Pisgah Polk County Oregon | AVA | | Mount Pisgah; Mt. Pisgah Polk County

# ───────────── WASHINGTON ─────────────
@ Washington | AVA
Washington | State AO | | WA; Washington State
Columbia Valley | AVA
Puget Sound | AVA
Columbia Gorge | AVA
Lewis-Clark Valley | AVA
@ Washington > Columbia Valley | AVA
Yakima Valley | AVA
Red Mountain | AVA
Rattlesnake Hills | AVA
Snipes Mountain | AVA
Candy Mountain | AVA
Goose Gap | AVA
Walla Walla Valley | AVA
The Rocks District of Milton-Freewater | AVA | | Rocks District; The Rocks District
Horse Heaven Hills | AVA
Wahluke Slope | AVA
Ancient Lakes of Columbia Valley | AVA | | Ancient Lakes
Lake Chelan | AVA
Naches Heights | AVA
Royal Slope | AVA
The Burn of Columbia Valley | AVA | | The Burn
White Bluffs | AVA
Rocky Reach | AVA

# ───────────── IDAHO ─────────────
@ Idaho | AVA
Idaho | State AO | | ID
Snake River Valley | AVA
Eagle Foothills | AVA
Lewis-Clark Valley | AVA

# ───────────── NEW YORK ─────────────
@ New York | AVA
New York | State AO | | NY; New York State
Finger Lakes | AVA
Hudson River Region | AVA | | Hudson Valley
Upper Hudson | AVA
Long Island | AVA
Lake Erie | AVA
Niagara Escarpment | AVA
Champlain Valley of New York | AVA | | Champlain Valley
@ New York > Finger Lakes | AVA
Cayuga Lake | AVA
Seneca Lake | AVA
@ New York > Long Island | AVA
North Fork of Long Island | AVA | | North Fork
The Hamptons, Long Island | AVA | | The Hamptons; Hamptons Long Island

# ───────────── VIRGINIA / MID-ATLANTIC ─────────────
@ Virginia | AVA
Virginia | State AO | | VA
Monticello | AVA
Shenandoah Valley | AVA
Northern Neck George Washington Birthplace | AVA | | Northern Neck
North Fork of Roanoke | AVA
Rocky Knob | AVA
Virginia's Eastern Shore | AVA | | Virginia Eastern Shore
Middleburg Virginia | AVA | | Middleburg
Virginia Peninsula | AVA
@ Maryland | AVA
Maryland | State AO | | MD
Linganore | AVA
Catoctin | AVA
Cumberland Valley | AVA
@ Pennsylvania | AVA
Pennsylvania | State AO | | PA
Lancaster Valley | AVA
Lehigh Valley | AVA
Central Delaware Valley | AVA
@ New Jersey | AVA
New Jersey | State AO | | NJ
Warren Hills | AVA
Outer Coastal Plain | AVA
Cape May Peninsula | AVA
@ West Virginia | AVA
West Virginia | State AO | | WV
Kanawha River Valley | AVA
Ohio River Valley | AVA

# ───────────── NEW ENGLAND ─────────────
@ Massachusetts | AVA
Massachusetts | State AO | | MA
Martha's Vineyard | AVA | | Marthas Vineyard
Southeastern New England | AVA
@ Connecticut | AVA
Connecticut | State AO | | CT
Western Connecticut Highlands | AVA
@ Rhode Island | AVA
Rhode Island | State AO | | RI
@ Vermont | AVA
Vermont | State AO | | VT

# ───────────── SOUTHEAST ─────────────
@ North Carolina | AVA
North Carolina | State AO | | NC
Yadkin Valley | AVA
Swan Creek | AVA
Haw River Valley | AVA
Upper Hiwassee Highlands | AVA
Appalachian High Country | AVA
Crest of the Blue Ridge Henderson County | AVA | | Crest of the Blue Ridge
@ Georgia | AVA
Georgia (US) | State AO | | Georgia; GA
Dahlonega Plateau | AVA
@ Tennessee | AVA
Tennessee | State AO | | TN
Mississippi Delta | AVA
@ Mississippi | AVA
Mississippi | State AO | | MS
@ Alabama | AVA
Alabama | State AO | | AL
@ Florida | AVA
Florida | State AO | | FL
@ Kentucky | AVA
Kentucky | State AO | | KY

# ───────────── MIDWEST ─────────────
@ Michigan | AVA
Michigan | State AO | | MI
Fennville | AVA
Lake Michigan Shore | AVA
Leelanau Peninsula | AVA
Old Mission Peninsula | AVA
Tip of the Mitt | AVA
@ Ohio | AVA
Ohio | State AO | | OH
Ohio River Valley | AVA
Isle St. George | AVA | | Isle Saint George
Grand River Valley | AVA
Loramie Creek | AVA
Lake Erie | AVA
@ Indiana | AVA
Indiana | State AO | | IN
Indiana Uplands | AVA
@ Illinois | AVA
Illinois | State AO | | IL
Shawnee Hills | AVA
Upper Mississippi River Valley | AVA
@ Wisconsin | AVA
Wisconsin | State AO | | WI
Lake Wisconsin | AVA
Wisconsin Ledge | AVA
@ Minnesota | AVA
Minnesota | State AO | | MN
Alexandria Lakes | AVA
@ Iowa | AVA
Iowa | State AO | | IA
Loess Hills District | AVA
@ Missouri | AVA
Missouri | State AO | | MO
Augusta | AVA
Hermann | AVA
Ozark Highlands | AVA
Ozark Mountain | AVA
@ Arkansas | AVA
Arkansas | State AO | | AR
Altus | AVA
Arkansas Mountain | AVA
@ Oklahoma | AVA
Oklahoma | State AO | | OK
@ Nebraska | AVA
Nebraska | State AO | | NE
@ Kansas | AVA
Kansas | State AO | | KS

# ───────────── TEXAS / SOUTHWEST ─────────────
@ Texas | AVA
Texas | State AO | | TX
Texas Hill Country | AVA | | Hill Country
Fredericksburg in the Texas Hill Country | AVA | | Fredericksburg
Bell Mountain | AVA
Texas High Plains | AVA | | High Plains
Escondido Valley | AVA
Texas Davis Mountains | AVA | | Davis Mountains
Texoma | AVA
Mesilla Valley | AVA
@ New Mexico | AVA
New Mexico | State AO | | NM
Middle Rio Grande Valley | AVA
Mimbres Valley | AVA
Mesilla Valley | AVA
@ Arizona | AVA
Arizona | State AO | | AZ
Sonoita | AVA
Willcox | AVA
Verde Valley | AVA
@ Colorado | AVA
Colorado | State AO | | CO
Grand Valley | AVA
West Elks | AVA
@ Nevada | AVA
Nevada | State AO | | NV
@ Utah | AVA
Utah | State AO | | UT

# ───────────── PACIFIC ─────────────
@ Hawaii | AVA
Hawaii | State AO | | HI
Ulupalakua | AVA
@ Alaska | AVA
Alaska | State AO | | AK
`,
);
