import type { CountryBlock, RawEntry } from "./parse";
import { FRANCE } from "./france";
import { ITALY } from "./italy";
import { PORTUGAL, SPAIN } from "./iberia";
import {
  AUSTRIA,
  CROATIA,
  CZECHIA,
  GERMANY,
  HUNGARY,
  LUXEMBOURG,
  SLOVAKIA,
  SLOVENIA,
  SWITZERLAND,
} from "./central-europe";
import {
  ARMENIA,
  BULGARIA,
  CYPRUS,
  GEORGIA,
  GREECE,
  ISRAEL,
  LEBANON,
  MALTA,
  MOLDOVA,
  ROMANIA,
  TURKEY,
  UKRAINE,
  UNITED_KINGDOM,
} from "./europe-east-med";
import { USA } from "./usa";
import { AUSTRALIA, NEW_ZEALAND, SOUTH_AFRICA } from "./oceania-africa";
import {
  ARGENTINA,
  BOLIVIA,
  BRAZIL,
  CANADA,
  CHILE,
  CHINA,
  INDIA,
  JAPAN,
  MEXICO,
  PERU_BOLIVIA,
  URUGUAY,
} from "./americas-asia";
import {
  dedupeKey,
  generateAlternates,
  normalizeForSearch,
  serializeAlternates,
} from "@/lib/normalize";
import eambrosiaWine from "./eambrosia-wine.json";
import ttbAvas from "./ttb-avas.json";

export type Level = "region" | "sub_region" | "appellation";

export interface GazetteerRow {
  id: number;
  country: string;
  region: string;
  subRegion: string | null;
  appellationName: string;
  classificationSystem: string | null;
  officialCode: string | null;
  alternateNames: string | null;
  continent: string;
  level: Level;
  parentId: number | null;
  source: string;
  nameNorm: string;
  altNorm: string | null;
  searchText: string;
}

export const COUNTRY_BLOCKS: CountryBlock[] = [
  FRANCE,
  ITALY,
  SPAIN,
  PORTUGAL,
  GERMANY,
  AUSTRIA,
  SWITZERLAND,
  LUXEMBOURG,
  HUNGARY,
  CZECHIA,
  SLOVAKIA,
  SLOVENIA,
  CROATIA,
  GREECE,
  ROMANIA,
  BULGARIA,
  CYPRUS,
  MALTA,
  UNITED_KINGDOM,
  GEORGIA,
  MOLDOVA,
  UKRAINE,
  TURKEY,
  ARMENIA,
  ISRAEL,
  LEBANON,
  USA,
  CANADA,
  MEXICO,
  ARGENTINA,
  CHILE,
  URUGUAY,
  BRAZIL,
  PERU_BOLIVIA,
  BOLIVIA,
  AUSTRALIA,
  NEW_ZEALAND,
  SOUTH_AFRICA,
  JAPAN,
  CHINA,
  INDIA,
];

export const CONTINENTS: Record<string, string> = {
  France: "Europe",
  Italy: "Europe",
  Spain: "Europe",
  Portugal: "Europe",
  Germany: "Europe",
  Austria: "Europe",
  Switzerland: "Europe",
  Luxembourg: "Europe",
  Hungary: "Europe",
  Czechia: "Europe",
  Slovakia: "Europe",
  Slovenia: "Europe",
  Croatia: "Europe",
  Greece: "Europe",
  Romania: "Europe",
  Bulgaria: "Europe",
  Cyprus: "Europe",
  Malta: "Europe",
  "United Kingdom": "Europe",
  Netherlands: "Europe",
  Belgium: "Europe",
  Denmark: "Europe",
  Ireland: "Europe",
  Poland: "Europe",
  Sweden: "Europe",
  Lithuania: "Europe",
  Latvia: "Europe",
  Estonia: "Europe",
  Finland: "Europe",
  Georgia: "Europe",
  Moldova: "Europe",
  Ukraine: "Europe",
  Armenia: "Europe",
  Turkey: "Asia",
  Israel: "Asia",
  Lebanon: "Asia",
  Japan: "Asia",
  China: "Asia",
  India: "Asia",
  "United States": "North America",
  Canada: "North America",
  Mexico: "North America",
  Argentina: "South America",
  Chile: "South America",
  Uruguay: "South America",
  Brazil: "South America",
  Peru: "South America",
  Bolivia: "South America",
  Australia: "Oceania",
  "New Zealand": "Oceania",
  "South Africa": "Africa",
};

/** Human readable registry description for every country (used by the UI + docs). */
export const COUNTRY_SOURCES: Array<{ country: string; source: string; continent: string }> =
  COUNTRY_BLOCKS.map((b) => ({
    country: b.country,
    source: b.source,
    continent: CONTINENTS[b.country] ?? "Other",
  }));

function levelOf(e: { region: string; subRegion: string | null; name: string }): Level {
  if (e.subRegion && e.name === e.subRegion) return "sub_region";
  if (!e.subRegion && e.name === e.region) return "region";
  return "appellation";
}

/**
 * Add synthetic container rows for any region / sub-region referenced by
 * entries but not present as a row of its own, so the parent chain
 * (Pauillac -> Médoc -> Bordeaux -> France) is always fully linked.
 */
function withSyntheticContainers(entries: RawEntry[]): RawEntry[] {
  const existing = new Set(entries.map((e) => dedupeKey(e.country, e.name)));
  const out: RawEntry[] = [];
  const added = new Set<string>();

  for (const e of entries) {
    const regionKey = dedupeKey(e.country, e.region);
    if (e.region !== e.country && !existing.has(regionKey) && !added.has(regionKey)) {
      added.add(regionKey);
      out.push({
        country: e.country,
        region: e.region,
        subRegion: null,
        name: e.region,
        classification: "Region",
        code: null,
        manualAlternates: [],
        source: "Hierarchy container (synthetic)",
        parentHint: null,
      });
    }
    if (e.subRegion) {
      const subKey = dedupeKey(e.country, e.subRegion);
      if (!existing.has(subKey) && !added.has(subKey)) {
        added.add(subKey);
        out.push({
          country: e.country,
          region: e.region,
          subRegion: e.subRegion,
          name: e.subRegion,
          classification: "Sub-region",
          code: null,
          manualAlternates: [],
          source: "Hierarchy container (synthetic)",
          parentHint: null,
        });
      }
    }
    out.push(e);
  }
  return out;
}


// ─────────────────────────────────────────────────────────────────────────────
// Registry enrichment (snapshots fetched by pipeline/fetch_eambrosia.py and
// pipeline/fetch_ttb_avas.py). Fills official codes, adds protected-name
// variants as alternates and auto-imports registry entries missing from the
// curated set so coverage is exhaustive for the EU register and TTB AVAs.
// ─────────────────────────────────────────────────────────────────────────────

interface EambrosiaRecord {
  id: string;
  file: string;
  names: string[];
  countries: string[];
  type: string;
  status: string;
  date: string | null;
  removed: boolean;
  third: boolean;
}
interface TtbRecord {
  section: string;
  name: string;
}

const ISO_COUNTRY: Record<string, string> = {
  FR: "France", IT: "Italy", ES: "Spain", PT: "Portugal", DE: "Germany", AT: "Austria", HU: "Hungary",
  GR: "Greece", EL: "Greece", RO: "Romania", BG: "Bulgaria", HR: "Croatia", SI: "Slovenia", CZ: "Czechia",
  SK: "Slovakia", CY: "Cyprus", MT: "Malta", LU: "Luxembourg", GB: "United Kingdom", UK: "United Kingdom",
  NL: "Netherlands", BE: "Belgium", DK: "Denmark", IE: "Ireland", PL: "Poland", SE: "Sweden", LT: "Lithuania",
  LV: "Latvia", EE: "Estonia", FI: "Finland",
};

const NATIONAL_TERM: Record<string, { PDO: string; PGI: string }> = {
  France: { PDO: "AOC", PGI: "IGP" },
  Italy: { PDO: "DOP", PGI: "IGT" },
  Spain: { PDO: "DOP", PGI: "IGP" },
  Portugal: { PDO: "DOP", PGI: "IGP" },
  Germany: { PDO: "Anbaugebiet", PGI: "Landwein" },
  Luxembourg: { PDO: "AOP", PGI: "IGP" },
};

function classificationFor(country: string, giType: string): string {
  const t = NATIONAL_TERM[country];
  if (t && (giType === "PDO" || giType === "PGI")) return t[giType];
  return giType;
}


/** Region anchoring for registry imports whose names carry no curated anchor. */
const REGION_HINTS: Record<string, [string, string | null, string?]> = {
  // Italy – IGT/DOP → region
  ...Object.fromEntries(["Anagni", "Colli Cimini", "Frusinate", "Costa Etrusco Romana", "Civitella d'Agliano"].map((n) => [`Italy|${n}`, ["Lazio", null]])),
  ...Object.fromEntries(["Ortona", "Terre Aquilane", "Terre Abruzzesi", "Casauria"].map((n) => [`Italy|${n}`, ["Abruzzo", null]])),
  ...Object.fromEntries(["Fortana del Taro", "Val Tidone", "Bianco del Sillaro", "Terre di Veleja"].map((n) => [`Italy|${n}`, ["Emilia-Romagna", null]])),
  ...Object.fromEntries(["Arghillà", "Costa Viola", "Lipuda", "Palizzi", "Pellaro", "Valdamato", "Scilla"].map((n) => [`Italy|${n}`, ["Calabria", null]])),
  ...Object.fromEntries(["Conselvano"].map((n) => [`Italy|${n}`, ["Veneto", null]])),
  ...Object.fromEntries(["Terre del Colleoni", "Alto Mincio", "Benaco Bresciano", "Collina del Milanese", "Montenetto di Brescia", "Ronchi di Brescia", "Sebino", "Ronchi Varesini", "Valcamonica", "Quistello", "Sabbioneta", "Provincia di Mantova"].map((n) => [`Italy|${n}`, ["Lombardia", null]])),
  ...Object.fromEntries(["Marmilla", "Nurra", "Ogliastra", "Parteolla", "Planargia", "Provincia di Nuoro", "Sibiola", "Tharros", "Trexenta", "Valle del Tirso", "Valli di Porto Pino"].map((n) => [`Italy|${n}`, ["Sardegna", null]])),
  ...Object.fromEntries(["Catalanesca del Monte Somma", "Epomeo", "Dugenta", "Roccamonfina"].map((n) => [`Italy|${n}`, ["Campania", null]])),
  ...Object.fromEntries(["Colline del Genovesato", "Terrazze dell'Imperiese"].map((n) => [`Italy|${n}`, ["Liguria", null]])),
  ...Object.fromEntries(["Bettona", "Cannara", "Narni"].map((n) => [`Italy|${n}`, ["Umbria", null]])),
  ...Object.fromEntries(["Salina", "Camarro", "Valle Belice", "Avola"].map((n) => [`Italy|${n}`, ["Sicilia", null]])),
  // France
  "France|Côtes de Meuse": ["Lorraine", null],
  "France|Hautes-Alpes": ["Provence", null],
  "France|Coteaux du Lyonnais": ["Beaujolais", null],
  ...Object.fromEntries(["Vallée du Paradis", "Coteaux d'Ensérune", "Vallée du Torgan", "Le Pays Cathare", "Terres du Midi"].map((n) => [`France|${n}`, ["Languedoc", null]])),
  "France|Coteaux de l'Ain": ["Bugey", null],
  "France|Pays de Brive": ["Sud-Ouest", null],
  "France|Corrèze": ["Sud-Ouest", null],
  "France|Île-de-France": ["Île-de-France", null],
  "France|Pineau des Charentes": ["Charentes", null],
  "France|Lorraine": ["Lorraine", null],
  // Spain
  "Spain|Sierra Sur de Jaén": ["Andalucía", null],
  "Spain|Campo de Calatrava": ["Castilla-La Mancha", null],
  "Spain|Terras do Navia": ["Galicia", null],
  // Germany – single-vineyard PDOs
  "Germany|Bürgstadter Berg": ["Franken", null, "Einzellage"],
  "Germany|Monzinger Niederberg": ["Nahe", null, "Einzellage"],
  "Germany|Uhlen Blaufüsser Lay": ["Mosel", null, "Einzellage"],
  "Germany|Uhlen Roth Lay": ["Mosel", null, "Einzellage"],
  "Germany|Uhlen Laubach": ["Mosel", null, "Einzellage"],
  // Hungary
  ...Object.fromEntries(["Kőszeg", "Etyeki Pezsgő", "Füred", "Mura", "Nivegy-völgy"].map((n) => [`Hungary|${n}`, ["Dunántúl", null]])),
  // Czechia / Slovenia / Croatia
  "Czechia|Šobes": ["Morava", null],
  "Czechia|Novosedelské Slámové víno": ["Morava", null],
  "Slovenia|Belokranjec": ["Posavje", null],
  "Slovenia|Bizeljčan": ["Posavje", null],
  "Croatia|Ponikve": ["Dalmacija", null],
  // United States – AVAs established after the curated snapshot
  "United States|Paulsell Valley": ["Washington", null],
  "United States|Winters Highlands": ["California", null],
  "United States|Yucaipa Valley": ["California", null],
  "United States|San Luis Rey": ["California", null],
  "United States|Upper Cumberland": ["Tennessee", null],
  "United States|Tryon Foothills": ["North Carolina", null],
  "United States|Nashoba Valley": ["Massachusetts", null],
};

function hintFor(country: string, name: string) {
  const direct = REGION_HINTS[`${country}|${name}`];
  if (direct) return direct;
  const n = normalizeForSearch(name);
  for (const [k, v] of Object.entries(REGION_HINTS)) {
    const [c, hn] = k.split("|");
    if (c === country && normalizeForSearch(hn) === n) return v;
  }
  return undefined;
}

type NameIndex = Map<string, RawEntry>;

function buildNameIndex(entries: RawEntry[]): NameIndex {
  const idx: NameIndex = new Map();
  for (const e of entries) {
    const names = [e.name, ...generateAlternates(e.name, e.manualAlternates)];
    for (const n of names) {
      const k = `${e.country}|${normalizeForSearch(n)}`;
      if (!idx.has(k)) idx.set(k, e);
    }
  }
  return idx;
}

/** Longest curated name (same country) appearing as whole words inside `name`. */
function findAnchor(entries: RawEntry[], country: string, name: string): RawEntry | undefined {
  const padded = ` ${normalizeForSearch(name)} `;
  let best: RawEntry | undefined;
  let bestLen = 0;
  for (const e of entries) {
    if (e.country !== country) continue;
    const en = normalizeForSearch(e.name);
    if (en.length < 4 || en.length <= bestLen) continue;
    if (padded.includes(` ${en} `)) {
      best = e;
      bestLen = en.length;
    }
  }
  return best;
}

function applyRegistryEnrichment(entries: RawEntry[]): RawEntry[] {
  const idx = buildNameIndex(entries);
  const additions: RawEntry[] = [];
  const addedKeys = new Set<string>();

  // ---- EU eAmbrosia -------------------------------------------------------
  for (const rec of eambrosiaWine as EambrosiaRecord[]) {
    if (rec.status !== "registered" || rec.removed || rec.third || !rec.names.length) continue;
    const country = ISO_COUNTRY[rec.countries[0]];
    if (!country) continue;

    let hit: RawEntry | undefined;
    for (const n of rec.names) {
      hit = idx.get(`${country}|${normalizeForSearch(n)}`);
      if (hit) break;
    }
    if (hit) {
      if (!hit.code) hit.code = rec.file;
      for (const n of rec.names) if (n !== hit.name && !hit.manualAlternates.includes(n)) hit.manualAlternates.push(n);
      continue;
    }

    const name = rec.names[0];
    const key = dedupeKey(country, name);
    if (addedKeys.has(key)) continue;
    addedKeys.add(key);
    const hint = hintFor(country, name);
    const anchor = hint ? undefined : findAnchor(entries, country, name);
    const entry: RawEntry = {
      country,
      region: hint ? hint[0] : anchor ? anchor.region : country,
      subRegion: hint ? hint[1] : anchor ? anchor.subRegion : null,
      name,
      classification: hint?.[2] ?? classificationFor(country, rec.type),
      code: rec.file,
      manualAlternates: rec.names.slice(1),
      source: "eAmbrosia (EU) — registry import",
      parentHint: null,
    };
    additions.push(entry);
    idx.set(`${country}|${normalizeForSearch(name)}`, entry);
  }

  // ---- US TTB (27 CFR Part 9) ---------------------------------------------
  for (const rec of ttbAvas as TtbRecord[]) {
    const clean = rec.name.replace(/\s+AVA\.?$/i, "").replace(/\.$/, "").trim();
    if (!clean) continue;
    const code = `27 CFR ${rec.section}`;
    const candidates = [clean, clean.replace(/,.*$/, "")];
    let hit: RawEntry | undefined;
    for (const c of candidates) {
      hit = idx.get(`United States|${normalizeForSearch(c)}`);
      if (hit) break;
    }
    if (hit) {
      if (!hit.code) hit.code = code;
      if (clean !== hit.name && !hit.manualAlternates.includes(clean)) hit.manualAlternates.push(clean);
      continue;
    }
    const key = dedupeKey("United States", clean);
    if (addedKeys.has(key)) continue;
    addedKeys.add(key);
    const hint = hintFor("United States", clean);
    const anchor = hint ? undefined : findAnchor(entries, "United States", clean);
    const entry: RawEntry = {
      country: "United States",
      region: hint ? hint[0] : anchor ? anchor.region : "United States",
      subRegion: hint ? hint[1] : anchor ? anchor.subRegion : null,
      name: clean,
      classification: "AVA",
      code,
      manualAlternates: [],
      source: "TTB 27 CFR Part 9 — registry import",
      parentHint: null,
    };
    additions.push(entry);
    idx.set(`United States|${normalizeForSearch(clean)}`, entry);
  }

  const all = [...entries, ...additions];
  const codeByName = new Map<string, string>();
  for (const e of all) if (e.code) codeByName.set(dedupeKey(e.country, e.name), e.code);
  for (const e of all) if (!e.code) e.code = codeByName.get(dedupeKey(e.country, e.name)) ?? null;
  return all;
}

function buildRows(): GazetteerRow[] {
  const raw = COUNTRY_BLOCKS.flatMap((b) => b.entries);

  // --- de-duplicate on (country, region, name); merge manual alternates ---
  const byKey = new Map<string, RawEntry>();
  const ordered: RawEntry[] = [];
  for (const e of raw) {
    const key = dedupeKey(e.country, e.region, e.name);
    const prev = byKey.get(key);
    if (prev) {
      for (const a of e.manualAlternates) if (!prev.manualAlternates.includes(a)) prev.manualAlternates.push(a);
      if (!prev.code && e.code) prev.code = e.code;
      continue;
    }
    byKey.set(key, e);
    ordered.push(e);
  }

  // --- official registry enrichment (codes, alternates, missing entries) ---
  // then synthetic region / sub-region containers so every row has a parent chain
  const enriched = withSyntheticContainers(applyRegistryEnrichment(ordered));

  // --- assign ids ---
  const hints = new Map<number, string>();
  const rows: GazetteerRow[] = enriched.map((e, i) => {
    if (e.parentHint) hints.set(i + 1, e.parentHint);
    const alts = generateAlternates(e.name, e.manualAlternates);
    const alternateNames = serializeAlternates(alts);
    const nameNorm = normalizeForSearch(e.name);
    const altNorm = alts.length ? alts.map(normalizeForSearch).filter(Boolean).join(",") : null;
    const searchText = normalizeForSearch(
      [e.name, ...alts, e.region, e.subRegion ?? "", e.country].join(" "),
    );
    return {
      id: i + 1,
      country: e.country,
      region: e.region,
      subRegion: e.subRegion,
      appellationName: e.name,
      classificationSystem: e.classification || null,
      officialCode: e.code,
      alternateNames,
      continent: CONTINENTS[e.country] ?? "Other",
      level: levelOf(e),
      parentId: null,
      source: e.source,
      nameNorm,
      altNorm,
      searchText,
    };
  });

  // --- resolve parent links ---
  const containers = new Map<string, GazetteerRow>();
  for (const r of rows) {
    const k = dedupeKey(r.country, r.appellationName);
    const prev = containers.get(k);
    // prefer region/sub_region level rows as containers
    if (!prev || (prev.level === "appellation" && r.level !== "appellation")) containers.set(k, r);
  }
  for (const r of rows) {
    let parent: GazetteerRow | undefined;
    const hint = hints.get(r.id);
    if (hint) {
      parent = containers.get(dedupeKey(r.country, hint));
      if (parent?.id === r.id) parent = undefined;
    }
    if (!parent && r.subRegion && r.level !== "sub_region") {
      parent = containers.get(dedupeKey(r.country, r.subRegion));
      if (parent?.id === r.id) parent = undefined;
    }
    if (!parent && r.level !== "region") {
      parent = containers.get(dedupeKey(r.country, r.region));
      if (parent?.id === r.id) parent = undefined;
    }
    r.parentId = parent ? parent.id : null;
  }

  return rows;
}

let cache: GazetteerRow[] | null = null;
export function getGazetteerRows(): GazetteerRow[] {
  if (!cache) cache = buildRows();
  return cache;
}

export function getGazetteerSummary() {
  const rows = getGazetteerRows();
  const countries = new Set(rows.map((r) => r.country));
  const byClass = new Map<string, number>();
  for (const r of rows) byClass.set(r.classificationSystem ?? "—", (byClass.get(r.classificationSystem ?? "—") ?? 0) + 1);
  return { total: rows.length, countries: countries.size, byClass: Object.fromEntries(byClass) };
}
