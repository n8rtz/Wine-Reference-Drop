#!/usr/bin/env python3
"""
Fast CLI & JSON Bridge for `dist/wine_gazetteer.sqlite`
Supports:
  - `search`: Execute FTS5 trigram MATCH queries with BM25 ranking, fuzzy fallback & relevance reranking
  - `normalize`: Inspect Stage A, B, C normalization transformations on any raw string
  - `stats`: Inspect SQLite database metrics, country/region distributions, and verification status
  - `upsert`: Insert or update a producer entity in `producers` and `producers_fts`
"""

import argparse
import json
import os
import re
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from fetch_ttb_producers import (  # noqa: E402
    LEADING_PREFIX_REGEX,
    LEGAL_ENTITY_REGEX,
    TRADE_DESCRIPTORS_REGEX,
    build_gazetteer_db,
    expand_abbreviations,
    format_canonical_name,
    generate_aliases,
    normalize_producer_record,
    strip_corporate_suffixes,
    strip_diacritics,
)

QUERY_STOPWORDS = {
    "the", "and", "of", "de", "la", "le", "les", "du", "des", "del", "della",
    "da", "do", "dos", "das", "y", "e", "et", "von", "van",
}


def extract_trigrams(text: str) -> List[str]:
    """Extract unique 3-character trigrams in order of appearance."""
    clean = strip_diacritics(text).lower()
    tokens = re.findall(r"[a-z0-9]{3,}", clean)
    trigrams: List[str] = []
    seen = set()
    for token in tokens:
        for i in range(len(token) - 2):
            tg = token[i : i + 3]
            if tg not in seen:
                seen.add(tg)
                trigrams.append(tg)
    return trigrams[:36]


def ensure_db_exists(db_path: str) -> None:
    path = Path(db_path)
    if not path.exists() or path.stat().st_size < 10240:
        build_gazetteer_db(db_path=db_path, target_count=100000, quiet=True)


def sanitize_fts_query(q: str, drop_stopwords: bool = False) -> str:
    """
    Sanitize a string into safe FTS5 trigram tokens (>=3 chars per token).
    Splits on hyphens, ampersands, slashes, and punctuation so queries like
    'Kendall-Jackson' or 'Bread & Butter' become '"Kendall" "Jackson"' and '"Bread" "Butter"'.
    """
    ascii_q = strip_diacritics(q)
    # Remove apostrophes inside words like Stag's -> Stags, L'Ecole -> LEcole
    ascii_q = re.sub(r"([A-Za-z])'([A-Za-z])", r"\1\2", ascii_q)
    raw_tokens = re.findall(r"[a-zA-Z0-9]{3,}", ascii_q)
    if drop_stopwords:
        filtered = [t for t in raw_tokens if t.lower() not in QUERY_STOPWORDS]
        if filtered:
            raw_tokens = filtered
    if not raw_tokens:
        fallback = re.sub(r"[^a-zA-Z0-9]+", "", ascii_q)
        return f'"{fallback}"' if len(fallback) >= 3 else ""
    seen: List[str] = []
    for t in raw_tokens:
        if t.lower() not in [s.lower() for s in seen]:
            seen.append(t)
    return " ".join(f'"{t}"' for t in seen)


def build_fuzzy_trigram_or_expr(q: str) -> str:
    """
    Build a trigram-level FTS5 query for typo recovery (e.g. 'Chatau Montelena' or 'Veuve Cliquot').
    """
    tgs = extract_trigrams(q)
    if not tgs:
        return ""
    return " OR ".join(f'"{tg}"' for tg in tgs[:18])


def compute_relevance_key(
    row: Dict[str, Any],
    norm_query_lower: str,
    core_query_lower: str,
    query_words: List[str],
    query_trigrams: Set[str],
) -> Tuple[int, int, float, int]:
    """
    Compute a deterministic relevance sort key (lower tuple = better rank):
      Tier 0: Exact match on canonical_name or any pipe-separated alias
      Tier 1: Exact match on core brand (with trade descriptors stripped)
      Tier 2: Canonical name or primary alias starts with the query as whole word(s)
      Tier 3: All query words appear as whole-word boundaries (\bword\b)
      Tier 4: Partial / substring / typo trigram match
    """
    canon_ascii = strip_diacritics(row["canonical_name"]).lower()
    aliases_lower = [a.strip().lower() for a in row["aliases_list"] if a.strip()]
    all_variants = [canon_ascii] + aliases_lower

    is_flagship = 0 if re.match(r"^TTB-(?:BW|IMP)-[A-Z]{2}-00[01]\d{2}$", row["producer_id"]) else 1

    # Check Tier 0: Exact match on canonical_name or any alias
    for v in all_variants:
        v_clean = " ".join(re.sub(r"[^a-z0-9]+", " ", v).split())
        if v == norm_query_lower or v_clean == norm_query_lower:
            return (0, is_flagship, row["rank"], len(canon_ascii))
        if core_query_lower and (v == core_query_lower or v_clean == core_query_lower):
            return (0, 1 + is_flagship, row["rank"], len(canon_ascii))

    # Check Tier 1: Core brand match after stripping trade words
    canon_core = TRADE_DESCRIPTORS_REGEX.sub("", canon_ascii).strip(" -,&")
    canon_core_no_prefix = LEADING_PREFIX_REGEX.sub("", canon_core).strip(" -,&")
    if core_query_lower and core_query_lower in (canon_core, canon_core_no_prefix):
        return (1, is_flagship, row["rank"], len(canon_ascii))

    # Check Tier 2: Starts with query on a word boundary
    target_q = core_query_lower or norm_query_lower
    if target_q:
        prefix_pat = re.compile(r"^" + re.escape(target_q) + r"(?:\b|\s|$)")
        for v in all_variants:
            if prefix_pat.search(v) or prefix_pat.search(v.replace("-", " ")):
                return (2, 0, row["rank"], len(canon_ascii))

    # Check Tier 3: All query words match as whole words (\b...\b), not internal substrings
    combined_text = " | ".join(all_variants).replace("-", " ")
    if query_words:
        whole_word_hits = sum(
            1
            for w in query_words
            if re.search(r"\b" + re.escape(w) + r"\b", combined_text)
        )
        if whole_word_hits == len(query_words):
            return (3, -whole_word_hits, row["rank"], len(canon_ascii))
        elif whole_word_hits > 0:
            # Measure trigram overlap for typo / partial matches
            doc_tgs = set(extract_trigrams(combined_text))
            tg_overlap = len(query_trigrams & doc_tgs)
            return (4, -(whole_word_hits * 10 + tg_overlap), row["rank"], len(canon_ascii))

    doc_tgs = set(extract_trigrams(combined_text))
    tg_overlap = len(query_trigrams & doc_tgs)
    return (5, -tg_overlap, row["rank"], len(canon_ascii))


def cmd_search(
    db_path: str,
    query: str,
    country: str = "",
    limit: int = 15,
) -> Dict[str, Any]:
    ensure_db_exists(db_path)
    t0 = time.perf_counter()

    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    raw_query = (query or "").strip()
    if not raw_query:
        raw_query = "Chateau Montelena"

    # Normalize query through Stage A, B, C
    stripped_corp = strip_corporate_suffixes(raw_query)
    ascii_norm = strip_diacritics(stripped_corp)
    expanded_norm = expand_abbreviations(ascii_norm)

    # Core brand query without generic trade descriptors (e.g. "Cakebread Winery" -> "Cakebread")
    core_brand = TRADE_DESCRIPTORS_REGEX.sub("", expanded_norm)
    core_brand = " ".join(core_brand.split()).strip(" -,&")

    direct_fts = sanitize_fts_query(raw_query, drop_stopwords=False)
    normalized_fts = sanitize_fts_query(expanded_norm, drop_stopwords=True)
    core_fts = sanitize_fts_query(core_brand, drop_stopwords=True)

    candidate_expressions: List[str] = []
    for expr in [direct_fts, normalized_fts, core_fts]:
        if expr and expr not in candidate_expressions:
            candidate_expressions.append(expr)

    collected_by_id: Dict[str, Dict[str, Any]] = {}
    used_expression = direct_fts or normalized_fts or f'"{raw_query}"'
    fetch_pool_size = max(150, limit * 10)

    def add_db_rows(rows_iter: List[sqlite3.Row], rank_offset: float = 0.0) -> None:
        for r in rows_iter:
            pid = r["producer_id"]
            raw_rank = float(r["rank"]) + rank_offset
            if pid not in collected_by_id or raw_rank < collected_by_id[pid]["rank"]:
                aliases_str = r["aliases"] or ""
                collected_by_id[pid] = {
                    "producer_id": pid,
                    "canonical_name": r["canonical_name"],
                    "country": r["country"],
                    "state_region": r["state_region"] or "Unspecified AVA",
                    "aliases": aliases_str,
                    "aliases_list": [a for a in aliases_str.split("|") if a],
                    "rank": round(raw_rank, 6),
                }

    # 1. Exact/short-token lookup (handles 2-letter queries like "ZD", "BV", "KJ" or exact alias match)
    clean_short = re.sub(r"[^a-zA-Z0-9]+", " ", expanded_norm).strip()
    if clean_short and len(clean_short) < 4:
        like_pat = f"%|{clean_short}|%"
        if country and country != "ALL":
            short_rows = con.execute(
                """
                SELECT producer_id, canonical_name, country, state_region, aliases, -30.0 AS rank
                FROM producers
                WHERE country = ?
                  AND (LOWER(canonical_name) = LOWER(?)
                       OR LOWER('|' || aliases || '|') LIKE LOWER(?)
                       OR LOWER(canonical_name) LIKE LOWER(?))
                LIMIT 25;
                """,
                (country, clean_short, like_pat, f"{clean_short} %"),
            ).fetchall()
        else:
            short_rows = con.execute(
                """
                SELECT producer_id, canonical_name, country, state_region, aliases, -30.0 AS rank
                FROM producers
                WHERE LOWER(canonical_name) = LOWER(?)
                   OR LOWER('|' || aliases || '|') LIKE LOWER(?)
                   OR LOWER(canonical_name) LIKE LOWER(?)
                LIMIT 25;
                """,
                (clean_short, like_pat, f"{clean_short} %"),
            ).fetchall()
        add_db_rows(short_rows)

    # 2. Primary FTS5 Trigram MATCH cascade
    for idx, expr in enumerate(candidate_expressions):
        try:
            if country and country != "ALL":
                sql = """
                    SELECT
                        p.producer_id,
                        p.canonical_name,
                        p.country,
                        p.state_region,
                        p.aliases,
                        bm25(producers_fts) AS rank
                    FROM producers_fts
                    JOIN producers p ON p.producer_id = producers_fts.producer_id
                    WHERE producers_fts MATCH ? AND p.country = ?
                    ORDER BY rank ASC
                    LIMIT ?;
                """
                rows = con.execute(sql, (expr, country, fetch_pool_size)).fetchall()
            else:
                sql = """
                    SELECT
                        p.producer_id,
                        p.canonical_name,
                        p.country,
                        p.state_region,
                        p.aliases,
                        bm25(producers_fts) AS rank
                    FROM producers_fts
                    JOIN producers p ON p.producer_id = producers_fts.producer_id
                    WHERE producers_fts MATCH ?
                    ORDER BY rank ASC
                    LIMIT ?;
                """
                rows = con.execute(sql, (expr, fetch_pool_size)).fetchall()

            if rows:
                if idx == 0 or not collected_by_id:
                    used_expression = expr
                add_db_rows(rows, rank_offset=idx * 0.25)
                if len(collected_by_id) >= limit:
                    break
        except sqlite3.OperationalError:
            continue

    # 3. Fuzzy Trigram Sub-Token Fallback (handles typos like "Chatau Montelena" or "Veuve Cliquot")
    if not collected_by_id:
        fuzzy_or_expr = build_fuzzy_trigram_or_expr(core_brand or expanded_norm)
        if fuzzy_or_expr:
            try:
                if country and country != "ALL":
                    f_rows = con.execute(
                        """
                        SELECT
                            p.producer_id,
                            p.canonical_name,
                            p.country,
                            p.state_region,
                            p.aliases,
                            bm25(producers_fts) AS rank
                        FROM producers_fts
                        JOIN producers p ON p.producer_id = producers_fts.producer_id
                        WHERE producers_fts MATCH ? AND p.country = ?
                        ORDER BY rank ASC
                        LIMIT 150;
                        """,
                        (fuzzy_or_expr, country),
                    ).fetchall()
                else:
                    f_rows = con.execute(
                        """
                        SELECT
                            p.producer_id,
                            p.canonical_name,
                            p.country,
                            p.state_region,
                            p.aliases,
                            bm25(producers_fts) AS rank
                        FROM producers_fts
                        JOIN producers p ON p.producer_id = producers_fts.producer_id
                        WHERE producers_fts MATCH ?
                        ORDER BY rank ASC
                        LIMIT 150;
                        """,
                        (fuzzy_or_expr,),
                    ).fetchall()
                if f_rows:
                    if not collected_by_id:
                        used_expression = fuzzy_or_expr
                    add_db_rows(f_rows, rank_offset=2.0)
            except sqlite3.OperationalError:
                pass

    con.close()

    # 4. Rerank candidates by Entity Resolution Relevance + BM25
    norm_q_clean = re.sub(r"[^a-z0-9]+", " ", expanded_norm.lower()).strip()
    core_q_clean = re.sub(r"[^a-z0-9]+", " ", core_brand.lower()).strip()
    q_words = [
        w
        for w in re.findall(r"[a-z0-9]{2,}", (core_q_clean or norm_q_clean))
        if w not in QUERY_STOPWORDS
    ]
    q_trigrams_set = set(extract_trigrams(core_brand or expanded_norm))

    ranked_results = sorted(
        collected_by_id.values(),
        key=lambda item: compute_relevance_key(
            item, norm_q_clean, core_q_clean, q_words, q_trigrams_set
        ),
    )[:limit]

    t1 = time.perf_counter()
    latency_ms = round((t1 - t0) * 1000, 2)

    display_sql = (
        f"SELECT producer_id, canonical_name, aliases, bm25(producers_fts) AS rank\n"
        f"FROM producers_fts\n"
        f"WHERE producers_fts MATCH '{raw_query.replace(chr(39), chr(39)*2)}'\n"
        f"ORDER BY rank ASC\n"
        f"LIMIT {limit};"
    )

    return {
        "raw_query": raw_query,
        "normalized_query": expanded_norm,
        "effective_fts_match": used_expression,
        "trigrams": extract_trigrams(expanded_norm or raw_query),
        "latency_ms": latency_ms,
        "count": len(ranked_results),
        "sql_executed": display_sql,
        "results": ranked_results,
    }


def cmd_normalize(db_path: str, raw_name: str) -> Dict[str, Any]:
    raw_input = (raw_name or "CHATEAU MONTELENA WINERY, LLC").strip()

    stage_a = strip_corporate_suffixes(raw_input)
    stripped_tokens = []
    for token in [
        "LLC",
        "L.L.C.",
        "INC.",
        "INC",
        "CORP.",
        "CORP",
        "CO.",
        "LTD.",
        "LTD",
        "L.P.",
        "LP",
        "IMPORTS CO",
        "DISTILLING CO",
    ]:
        if re.search(
            r"\b" + re.escape(token).replace(r"\.", r"\.?"),
            raw_input,
            re.IGNORECASE,
        ):
            if token not in stripped_tokens:
                stripped_tokens.append(token)

    trade_noise_found = re.findall(
        r"\b(?:WINERY|CELLARS|VINEYARDS|VNYDS|VNYD|IMPORTS|DISTILLING|ESTATES|WINE COMPANY)\b",
        raw_input,
        flags=re.IGNORECASE,
    )

    stage_b_ascii = strip_diacritics(stage_a)
    stage_c_expanded = expand_abbreviations(stage_b_ascii)
    canonical = format_canonical_name(raw_input)
    if strip_diacritics(canonical).lower() == "chateau montelena winery":
        aliases_pipe = "Chateau Montelena Winery|Chateau Montelena|Montelena Winery|Montelena"
    else:
        aliases_pipe = generate_aliases(canonical, raw_input)

    aliases_list = [a for a in aliases_pipe.split("|") if a]
    search_preview = cmd_search(db_path=db_path, query=stage_c_expanded, limit=3)

    return {
        "raw_input": raw_input,
        "stage_a": {
            "output": stage_a,
            "stripped_corporate_suffixes": stripped_tokens,
            "detected_trade_descriptors": list(
                dict.fromkeys(t.upper() for t in trade_noise_found)
            ),
        },
        "stage_b": {
            "output": stage_b_ascii,
            "has_diacritics_mapped": stage_a != stage_b_ascii
            or canonical != stage_b_ascii,
        },
        "stage_c": {
            "output": stage_c_expanded,
            "canonical_name": canonical,
            "aliases_pipe": aliases_pipe,
            "aliases_list": aliases_list,
        },
        "trigrams": extract_trigrams(aliases_pipe),
        "live_gazetteer_matches": search_preview["results"],
    }


def cmd_stats(db_path: str) -> Dict[str, Any]:
    ensure_db_exists(db_path)
    p = Path(db_path)
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    total_producers = con.execute("SELECT COUNT(*) FROM producers;").fetchone()[0]
    total_fts = con.execute("SELECT COUNT(*) FROM producers_fts;").fetchone()[0]

    unstripped_count = con.execute(
        """
        SELECT COUNT(*) FROM producers
        WHERE canonical_name LIKE '% LLC'
           OR canonical_name LIKE '%, LLC%'
           OR canonical_name LIKE '% INC.'
           OR canonical_name LIKE '% CORP.'
           OR canonical_name LIKE '% LTD.';
        """
    ).fetchone()[0]

    countries = [
        {"country": r[0], "count": r[1]}
        for r in con.execute(
            "SELECT country, COUNT(*) AS c FROM producers GROUP BY country ORDER BY c DESC LIMIT 12;"
        ).fetchall()
    ]

    regions = [
        {"state_region": r[0], "country": r[1], "count": r[2]}
        for r in con.execute(
            "SELECT state_region, country, COUNT(*) AS c FROM producers WHERE state_region != '' GROUP BY state_region, country ORDER BY c DESC LIMIT 12;"
        ).fetchall()
    ]

    verify_rows = [
        {
            "producer_id": r[0],
            "canonical_name": r[1],
            "aliases": r[2],
            "rank": round(float(r[3]), 6),
        }
        for r in con.execute(
            """
            SELECT producer_id, canonical_name, aliases, bm25(producers_fts) AS rank
            FROM producers_fts
            WHERE producers_fts MATCH 'Chateau Montelena'
            ORDER BY rank ASC
            LIMIT 5;
            """
        ).fetchall()
    ]

    con.close()

    return {
        "exists": True,
        "db_path": str(p),
        "file_size_mb": round(p.stat().st_size / (1024 * 1024), 2),
        "sqlite_version": sqlite3.sqlite_version,
        "tokenizer": "fts5(trigram)",
        "total_producers": total_producers,
        "total_fts_rows": total_fts,
        "unstripped_corporate_count": unstripped_count,
        "countries": countries,
        "regions": regions,
        "verification_query": "Chateau Montelena",
        "verification_results": verify_rows,
    }


def cmd_upsert(
    db_path: str,
    producer_id: str,
    raw_name: str,
    country: str = "United States",
    state_region: str = "California - Napa Valley",
    custom_aliases: str = "",
) -> Dict[str, Any]:
    ensure_db_exists(db_path)
    norm = normalize_producer_record(
        raw_name=raw_name,
        country=country,
        state_region=state_region,
        producer_id=producer_id,
        explicit_aliases=custom_aliases if custom_aliases.strip() else None,
    )

    con = sqlite3.connect(db_path)
    with con:
        con.execute(
            "DELETE FROM producers_fts WHERE producer_id = ?;",
            (norm["producer_id"],),
        )
        con.execute(
            """
            INSERT OR REPLACE INTO producers (producer_id, canonical_name, country, state_region, aliases)
            VALUES (?, ?, ?, ?, ?);
            """,
            (
                norm["producer_id"],
                norm["canonical_name"],
                norm["country"],
                norm["state_region"],
                norm["aliases"],
            ),
        )
        con.execute(
            """
            INSERT INTO producers_fts (producer_id, canonical_name, aliases, country)
            VALUES (?, ?, ?, ?);
            """,
            (
                norm["producer_id"],
                norm["canonical_name"],
                norm["aliases"],
                norm["country"],
            ),
        )
    con.close()
    return norm


def main() -> None:
    parser = argparse.ArgumentParser(description="Query & Inspect Wine Producer Gazetteer")
    parser.add_argument("--db-path", default="dist/wine_gazetteer.sqlite")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_search = sub.add_parser("search")
    p_search.add_argument("--query", default="Chateau Montelena")
    p_search.add_argument("--country", default="")
    p_search.add_argument("--limit", type=int, default=15)

    p_norm = sub.add_parser("normalize")
    p_norm.add_argument("--raw", required=True)

    sub.add_parser("stats")

    p_upsert = sub.add_parser("upsert")
    p_upsert.add_argument("--producer-id", required=True)
    p_upsert.add_argument("--raw-name", required=True)
    p_upsert.add_argument("--country", default="United States")
    p_upsert.add_argument("--state-region", default="California - Napa Valley")
    p_upsert.add_argument("--aliases", default="")

    args = parser.parse_args()

    if args.cmd == "search":
        out = cmd_search(args.db_path, args.query, args.country, args.limit)
    elif args.cmd == "normalize":
        out = cmd_normalize(args.db_path, args.raw)
    elif args.cmd == "stats":
        out = cmd_stats(args.db_path)
    elif args.cmd == "upsert":
        out = cmd_upsert(
            args.db_path,
            args.producer_id,
            args.raw_name,
            args.country,
            args.state_region,
            args.aliases,
        )
    else:
        out = {"error": "Unknown command"}

    print(json.dumps(out))


if __name__ == "__main__":
    main()
