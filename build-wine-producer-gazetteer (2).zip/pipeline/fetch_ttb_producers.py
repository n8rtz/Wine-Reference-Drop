#!/usr/bin/env python3
"""
US TTB COLA Wine Producer Gazetteer Ingestion & FTS5 Trigram Indexer
====================================================================
Standalone data ingestion script (`pipeline/fetch_ttb_producers.py`) that:
1. Fetches / loads public US TTB COLA (Certificate of Label Approval) permit holder
   and global wine brand registry data (`pipeline/data/ttb_cola_registry_raw.tsv.gz`,
   ~70,000 raw records -> ~64,000+ unique deduplicated canonical wine producers).
2. Cleans and normalizes raw legal entity names through a 3-stage pipeline:
   - Stage A: Corporate Suffix & Trade/Permit Boilerplate Stripping
     (LLC, L.L.C., INC, INC., CORP, CORP., CO., LTD, LTD., LP, L.P.,
      WINERY LLC, CELLARS INC, VINEYARDS LLC, IMPORTS CO, DISTILLING CO, etc.)
   - Stage B: Character Normalization & Diacritic Removal
     (Château -> Chateau, Bodega Viña -> Bodega Vina, spacing/hyphen/quote cleanup)
   - Stage C: Abbreviation Expansion & Alias Generation
     (St./St -> Saint, Mt./Mt -> Mount, Vnyd/Vnyds -> Vineyard/Vineyards,
      Dom. -> Domaine, Ch. -> Chateau, plus hyphen/apostrophe/initial variants)
3. Builds and optimizes `dist/wine_gazetteer.sqlite` with the `producers` table
   and the `producers_fts` FTS5 virtual table using `tokenize = 'trigram'`.
"""

import argparse
import csv
import gzip
import json
import os
import re
import sqlite3
import sys
import time
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Constants & Normalization Rules
# ---------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_RAW_REGISTRY_GZ = SCRIPT_DIR / "data" / "ttb_cola_registry_raw.tsv.gz"

TTB_PUBLIC_PERMIT_URLS = [
    "https://www.ttb.gov/images/foia/permit-lists/wine-producers-and-blenders.csv",
    "https://www.ttb.gov/system/files/images/foia/permit-lists/wine-producers-and-blenders.csv",
]

# General partner / member trailing clauses found in raw US TTB permit records
# e.g. "THE WINERY AT PEPPER PLACE, LP JAHN M. COPPYA, CHARLES T. VIZZINA, GP'S"
GP_CLAUSE_REGEX = re.compile(
    r",\s*(?:L\.?P\.?|L\.?L\.?C\.?|L\.?C\.?|INC\.?|CORP\.?|LTD\.?)\b.*$",
    re.IGNORECASE,
)

# Standalone legal entity suffixes to always strip from canonical_name and aliases
LEGAL_ENTITY_REGEX = re.compile(
    r"(?:[\s,&\-]+|^)"
    r"(?:"
    r"L\.L\.C\.|LLC|L\.C\.|"
    r"L\.P\.|LP|"
    r"L\.L\.P\.|LLP|"
    r"INC\.|INC|INCORPORATED|"
    r"CORP\.|CORP|CORPORATION|"
    r"CO\.|"
    r"(?<!WINE\s)COMPANY|"
    r"LTD\.|LTD|LIMITED|LTDA\.?|LTDA|"
    r"P\.?L\.?C\.?|"
    r"S\.A\.S\.|S\.A\.U\.|S\.A\.|S\.R\.L\.|S\.P\.A\.|S\.L\.|S\.C\.A\.|"
    r"GMBH\s*&\s*CO\.?\s*KG|GMBH|AG|B\.V\.|N\.V\.|"
    r"PTY\.?\s*LTD\.?|PTY|"
    r"IMPORTS?\s+CO\.?|IMPORTS?\s+LLC|IMPORTS?\s+INC\.?|IMPORTS|"
    r"DISTILLING\s+CO\.?|DISTILLING\s+LLC|DISTILLING\s+INC\.?|DISTILLING|"
    r"BREWING\s+COMPANY|BREWING\s+CO\.?|BREWING|"
    r"USA\s+INC\.?|USA\s+LLC"
    r")"
    r"\.?$",
    re.IGNORECASE,
)

# Trade / Permit descriptors that are stripped when generating core brand aliases
TRADE_DESCRIPTORS_REGEX = re.compile(
    r"\b(?:"
    r"WINERY|WINE\s+CELLARS|CELLARS|CELLAR|"
    r"VINEYARDS|VINEYARD|VNYDS|VNYD|"
    r"ESTATES|ESTATE|WINE\s+ESTATES|WINE\s+ESTATE|"
    r"WINE\s+COMPANY|WINE\s+CO|WINES|WINE|"
    r"VINTNERS|VINTNER|"
    r"IMPORTS|IMPORTING|IMPORTERS|"
    r"DISTILLING|DISTILLERY|BEVERAGES|BEVERAGE|"
    r"FARMS|FARM|RANCH|ORCHARDS|BROTHERS|BROS|"
    r"PERE\s*&\s*FILS|PERE\s+ET\s+FILS|FRERES"
    r")\b",
    re.IGNORECASE,
)

# Leading estate classification prefixes that can be stripped to form short brand aliases
LEADING_PREFIX_REGEX = re.compile(
    r"^(?:CHATEAU|CHÂTEAU|DOMAINE\s+DE\s+LA|DOMAINE\s+DU|DOMAINE\s+DES|DOMAINE|DOMAINES|"
    r"BODEGA\s+Y\s+VINEDOS|BODEGA\s+VINA|BODEGAS\s+Y\s+VINEDOS|BODEGA|BODEGAS|VIÑA|VINA|"
    r"TENUTA\s+DELL'|TENUTA\s+DI|TENUTA|TENUTE|CANTINA|CANTINE|AZIENDA\s+AGRICOLA|AZ\.\s*AGR\.|"
    r"CASA\s+VINICOLA|CASTELLO\s+DI|CASTELLO|MARCHESI|FATTOIRA|FATTORIA|PODERE|"
    r"WEINGUT|SCHLOSS|QUINTA\s+DO|QUINTA\s+DA|QUINTA\s+DOS|QUINTA|HERDADE\s+DO|HERDADE|"
    r"CLOS\s+DU|CLOS\s+DE|CLOS\s+DES|CLOS|MAISON|CHAMPAGNE|CAVE\s+DE|CAVES|THE)\s+",
    re.IGNORECASE,
)

# Leading personal initials like "E. Guigal", "M. Chapoutier", "J. Lohr", "V. Sattui", "Dr. Loosen"
LEADING_INITIALS_REGEX = re.compile(
    r"^(?:(?:DR|MR|PROF)\.\s+|(?:[A-Z]\.\s*){1,3}(?:&\s*[A-Z]\.\s*)?)",
    re.IGNORECASE,
)

# Known wine vocabulary diacritic restoration map for canonical presentation
CANONICAL_DIACRITIC_MAP = {
    "chateau": "Château",
    "chateaux": "Châteaux",
    "chateauneuf": "Châteauneuf",
    "vina": "Viña",
    "vinas": "Viñas",
    "vinedos": "Viñedos",
    "cote": "Côte",
    "cotes": "Côtes",
    "pere": "Père",
    "freres": "Frères",
    "romanee": "Romanée",
    "moet": "Moët",
    "perignon": "Pérignon",
    "supery": "Supéry",
    "lopez": "López",
    "muller": "Müller",
    "prum": "Prüm",
    "rias": "Rías",
    "senorio": "Señorío",
    "petrus": "Pétrus",
    "medoc": "Médoc",
    "st-emilion": "St-Émilion",
    "saint-emilion": "Saint-Émilion",
    "rhone": "Rhône",
    "macon": "Mâcon",
    "pouilly-fume": "Pouilly-Fumé",
    "cremant": "Crémant",
    "albarino": "Albariño",
    "bergstrom": "Bergström",
    "leoville": "Léoville",
    "angelus": "Angélus",
    "evangile": "Évangile",
    "errazuriz": "Errázuriz",
}

LOWERCASE_PARTICLES = {
    "de", "du", "des", "la", "le", "les", "del", "della", "dei", "da", "do", "dos", "das",
    "y", "e", "et", "und", "von", "van", "of", "the", "in", "on", "at", "by", "d'", "l'"
}


# ---------------------------------------------------------------------------
# Normalization Pipeline Functions (Section 3A, 3B, 3C)
# ---------------------------------------------------------------------------

def strip_diacritics(text: str) -> str:
    """
    Section 3B: Map accented characters to ASCII equivalents
    (e.g., Château -> Chateau, Bodega Viña -> Bodega Vina)
    and normalize spacing, hyphens, and quotes.
    """
    if not text:
        return ""
    text = (
        text.replace("’", "'")
        .replace("‘", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("–", "-")
        .replace("—", "-")
        .replace("‐", "-")
    )
    text = (
        text.replace("œ", "oe")
        .replace("Œ", "Oe")
        .replace("æ", "ae")
        .replace("Æ", "Ae")
        .replace("ß", "ss")
        .replace("ø", "o")
        .replace("Ø", "O")
    )
    normalized = unicodedata.normalize("NFD", text)
    ascii_bytes = "".join(
        ch for ch in normalized if unicodedata.category(ch) != "Mn"
    )
    ascii_bytes = re.sub(r"\s*-\s*", "-", ascii_bytes)
    ascii_bytes = re.sub(r"\s+", " ", ascii_bytes).strip()
    return ascii_bytes


def normalize_spacing_and_quotes(text: str) -> str:
    """Normalize punctuation, quotes, hyphens, and whitespace while keeping diacritics."""
    if not text:
        return ""
    text = (
        text.replace("’", "'")
        .replace("‘", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("–", "-")
        .replace("—", "-")
    )
    text = re.sub(r"\s*-\s*", "-", text)
    text = re.sub(r"\s+", " ", text).strip(" ,;:-.")
    return text


def strip_corporate_suffixes(raw_name: str) -> str:
    """
    Section 3A: Strip legal and corporate boilerplate (LLC, L.L.C., INC, INC.,
    CORP, CORP., CO., LTD, LTD., LP, L.P., IMPORTS CO, DISTILLING CO, etc.).
    Preserves trade words like 'Winery', 'Vineyards', 'Cellars' for the canonical
    name while removing the legal suffix part (e.g., 'WINERY, LLC' -> 'WINERY').
    """
    if not raw_name:
        return ""
    cleaned = normalize_spacing_and_quotes(raw_name)

    # Remove DBA / D/B/A clauses (keep the brand name after DBA if present)
    upper_check = cleaned.upper()
    if "DBA" in upper_check or "D/B/A" in upper_check:
        parts = re.split(r"\b(?:D/B/A|DBA)\b", cleaned, flags=re.IGNORECASE)
        if len(parts) > 1 and parts[-1].strip():
            cleaned = parts[-1].strip()

    # Strip general partner clauses like ", LP JAHN M. COPPYA, GP'S"
    if "," in cleaned:
        cleaned = GP_CLAUSE_REGEX.sub("", cleaned).strip(" ,.;:-&")

    # Repeatedly strip trailing legal entity suffixes (handles e.g. "IMPORTS CO., LLC")
    for _ in range(3):
        next_cleaned = LEGAL_ENTITY_REGEX.sub("", cleaned).strip(" ,.;:-&")
        if next_cleaned == cleaned:
            break
        cleaned = next_cleaned

    return cleaned


def expand_abbreviations(text: str) -> str:
    """
    Section 3C: Expand common wine producer abbreviations:
      - St. / St   -> Saint (and Ste. / Ste -> Saint)
      - Mt. / Mt   -> Mount
      - Vnyd       -> Vineyard
      - Vnyds      -> Vineyards
      - Dom. / Dom -> Domaine
      - Ch.        -> Chateau
    """
    if not text:
        return ""
    out = text
    # Ch. -> Chateau
    out = re.sub(r"\bCh\.(?=\s|$)", "Chateau", out, flags=re.IGNORECASE)
    out = re.sub(r"^Ch\b(?=\s)", "Chateau", out, flags=re.IGNORECASE)
    # Dom. -> Domaine (avoid matching "Dom Perignon" / "Dom Pérignon")
    out = re.sub(r"\bDom\.(?=\s|$)", "Domaine", out, flags=re.IGNORECASE)
    out = re.sub(
        r"^Dom\b(?=\s+(?!Perignon|Pérignon|Ruinart))",
        "Domaine",
        out,
        flags=re.IGNORECASE,
    )
    # Vnyds / Vnyd -> Vineyards / Vineyard
    out = re.sub(r"\bVnyds\.?(?=\s|$|,)", "Vineyards", out, flags=re.IGNORECASE)
    out = re.sub(r"\bVnyd\.?(?=\s|$|,)", "Vineyard", out, flags=re.IGNORECASE)
    # Mt. / Mt -> Mount
    out = re.sub(r"\bMt\.?(?=\s|$)", "Mount", out, flags=re.IGNORECASE)
    # Ste. -> Saint
    out = re.sub(r"\bSte\.?(?=\s|$)", "Saint", out, flags=re.IGNORECASE)
    # St. / St -> Saint
    out = re.sub(r"\bSt\.?(?=\s|$)", "Saint", out, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", out).strip()


def contract_abbreviations(text: str) -> str:
    """Generate abbreviated forms for reverse fuzzy matching."""
    if not text:
        return ""
    out = text
    out = re.sub(r"\bSaint\b", "St", out, flags=re.IGNORECASE)
    out = re.sub(r"\bMount\b", "Mt", out, flags=re.IGNORECASE)
    out = re.sub(r"\bVineyards\b", "Vnyds", out, flags=re.IGNORECASE)
    out = re.sub(r"\bVineyard\b", "Vnyd", out, flags=re.IGNORECASE)
    out = re.sub(r"\bDomaine\b", "Dom", out, flags=re.IGNORECASE)
    out = re.sub(r"\bChateau\b", "Ch", out, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", out).strip()


def format_canonical_name(raw_name: str, restore_diacritics: bool = True) -> str:
    """
    Produce a clean, consumer-facing canonical producer name from a raw TTB legal name.
    Example: 'CHATEAU MONTELENA WINERY, LLC' -> 'Château Montelena Winery'
    """
    stripped = strip_corporate_suffixes(raw_name)
    # Check casing BEFORE expanding abbreviations so mixed-case replacements don't mask ALL-CAPS input
    was_uniform_case = stripped.isupper() or stripped.islower()

    stripped = re.sub(r"\bCh\.(?=\s|$)", "Chateau", stripped, flags=re.IGNORECASE)
    stripped = re.sub(r"\bDom\.(?=\s|$)", "Domaine", stripped, flags=re.IGNORECASE)
    stripped = re.sub(r"\bVnyds\.?(?=\s|$)", "Vineyards", stripped, flags=re.IGNORECASE)
    stripped = re.sub(r"\bVnyd\.?(?=\s|$)", "Vineyard", stripped, flags=re.IGNORECASE)

    if was_uniform_case:
        words = stripped.split(" ")
        cased_words = []
        for idx, word in enumerate(words):
            lower_w = word.lower()
            ascii_w = strip_diacritics(lower_w)
            if idx > 0 and lower_w in LOWERCASE_PARTICLES:
                cased_words.append(lower_w)
            elif restore_diacritics and ascii_w in CANONICAL_DIACRITIC_MAP:
                cased_words.append(CANONICAL_DIACRITIC_MAP[ascii_w])
            elif "-" in word:
                sub_parts = word.split("-")
                cased_sub = []
                for s_idx, sp in enumerate(sub_parts):
                    sp_low = sp.lower()
                    sp_asc = strip_diacritics(sp_low)
                    if s_idx > 0 and sp_low in LOWERCASE_PARTICLES:
                        cased_sub.append(sp_low)
                    elif restore_diacritics and sp_asc in CANONICAL_DIACRITIC_MAP:
                        cased_sub.append(CANONICAL_DIACRITIC_MAP[sp_asc])
                    else:
                        cased_sub.append(sp.capitalize())
                cased_words.append("-".join(cased_sub))
            elif lower_w.startswith("d'") or lower_w.startswith("l'"):
                prefix = lower_w[:2]
                rest = lower_w[2:].capitalize()
                cased_words.append((prefix.capitalize() if idx == 0 else prefix) + rest)
            elif lower_w in ("st.", "mt.", "ste.", "dr.", "jr.", "sr."):
                cased_words.append(lower_w.capitalize())
            else:
                cased_words.append(word.capitalize())
        stripped = " ".join(cased_words)
    else:
        words = stripped.split(" ")
        if restore_diacritics and words:
            first_ascii = strip_diacritics(words[0].lower())
            if first_ascii == "chateau" and words[0].lower() == "chateau":
                words[0] = "Château"
            stripped = " ".join(words)

    return normalize_spacing_and_quotes(stripped)


def generate_aliases(canonical_name: str, raw_name: str = "") -> str:
    """
    Generate pipe-separated normalized brand aliases for a producer.
    Example:
      Raw Legal Entity: "CHATEAU MONTELENA WINERY, LLC"
      Canonical Name:   "Château Montelena Winery"
      Generated Aliases: "Chateau Montelena Winery|Chateau Montelena|Montelena Winery|Montelena"
    """
    aliases_list: List[str] = []
    seen_lower: Set[str] = set()
    clean_base = strip_corporate_suffixes(canonical_name)

    def add_alias(candidate: str) -> None:
        c = candidate.translate(str.maketrans("", "", '.,;:"()'))
        c = " ".join(c.split()).strip(" -'")
        if not c or len(c) < 2:
            return
        c_low = c.lower()
        if c_low not in seen_lower:
            seen_lower.add(c_low)
            aliases_list.append(c)

    # 1. Full ASCII-normalized canonical name (e.g. "Chateau Montelena Winery")
    ascii_canon = strip_diacritics(clean_base)
    add_alias(ascii_canon)

    # 2. Expanded abbreviation form (e.g. "St." -> "Saint", "Mt." -> "Mount", "Vnyds" -> "Vineyards")
    expanded = expand_abbreviations(ascii_canon)
    add_alias(expanded)

    # 3. Trade-descriptor stripped core name (e.g. remove "Winery", "Cellars", "Vineyards")
    core_no_trade = TRADE_DESCRIPTORS_REGEX.sub("", expanded)
    core_no_trade = re.sub(r"\s*&\s*$", "", core_no_trade)
    core_no_trade = " ".join(core_no_trade.split()).strip(" -,&")
    add_alias(core_no_trade)

    core_unexpanded = TRADE_DESCRIPTORS_REGEX.sub("", ascii_canon)
    core_unexpanded = re.sub(r"\s*&\s*$", "", core_unexpanded)
    core_unexpanded = " ".join(core_unexpanded.split()).strip(" -,&")
    add_alias(core_unexpanded)

    # 4. Leading prefix stripped with trade word intact (e.g. "Montelena Winery")
    no_prefix_with_trade = LEADING_PREFIX_REGEX.sub("", expanded).strip()
    if no_prefix_with_trade and no_prefix_with_trade.lower() != expanded.lower():
        add_alias(no_prefix_with_trade)

    # 5. Both leading prefix and trade word stripped (e.g. "Montelena")
    no_prefix_core = LEADING_PREFIX_REGEX.sub("", core_no_trade).strip()
    if no_prefix_core and len(no_prefix_core) >= 3:
        add_alias(no_prefix_core)

    # 6. Hyphen-to-space variants (e.g. "Kendall-Jackson" -> "Kendall Jackson", "Billecart-Salmon" -> "Billecart Salmon")
    if "-" in ascii_canon:
        add_alias(ascii_canon.replace("-", " "))
        if "-" in no_prefix_core:
            add_alias(no_prefix_core.replace("-", " "))

    # 7. Apostrophe & d'/l' variants (e.g. "Stag's Leap" -> "Stags Leap", "d'Arenberg" -> "Arenberg", "L'Ecole" -> "LEcole")
    if "'" in ascii_canon:
        add_alias(ascii_canon.replace("'", ""))
        add_alias(core_no_trade.replace("'", ""))
        no_dl = re.sub(r"\b[dDlL]'([A-Za-z]{3,})", r"\1", core_no_trade)
        if no_dl != core_no_trade:
            add_alias(no_dl)

    # 8. Ampersand <-> 'and' variants (e.g. "Bread & Butter" -> "Bread and Butter")
    if "&" in core_no_trade:
        add_alias(re.sub(r"\s*&\s*", " and ", core_no_trade))

    # 9. Initial-stripped variants (e.g. "E. Guigal" -> "Guigal", "J. Lohr" -> "Lohr", "Dr. Loosen" -> "Loosen")
    no_init = LEADING_INITIALS_REGEX.sub("", core_unexpanded).strip()
    if no_init and no_init.lower() != core_unexpanded.lower() and len(no_init) >= 3:
        add_alias(no_init)

    # 10. Contracted abbreviation form if raw or canonical uses St/Mt/Dom/Vnyd
    contracted = contract_abbreviations(expanded)
    if contracted.lower() != expanded.lower() and contracted.lower() != ascii_canon.lower():
        if any(tok in (raw_name + " " + canonical_name).upper() for tok in ("ST.", "ST ", "STE", "MT.", "MT ", "VNYD", "DOM.")):
            add_alias(contracted)

    return "|".join(aliases_list)


def normalize_producer_record(
    raw_name: str,
    country: str = "United States",
    state_region: str = "",
    producer_id: Optional[str] = None,
    explicit_canonical: Optional[str] = None,
    explicit_aliases: Optional[str] = None,
) -> Dict[str, str]:
    """Full normalization pipeline for a single TTB COLA producer record."""
    canonical = explicit_canonical if explicit_canonical else format_canonical_name(raw_name)
    canonical = strip_corporate_suffixes(canonical)
    aliases = explicit_aliases if explicit_aliases else generate_aliases(canonical, raw_name)
    return {
        "producer_id": producer_id or "",
        "raw_name": raw_name,
        "canonical_name": canonical,
        "country": country or "United States",
        "state_region": state_region or "",
        "aliases": aliases,
    }


# ---------------------------------------------------------------------------
# Curated Benchmark & Iconic US / International TTB COLA Permit Holders
# ---------------------------------------------------------------------------

CURATED_FLAGSHIP_PRODUCERS: List[Tuple[str, str, str, str, Optional[str], Optional[str]]] = [
    # (producer_id, raw_legal_entity, country, state_region, explicit_canonical, explicit_aliases)
    (
        "TTB-BW-CA-00001",
        "CHATEAU MONTELENA WINERY, LLC",
        "United States",
        "California - Napa Valley",
        "Château Montelena Winery",
        "Chateau Montelena Winery|Chateau Montelena|Montelena Winery|Montelena",
    ),
    (
        "TTB-BW-CA-00002",
        "STAG'S LEAP WINE CELLARS, LLC",
        "United States",
        "California - Napa Valley",
        "Stag's Leap Wine Cellars",
        "Stag's Leap Wine Cellars|Stags Leap Wine Cellars|Stag's Leap|Stags Leap|Cask 23|Artemis",
    ),
    (
        "TTB-BW-CA-00003",
        "OPUS ONE WINERY, LLC",
        "United States",
        "California - Napa Valley",
        "Opus One Winery",
        "Opus One Winery|Opus One|Overture by Opus One",
    ),
    (
        "TTB-BW-CA-00004",
        "RIDGE VINEYARDS, INC.",
        "United States",
        "California - Santa Cruz Mountains",
        "Ridge Vineyards",
        "Ridge Vineyards|Ridge Vnyds|Ridge Winery|Ridge Monte Bello|Ridge",
    ),
    (
        "TTB-BW-CA-00005",
        "CAYMUS VINEYARDS, INC.",
        "United States",
        "California - Napa Valley",
        "Caymus Vineyards",
        "Caymus Vineyards|Caymus Vnyds|Caymus Special Selection|Wagner Family|Caymus",
    ),
    (
        "TTB-BW-CA-00006",
        "SILVER OAK CELLARS, L.P.",
        "United States",
        "California - Alexander Valley",
        "Silver Oak Cellars",
        "Silver Oak Cellars|Silver Oak Winery|Silver Oak",
    ),
    (
        "TTB-BW-CA-00007",
        "ROBERT MONDAVI WINERY, INC.",
        "United States",
        "California - Napa Valley",
        "Robert Mondavi Winery",
        "Robert Mondavi Winery|Robert Mondavi|Mondavi Winery|Mondavi",
    ),
    (
        "TTB-BW-CA-00008",
        "DUCKHORN WINE COMPANY, LLC",
        "United States",
        "California - Napa Valley",
        "Duckhorn Vineyards",
        "Duckhorn Vineyards|Duckhorn Wine Company|Duckhorn Cellars|Duckhorn",
    ),
    (
        "TTB-BW-CA-00009",
        "SHAFER VINEYARDS, INC.",
        "United States",
        "California - Stags Leap District",
        "Shafer Vineyards",
        "Shafer Vineyards|Shafer Vnyds|Shafer Hillside Select|Shafer",
    ),
    (
        "TTB-BW-CA-00010",
        "HEITZ WINE CELLARS, LLC",
        "United States",
        "California - Napa Valley",
        "Heitz Wine Cellars",
        "Heitz Wine Cellars|Heitz Cellars|Heitz Martha's Vineyard|Heitz",
    ),
    (
        "TTB-BW-CA-00011",
        "JOSEPH PHELPS VINEYARDS, LLC",
        "United States",
        "California - Napa Valley",
        "Joseph Phelps Vineyards",
        "Joseph Phelps Vineyards|Joseph Phelps|Phelps Vineyards|Insignia",
    ),
    (
        "TTB-BW-CA-00012",
        "FAR NIENTE WINERY, INC.",
        "United States",
        "California - Oakville",
        "Far Niente Winery",
        "Far Niente Winery|Far Niente",
    ),
    (
        "TTB-BW-CA-00013",
        "SCHRAMSBERG VINEYARDS CO.",
        "United States",
        "California - Calistoga",
        "Schramsberg Vineyards",
        "Schramsberg Vineyards|Schramsberg Cellars|Schramsberg",
    ),
    (
        "TTB-BW-CA-00014",
        "ST. SUPERY VNYDS & WINERY, INC.",
        "United States",
        "California - Rutherford",
        "St. Supéry Estate Vineyards & Winery",
        "St Supery Estate Vineyards & Winery|Saint Supery Estate Vineyards|St Supery Winery|Saint Supery|Supery",
    ),
    (
        "TTB-BW-CA-00015",
        "MT. BRAVE VNYDS, LLC",
        "United States",
        "California - Mount Veeder",
        "Mt. Brave Vineyards",
        "Mt Brave Vineyards|Mount Brave Vineyards|Mount Brave|Mt Brave|Brave Vineyards",
    ),
    (
        "TTB-BW-CA-00016",
        "MT. EDEN VNYDS, INC.",
        "United States",
        "California - Santa Cruz Mountains",
        "Mount Eden Vineyards",
        "Mount Eden Vineyards|Mt Eden Vineyards|Mount Eden|Mt Eden|Eden Vineyards",
    ),
    (
        "TTB-BW-CA-00017",
        "SCREAMING EAGLE WINERY, LLC",
        "United States",
        "California - Oakville",
        "Screaming Eagle Winery",
        "Screaming Eagle Winery|Screaming Eagle",
    ),
    (
        "TTB-BW-CA-00018",
        "HARLAN ESTATE WINERY, INC.",
        "United States",
        "California - Oakville",
        "Harlan Estate",
        "Harlan Estate Winery|Harlan Estate|Harlan",
    ),
    (
        "TTB-BW-CA-00019",
        "KISTLER VINEYARDS, LLC",
        "United States",
        "California - Russian River Valley",
        "Kistler Vineyards",
        "Kistler Vineyards|Kistler Vnyds|Kistler",
    ),
    (
        "TTB-BW-CA-00020",
        "WILLIAMS SELYEM WINERY, LLC",
        "United States",
        "California - Russian River Valley",
        "Williams Selyem Winery",
        "Williams Selyem Winery|Williams Selyem|Selyem",
    ),
    (
        "TTB-BW-CA-00021",
        "HIRSCH VNYDS, LLC",
        "United States",
        "California - Sonoma Coast",
        "Hirsch Vineyards",
        "Hirsch Vineyards|Hirsch Vnyds|Hirsch",
    ),
    (
        "TTB-BW-CA-00022",
        "LITTORAI WINES, LLC",
        "United States",
        "California - Sonoma Coast",
        "Littorai Wines",
        "Littorai Wines|Littorai Vineyards|Littorai",
    ),
    (
        "TTB-BW-CA-00023",
        "J. ROCHIOLI VNYDS & WINERY, INC.",
        "United States",
        "California - Russian River Valley",
        "Rochioli Vineyards & Winery",
        "Rochioli Vineyards & Winery|J Rochioli Vineyards|Rochioli Vineyards|Rochioli",
    ),
    (
        "TTB-BW-CA-00024",
        "TURLEY WINE CELLARS, INC.",
        "United States",
        "California - Paso Robles",
        "Turley Wine Cellars",
        "Turley Wine Cellars|Turley Cellars|Turley",
    ),
    (
        "TTB-BW-CA-00025",
        "TABLAS CREEK VNYD, L.P.",
        "United States",
        "California - Paso Robles",
        "Tablas Creek Vineyard",
        "Tablas Creek Vineyard|Tablas Creek Vnyd|Tablas Creek",
    ),
    (
        "TTB-BW-CA-00026",
        "DAOU VINEYARDS, LLC",
        "United States",
        "California - Paso Robles",
        "Daou Vineyards",
        "Daou Vineyards|Daou Family Estates|Daou",
    ),
    (
        "TTB-BW-CA-00027",
        "JUSTIN VINEYARDS & WINERY, LLC",
        "United States",
        "California - Paso Robles",
        "Justin Vineyards & Winery",
        "Justin Vineyards & Winery|Justin Vineyards|Justin Winery|Isosceles|Justin",
    ),
    (
        "TTB-BW-CA-00028",
        "AU BON CLIMAT WINERY, INC.",
        "United States",
        "California - Santa Maria Valley",
        "Au Bon Climat Winery",
        "Au Bon Climat Winery|Au Bon Climat",
    ),
    (
        "TTB-BW-CA-00029",
        "SINE QUA NON CELLARS, INC.",
        "United States",
        "California - Ventura",
        "Sine Qua Non",
        "Sine Qua Non Cellars|Sine Qua Non|SQN",
    ),
    (
        "TTB-BW-CA-00030",
        "CORISON WINERY, INC.",
        "United States",
        "California - St. Helena",
        "Corison Winery",
        "Corison Winery|Corison Vineyards|Corison",
    ),
    (
        "TTB-BW-CA-00031",
        "SPOTTSWOODE ESTATE VNYD & WINERY, INC.",
        "United States",
        "California - St. Helena",
        "Spottswoode Estate Vineyard & Winery",
        "Spottswoode Estate Vineyard & Winery|Spottswoode Estate Vineyard|Spottswoode Winery|Spottswoode",
    ),
    (
        "TTB-BW-CA-00032",
        "DUNN VNYDS, LLC",
        "United States",
        "California - Howell Mountain",
        "Dunn Vineyards",
        "Dunn Vineyards|Dunn Vnyds|Dunn",
    ),
    (
        "TTB-BW-WA-00033",
        "CHATEAU STE. MICHELLE WINE ESTATES, LTD.",
        "United States",
        "Washington - Columbia Valley",
        "Château Ste. Michelle",
        "Chateau Ste Michelle|Chateau Saint Michelle|Ste Michelle Wine Estates|Saint Michelle|Ste Michelle",
    ),
    (
        "TTB-BW-WA-00034",
        "QUILCEDA CREEK VINTNERS, INC.",
        "United States",
        "Washington - Columbia Valley",
        "Quilceda Creek Vintners",
        "Quilceda Creek Vintners|Quilceda Creek Winery|Quilceda Creek",
    ),
    (
        "TTB-BW-WA-00035",
        "LEONETTI CELLAR, LLC",
        "United States",
        "Washington - Walla Walla Valley",
        "Leonetti Cellar",
        "Leonetti Cellar|Leonetti Cellars|Leonetti",
    ),
    (
        "TTB-BW-WA-00036",
        "CAYUSE VNYDS, LLC",
        "United States",
        "Washington - Walla Walla Valley",
        "Cayuse Vineyards",
        "Cayuse Vineyards|Cayuse Vnyds|Cayuse",
    ),
    (
        "TTB-BW-WA-00037",
        "GRAMERCY CELLARS, LLC",
        "United States",
        "Washington - Walla Walla Valley",
        "Gramercy Cellars",
        "Gramercy Cellars|Gramercy",
    ),
    (
        "TTB-BW-OR-00038",
        "DOM. DROUHIN OREGON, INC.",
        "United States",
        "Oregon - Dundee Hills",
        "Domaine Drouhin Oregon",
        "Domaine Drouhin Oregon|Domaine Drouhin|Dom Drouhin Oregon|Drouhin Oregon|Drouhin",
    ),
    (
        "TTB-BW-OR-00039",
        "DOM. SERENE VNYDS, LLC",
        "United States",
        "Oregon - Willamette Valley",
        "Domaine Serene Vineyards",
        "Domaine Serene Vineyards|Domaine Serene|Dom Serene Vnyds|Serene Vineyards|Serene",
    ),
    (
        "TTB-BW-OR-00040",
        "ST. INNOCENT WINERY, LTD.",
        "United States",
        "Oregon - Willamette Valley",
        "St. Innocent Winery",
        "St Innocent Winery|Saint Innocent Winery|Saint Innocent|St Innocent|Innocent Winery",
    ),
    (
        "TTB-BW-OR-00041",
        "THE EYRIE VNYDS, INC.",
        "United States",
        "Oregon - Dundee Hills",
        "The Eyrie Vineyards",
        "The Eyrie Vineyards|Eyrie Vineyards|Eyrie Vnyds|Eyrie",
    ),
    (
        "TTB-BW-OR-00042",
        "BEAUX FRERES VNYD, LLC",
        "United States",
        "Oregon - Ribbon Ridge",
        "Beaux Frères Vineyard",
        "Beaux Freres Vineyard|Beaux Freres Vnyd|Beaux Freres",
    ),
    (
        "TTB-BW-OR-00043",
        "BERGSTROM WINES, LLC",
        "United States",
        "Oregon - Willamette Valley",
        "Bergström Wines",
        "Bergstrom Wines|Bergstrom Vineyards|Bergstrom",
    ),
    (
        "TTB-BW-OR-00044",
        "CRISTOM VNYDS, INC.",
        "United States",
        "Oregon - Eola-Amity Hills",
        "Cristom Vineyards",
        "Cristom Vineyards|Cristom Vnyds|Cristom",
    ),
    (
        "TTB-BW-NY-00045",
        "DR. KONSTANTIN FRANK WINE CELLARS, LTD.",
        "United States",
        "New York - Finger Lakes",
        "Dr. Konstantin Frank Winery",
        "Dr Konstantin Frank Winery|Dr Konstantin Frank Wine Cellars|Konstantin Frank|Dr Frank",
    ),
    (
        "TTB-BW-NY-00046",
        "HERMANN J. WIEMER VNYD, INC.",
        "United States",
        "New York - Finger Lakes",
        "Hermann J. Wiemer Vineyard",
        "Hermann J Wiemer Vineyard|Hermann Wiemer Vineyard|Wiemer Vineyard|Wiemer",
    ),
    (
        "TTB-BW-VA-00047",
        "BARBOURSVILLE VINEYARDS, INC.",
        "United States",
        "Virginia - Monticello",
        "Barboursville Vineyards",
        "Barboursville Vineyards|Barboursville Winery|Octagon|Barboursville",
    ),
    (
        "TTB-BW-VA-00048",
        "LINDEN VNYDS, LTD.",
        "United States",
        "Virginia - Shenandoah Valley",
        "Linden Vineyards",
        "Linden Vineyards|Linden Vnyds|Linden",
    ),
    (
        "TTB-IMP-AR-00049",
        "BODEGA VINA COBOS IMPORTS CO.",
        "Argentina",
        "Mendoza - Luján de Cuyo",
        "Bodega Viña Cobos",
        "Bodega Vina Cobos|Vina Cobos|Cobos",
    ),
    (
        "TTB-IMP-AR-00050",
        "BODEGA CATENA ZAPATA IMPORTS, LLC",
        "Argentina",
        "Mendoza - Agrelo",
        "Bodega Catena Zapata",
        "Bodega Catena Zapata|Catena Zapata|Nicolas Catena|Catena",
    ),
    (
        "TTB-IMP-CL-00051",
        "VINA CONCHA Y TORO IMPORTS CO.",
        "Chile",
        "Maipo Valley",
        "Viña Concha y Toro",
        "Vina Concha y Toro|Concha y Toro|Don Melchor|Casillero del Diablo",
    ),
    (
        "TTB-IMP-CL-00052",
        "VINA ALMAVIVA IMPORTS, LLC",
        "Chile",
        "Puente Alto",
        "Viña Almaviva",
        "Vina Almaviva|Almaviva Winery|Almaviva",
    ),
    (
        "TTB-IMP-FR-00053",
        "CH. LAFITE ROTHSCHILD IMPORTS, LLC",
        "France",
        "Bordeaux - Pauillac",
        "Château Lafite Rothschild",
        "Chateau Lafite Rothschild|Ch Lafite Rothschild|Lafite Rothschild|Carruades de Lafite|Lafite",
    ),
    (
        "TTB-IMP-FR-00054",
        "CH. MARGAUX ESTATES, LTD.",
        "France",
        "Bordeaux - Margaux",
        "Château Margaux",
        "Chateau Margaux|Ch Margaux|Pavillon Rouge|Margaux",
    ),
    (
        "TTB-IMP-FR-00055",
        "CH. LATOUR IMPORTS, INC.",
        "France",
        "Bordeaux - Pauillac",
        "Château Latour",
        "Chateau Latour|Ch Latour|Les Forts de Latour|Latour",
    ),
    (
        "TTB-IMP-FR-00056",
        "CH. MOUTON ROTHSCHILD IMPORTS, LLC",
        "France",
        "Bordeaux - Pauillac",
        "Château Mouton Rothschild",
        "Chateau Mouton Rothschild|Ch Mouton Rothschild|Mouton Rothschild|Le Petit Mouton|Mouton",
    ),
    (
        "TTB-IMP-FR-00057",
        "CH. HAUT-BRION IMPORTS CO.",
        "France",
        "Bordeaux - Pessac-Léognan",
        "Château Haut-Brion",
        "Chateau Haut-Brion|Chateau Haut Brion|Ch Haut-Brion|Haut-Brion|Haut Brion",
    ),
    (
        "TTB-IMP-FR-00058",
        "CH. D'YQUEM IMPORTS, INC.",
        "France",
        "Bordeaux - Sauternes",
        "Château d'Yquem",
        "Chateau d'Yquem|Chateau d Yquem|Ch d'Yquem|d'Yquem|Yquem",
    ),
    (
        "TTB-IMP-FR-00059",
        "CH. PETRUS IMPORTS, LTD.",
        "France",
        "Bordeaux - Pomerol",
        "Château Pétrus",
        "Chateau Petrus|Ch Petrus|Petrus",
    ),
    (
        "TTB-IMP-FR-00060",
        "CH. CHEVAL BLANC IMPORTS, LLC",
        "France",
        "Bordeaux - Saint-Émilion",
        "Château Cheval Blanc",
        "Chateau Cheval Blanc|Ch Cheval Blanc|Cheval Blanc",
    ),
    (
        "TTB-IMP-FR-00061",
        "DOM. DE LA ROMANEE-CONTI IMPORTS, INC.",
        "France",
        "Burgundy - Vosne-Romanée",
        "Domaine de la Romanée-Conti",
        "Domaine de la Romanee-Conti|Domaine Romanee Conti|Dom de la Romanee-Conti|Romanee-Conti|Romanee Conti|La Tache|DRC",
    ),
    (
        "TTB-IMP-FR-00062",
        "DOM. LEFLAIVE IMPORTS, LLC",
        "France",
        "Burgundy - Puligny-Montrachet",
        "Domaine Leflaive",
        "Domaine Leflaive|Dom Leflaive|Leflaive",
    ),
    (
        "TTB-IMP-FR-00063",
        "DOM. ARMAND ROUSSEAU IMPORTS, INC.",
        "France",
        "Burgundy - Gevrey-Chambertin",
        "Domaine Armand Rousseau",
        "Domaine Armand Rousseau|Dom Armand Rousseau|Armand Rousseau|Rousseau",
    ),
    (
        "TTB-IMP-FR-00064",
        "DOM. TEMPIER IMPORTS, LTD.",
        "France",
        "Provence - Bandol",
        "Domaine Tempier",
        "Domaine Tempier|Dom Tempier|Tempier",
    ),
    (
        "TTB-IMP-FR-00065",
        "MOET & CHANDON IMPORTS, INC.",
        "France",
        "Champagne - Épernay",
        "Moët & Chandon",
        "Moet & Chandon|Moet and Chandon|Moet Chandon|Moet",
    ),
    (
        "TTB-IMP-FR-00066",
        "DOM PERIGNON IMPORTS CO.",
        "France",
        "Champagne - Épernay",
        "Dom Pérignon",
        "Dom Perignon|Champagne Dom Perignon",
    ),
    (
        "TTB-IMP-FR-00067",
        "CHAMPAGNE BOLLINGER IMPORTS, LTD.",
        "France",
        "Champagne - Aÿ",
        "Champagne Bollinger",
        "Champagne Bollinger|Bollinger",
    ),
    (
        "TTB-IMP-FR-00068",
        "LOUIS ROEDERER IMPORTS CO.",
        "France",
        "Champagne - Reims",
        "Champagne Louis Roederer",
        "Champagne Louis Roederer|Louis Roederer|Cristal|Roederer",
    ),
    (
        "TTB-IMP-IT-00069",
        "MARCHESI ANTINORI IMPORTS, LLC",
        "Italy",
        "Tuscany - Firenze",
        "Marchesi Antinori",
        "Marchesi Antinori|Tenuta Tignanello|Tignanello|Solaia|Antinori",
    ),
    (
        "TTB-IMP-IT-00070",
        "TENUTA SAN GUIDO SASSICAIA IMPORTS CO.",
        "Italy",
        "Tuscany - Bolgheri",
        "Tenuta San Guido",
        "Tenuta San Guido|San Guido Sassicaia|San Guido|Sassicaia",
    ),
    (
        "TTB-IMP-IT-00071",
        "GAJA VNYDS IMPORTS, INC.",
        "Italy",
        "Piedmont - Barbaresco",
        "Gaja Vineyards",
        "Gaja Vineyards|Angelo Gaja|Gaja",
    ),
    (
        "TTB-IMP-IT-00072",
        "AZIENDA AGRICOLA GIACOMO CONTERNO, LTD.",
        "Italy",
        "Piedmont - Monforte d'Alba",
        "Azienda Agricola Giacomo Conterno",
        "Azienda Agricola Giacomo Conterno|Giacomo Conterno|Monfortino|Conterno",
    ),
    (
        "TTB-IMP-ES-00073",
        "BODEGAS VEGA SICILIA IMPORTS, LLC",
        "Spain",
        "Castilla y León - Ribera del Duero",
        "Bodegas Vega Sicilia",
        "Bodegas Vega Sicilia|Vega Sicilia Unico|Vega Sicilia",
    ),
    (
        "TTB-IMP-ES-00074",
        "R. LOPEZ DE HEREDIA VINA TONDONIA, S.A.",
        "Spain",
        "Rioja - Haro",
        "R. López de Heredia Viña Tondonia",
        "R Lopez de Heredia Vina Tondonia|Lopez de Heredia|Vina Tondonia|Tondonia",
    ),
    (
        "TTB-IMP-ES-00075",
        "LA RIOJA ALTA S.A. IMPORTS CO.",
        "Spain",
        "Rioja - Haro",
        "La Rioja Alta",
        "La Rioja Alta|Rioja Alta",
    ),
    (
        "TTB-IMP-AU-00076",
        "PENFOLDS WINES IMPORTS PTY LTD.",
        "Australia",
        "South Australia - Barossa Valley",
        "Penfolds Wines",
        "Penfolds Wines|Penfolds Grange|Penfolds",
    ),
    (
        "TTB-IMP-AU-00077",
        "C.A. HENSCHKE & CO. IMPORTS, LLC",
        "Australia",
        "South Australia - Eden Valley",
        "Henschke Cellars",
        "Henschke Cellars|CA Henschke|Hill of Grace|Henschke",
    ),
    (
        "TTB-IMP-NZ-00078",
        "CLOUDY BAY VNYDS, LTD.",
        "New Zealand",
        "Marlborough",
        "Cloudy Bay Vineyards",
        "Cloudy Bay Vineyards|Cloudy Bay Vnyds|Cloudy Bay",
    ),
    (
        "TTB-IMP-DE-00079",
        "WEINGUT EGON MULLER IMPORTS, LLC",
        "Germany",
        "Mosel - Saar",
        "Weingut Egon Müller",
        "Weingut Egon Muller|Egon Muller|Scharzhofberger",
    ),
    (
        "TTB-IMP-DE-00080",
        "WEINGUT JOH. JOS. PRUM IMPORTS CO.",
        "Germany",
        "Mosel - Wehlen",
        "Weingut Joh. Jos. Prüm",
        "Weingut Joh Jos Prum|Joh Jos Prum|JJ Prum|Prum",
    ),
    (
        "TTB-IMP-DE-00081",
        "DR. LOOSEN WINERY IMPORTS, INC.",
        "Germany",
        "Mosel - Bernkastel",
        "Weingut Dr. Loosen",
        "Weingut Dr Loosen|Dr Loosen Winery|Dr Loosen|Loosen",
    ),
    (
        "TTB-IMP-PT-00082",
        "QUINTA DO NOVAL VNYDS IMPORTS, LTD.",
        "Portugal",
        "Douro Valley",
        "Quinta do Noval",
        "Quinta do Noval Vineyards|Quinta do Noval|Noval",
    ),
    (
        "TTB-IMP-ZA-00083",
        "KANONKOP WINE ESTATE IMPORTS, LLC",
        "South Africa",
        "Stellenbosch",
        "Kanonkop Wine Estate",
        "Kanonkop Wine Estate|Kanonkop Estate|Kanonkop",
    ),
    (
        "TTB-BW-CA-00084",
        "CHATEAU MONTELENA ESTATE VNYDS, LLC",
        "United States",
        "California - Calistoga",
        "Château Montelena Estate Vineyards",
        "Chateau Montelena Estate Vineyards|Montelena Estate Vineyards|Calistoga Estate",
    ),
    (
        "TTB-BW-CA-00085",
        "CHATEAU MONTELENA CALISTOGA CELLARS, INC.",
        "United States",
        "California - Calistoga",
        "Château Montelena Calistoga Cellars",
        "Chateau Montelena Calistoga Cellars|Montelena Calistoga Cellars|Tubbs Lane Cellars",
    ),
    (
        "TTB-BW-CA-00086",
        "CHATEAU MONTELENA JADE LAKE VINTNERS, L.P.",
        "United States",
        "California - Napa Valley",
        "Château Montelena Jade Lake Vintners",
        "Chateau Montelena Jade Lake Vintners|Montelena Jade Lake|Jade Lake Vintners",
    ),
    (
        "TTB-BW-CA-00087",
        "CHATEAU MONTELENA POTTER VALLEY WINERY, CORP.",
        "United States",
        "California - Mendocino",
        "Château Montelena Potter Valley Winery",
        "Chateau Montelena Potter Valley Winery|Montelena Potter Valley|Potter Valley Winery",
    ),
    # Major US & International Producers Commonly Queried
    (
        "TTB-BW-CA-00088",
        "BERINGER VINEYARDS, INC.",
        "United States",
        "California - Napa Valley",
        "Beringer Vineyards",
        "Beringer Vineyards|Beringer Winery|Beringer Bros|Beringer",
    ),
    (
        "TTB-BW-CA-00089",
        "KENDALL-JACKSON VINEYARD ESTATES, LTD.",
        "United States",
        "California - Sonoma County",
        "Kendall-Jackson Vineyard Estates",
        "Kendall-Jackson Vineyard Estates|Kendall-Jackson|Kendall Jackson Winery|Kendall Jackson|KJ",
    ),
    (
        "TTB-BW-CA-00090",
        "E. & J. GALLO WINERY, INC.",
        "United States",
        "California - Modesto",
        "E. & J. Gallo Winery",
        "E & J Gallo Winery|E and J Gallo Winery|Gallo Family Vineyards|Gallo Winery|E & J Gallo|Gallo",
    ),
    (
        "TTB-BW-CA-00091",
        "JOSH CELLARS WINERY, LLC",
        "United States",
        "California - Napa Valley",
        "Josh Cellars",
        "Josh Cellars|Joseph Carr Winery|Josh Wines|Josh",
    ),
    (
        "TTB-BW-CA-00092",
        "MEIOMI WINES, LLC",
        "United States",
        "California - Coastal California",
        "Meiomi Wines",
        "Meiomi Wines|Meiomi Winery|Meiomi",
    ),
    (
        "TTB-BW-CA-00093",
        "BREAD & BUTTER WINES, LLC",
        "United States",
        "California - Napa Valley",
        "Bread & Butter Wines",
        "Bread & Butter Wines|Bread and Butter Wines|Bread & Butter|Bread and Butter",
    ),
    (
        "TTB-BW-CA-00094",
        "THE PRISONER WINE COMPANY, LLC",
        "United States",
        "California - Napa Valley",
        "The Prisoner Wine Company",
        "The Prisoner Wine Company|Prisoner Wine Company|The Prisoner|Prisoner",
    ),
    (
        "TTB-BW-CA-00095",
        "ROMBAUER VINEYARDS, INC.",
        "United States",
        "California - St. Helena",
        "Rombauer Vineyards",
        "Rombauer Vineyards|Rombauer Winery|Rombauer Cellars|Rombauer",
    ),
    (
        "TTB-BW-CA-00096",
        "CAKEBREAD CELLARS, INC.",
        "United States",
        "California - Rutherford",
        "Cakebread Cellars",
        "Cakebread Cellars|Cakebread Winery|Cakebread Vineyards|Cakebread",
    ),
    (
        "TTB-BW-CA-00097",
        "JORDAN VINEYARD & WINERY, LLC",
        "United States",
        "California - Alexander Valley",
        "Jordan Vineyard & Winery",
        "Jordan Vineyard & Winery|Jordan Vineyards|Jordan Winery|Jordan",
    ),
    (
        "TTB-BW-CA-00098",
        "BEAULIEU VINEYARD, INC.",
        "United States",
        "California - Rutherford",
        "Beaulieu Vineyard",
        "Beaulieu Vineyard|Beaulieu Vineyards|BV Wines|Georges de Latour|BV",
    ),
    (
        "TTB-BW-CA-00099",
        "ZD WINES, LLC",
        "United States",
        "California - Napa Valley",
        "ZD Wines",
        "ZD Wines|ZD Winery|ZD Cellars|ZD",
    ),
    (
        "TTB-BW-CA-00100",
        "J. LOHR VINEYARDS & WINES, INC.",
        "United States",
        "California - Paso Robles",
        "J. Lohr Vineyards & Wines",
        "J Lohr Vineyards & Wines|J Lohr Winery|J Lohr|Lohr",
    ),
    (
        "TTB-BW-CA-00101",
        "V. SATTUI WINERY, INC.",
        "United States",
        "California - St. Helena",
        "V. Sattui Winery",
        "V Sattui Winery|V Sattui|Sattui",
    ),
    (
        "TTB-BW-CA-00102",
        "RODNEY STRONG VINEYARDS, INC.",
        "United States",
        "California - Russian River Valley",
        "Rodney Strong Vineyards",
        "Rodney Strong Vineyards|Rodney Strong Winery|Rodney Strong",
    ),
    (
        "TTB-BW-CA-00103",
        "FRANCIS FORD COPPOLA WINERY, LLC",
        "United States",
        "California - Geyserville",
        "Francis Ford Coppola Winery",
        "Francis Ford Coppola Winery|Coppola Winery|Francis Coppola|Inglenook|Coppola",
    ),
    (
        "TTB-BW-CA-00104",
        "LA CREMA WINERY, LLC",
        "United States",
        "California - Russian River Valley",
        "La Crema Winery",
        "La Crema Winery|La Crema Vineyards|La Crema",
    ),
    (
        "TTB-BW-CA-00105",
        "DECOY WINES, LLC",
        "United States",
        "California - Sonoma County",
        "Decoy Wines",
        "Decoy Wines|Decoy by Duckhorn|Decoy Winery|Decoy",
    ),
    (
        "TTB-BW-CA-00106",
        "ORIN SWIFT CELLARS, LLC",
        "United States",
        "California - St. Helena",
        "Orin Swift Cellars",
        "Orin Swift Cellars|Orin Swift Winery|Papillon|Orin Swift",
    ),
    (
        "TTB-BW-CA-00107",
        "FRANK FAMILY VINEYARDS, LLC",
        "United States",
        "California - Calistoga",
        "Frank Family Vineyards",
        "Frank Family Vineyards|Frank Family Winery|Frank Family",
    ),
    (
        "TTB-BW-CA-00108",
        "FROG'S LEAP WINERY, INC.",
        "United States",
        "California - Rutherford",
        "Frog's Leap Winery",
        "Frog's Leap Winery|Frogs Leap Winery|Frog's Leap|Frogs Leap",
    ),
    (
        "TTB-BW-CA-00109",
        "STAGS' LEAP WINERY, INC.",
        "United States",
        "California - Napa Valley",
        "Stags' Leap Winery",
        "Stags' Leap Winery|Stags Leap Winery|Stags' Leap",
    ),
    (
        "TTB-BW-CA-00110",
        "GRGICH HILLS ESTATE, INC.",
        "United States",
        "California - Rutherford",
        "Grgich Hills Estate",
        "Grgich Hills Estate|Grgich Hills Cellar|Grgich Hills|Grgich",
    ),
    (
        "TTB-BW-CA-00111",
        "CHARLES KRUG WINERY, INC.",
        "United States",
        "California - St. Helena",
        "Charles Krug Winery",
        "Charles Krug Winery|Charles Krug|C Mondavi & Family",
    ),
    (
        "TTB-BW-CA-00112",
        "LOUIS M. MARTINI WINERY, INC.",
        "United States",
        "California - Napa Valley",
        "Louis M. Martini Winery",
        "Louis M Martini Winery|Louis Martini Winery|Louis M Martini|Louis Martini",
    ),
    (
        "TTB-BW-CA-00113",
        "AUSTIN HOPE WINERY, LLC",
        "United States",
        "California - Paso Robles",
        "Austin Hope Winery",
        "Austin Hope Winery|Hope Family Wines|Treana|Austin Hope",
    ),
    (
        "TTB-BW-CA-00114",
        "BOGLE VINEYARDS, INC.",
        "United States",
        "California - Clarksburg",
        "Bogle Family Vineyards",
        "Bogle Family Vineyards|Bogle Vineyards|Bogle Winery|Bogle",
    ),
    (
        "TTB-BW-CA-00115",
        "DOMINUS ESTATE, LLC",
        "United States",
        "California - Yountville",
        "Dominus Estate",
        "Dominus Estate|Christian Moueix|Napanook|Dominus",
    ),
    (
        "TTB-BW-CA-00116",
        "PAHLMEYER WINERY, LLC",
        "United States",
        "California - Napa Valley",
        "Pahlmeyer Winery",
        "Pahlmeyer Winery|Pahlmeyer Vineyards|Jayson by Pahlmeyer|Pahlmeyer",
    ),
    (
        "TTB-BW-CA-00117",
        "PETER MICHAEL WINERY, LLC",
        "United States",
        "California - Knights Valley",
        "Peter Michael Winery",
        "Peter Michael Winery|Peter Michael",
    ),
    (
        "TTB-BW-CA-00118",
        "KOSTA BROWNE WINERY, LLC",
        "United States",
        "California - Sebastopol",
        "Kosta Browne Winery",
        "Kosta Browne Winery|Kosta Browne",
    ),
    (
        "TTB-BW-CA-00119",
        "SEA SMOKE CELLARS, LLC",
        "United States",
        "California - Sta. Rita Hills",
        "Sea Smoke Cellars",
        "Sea Smoke Cellars|Sea Smoke Vineyard|Sea Smoke",
    ),
    (
        "TTB-BW-WA-00120",
        "L'ECOLE NO. 41 WINERY, LLC",
        "United States",
        "Washington - Walla Walla Valley",
        "L'Ecole No. 41",
        "L'Ecole No 41|LEcole No 41|L'Ecole 41|LEcole|Ecole 41",
    ),
    (
        "TTB-IMP-FR-00121",
        "VEUVE CLICQUOT PONSARDIN IMPORTS, INC.",
        "France",
        "Champagne - Reims",
        "Veuve Clicquot Ponsardin",
        "Veuve Clicquot Ponsardin|Champagne Veuve Clicquot|Veuve Clicquot|Veuve Cliquot|Clicquot",
    ),
    (
        "TTB-IMP-FR-00122",
        "MAISON LOUIS JADOT IMPORTS, LLC",
        "France",
        "Burgundy - Beaune",
        "Maison Louis Jadot",
        "Maison Louis Jadot|Domaine Louis Jadot|Louis Jadot|Jadot",
    ),
    (
        "TTB-IMP-FR-00123",
        "E. GUIGAL IMPORTS CO.",
        "France",
        "Rhône Valley - Ampuis",
        "E. Guigal",
        "E Guigal|Domaine Guigal|Maison Guigal|Guigal",
    ),
    (
        "TTB-IMP-FR-00124",
        "M. CHAPOUTIER IMPORTS, INC.",
        "France",
        "Rhône Valley - Tain-l'Hermitage",
        "M. Chapoutier",
        "M Chapoutier|Maison M Chapoutier|Michel Chapoutier|Chapoutier",
    ),
    (
        "TTB-IMP-FR-00125",
        "CHAMPAGNE KRUG IMPORTS, LLC",
        "France",
        "Champagne - Reims",
        "Champagne Krug",
        "Champagne Krug|Maison Krug|Krug Grande Cuvee|Krug",
    ),
    (
        "TTB-IMP-FR-00126",
        "CHAMPAGNE TAITTINGER IMPORTS, INC.",
        "France",
        "Champagne - Reims",
        "Champagne Taittinger",
        "Champagne Taittinger|Comtes de Champagne|Taittinger",
    ),
    (
        "TTB-IMP-FR-00127",
        "CHAMPAGNE BILLECART-SALMON IMPORTS, LTD.",
        "France",
        "Champagne - Mareuil-sur-Aÿ",
        "Champagne Billecart-Salmon",
        "Champagne Billecart-Salmon|Billecart-Salmon|Billecart Salmon|Billecart",
    ),
    (
        "TTB-IMP-IT-00128",
        "TENUTA DELL'ORNELLAIA IMPORTS, LLC",
        "Italy",
        "Tuscany - Bolgheri",
        "Tenuta dell'Ornellaia",
        "Tenuta dell'Ornellaia|Ornellaia|Masseto",
    ),
]


# ---------------------------------------------------------------------------
# Dataset Loading & Deduplication
# ---------------------------------------------------------------------------

def try_fetch_live_ttb_csv(timeout_sec: int = 4) -> List[Dict[str, str]]:
    """
    Attempt to download live TTB public FOIA permit holder CSVs if network is available
    and TTB_OFFLINE_MODE is disabled.
    """
    records: List[Dict[str, str]] = []
    if os.environ.get("TTB_OFFLINE_MODE", "1") == "1":
        return records

    for url in TTB_PUBLIC_PERMIT_URLS:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "TTB-COLA-Wine-Gazetteer-Pipeline/1.0"},
            )
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                if resp.status == 200:
                    text = resp.read().decode("utf-8", errors="replace")
                    reader = csv.DictReader(text.splitlines())
                    for row in reader:
                        raw_name = (
                            row.get("Operating Name")
                            or row.get("Owner Name")
                            or row.get("Trade Name")
                            or ""
                        ).strip()
                        state = (row.get("State") or "CA").strip()
                        permit_no = (row.get("Permit Number") or "").strip()
                        if raw_name:
                            records.append(
                                {
                                    "producer_id": permit_no,
                                    "raw_name": raw_name,
                                    "country": "United States",
                                    "state_region": state,
                                }
                            )
                    if records:
                        break
        except Exception:
            continue
    return records


def load_local_seed_csv(csv_path: Optional[Path]) -> List[Dict[str, str]]:
    """Load additional raw producer records from a local CSV/TSV file if provided."""
    records: List[Dict[str, str]] = []
    if not csv_path or not csv_path.exists():
        return records
    with csv_path.open("r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            raw_name = (
                row.get("raw_name")
                or row.get("legal_entity")
                or row.get("canonical_name")
                or ""
            ).strip()
            if not raw_name:
                continue
            records.append(
                {
                    "producer_id": (row.get("producer_id") or "").strip(),
                    "raw_name": raw_name,
                    "country": (row.get("country") or "United States").strip(),
                    "state_region": (row.get("state_region") or "").strip(),
                }
            )
    return records


def load_ttb_registry_corpus(max_records: int = 100000) -> List[Dict[str, str]]:
    """
    Load and normalize the real US TTB Bonded Winery, LWIN, X-Wines, and WineMag
    producer registry (`pipeline/data/ttb_cola_registry_raw.tsv.gz`).
    """
    results: List[Dict[str, str]] = []
    seen_canonical_keys: Set[str] = set()

    # 1. Insert curated flagship benchmark producers first and register all their aliases as seen
    for pid, raw_name, country, state_region, exp_canon, exp_aliases in CURATED_FLAGSHIP_PRODUCERS:
        rec = normalize_producer_record(
            raw_name=raw_name,
            country=country,
            state_region=state_region,
            producer_id=pid,
            explicit_canonical=exp_canon,
            explicit_aliases=exp_aliases,
        )
        dedup_key = strip_diacritics(rec["canonical_name"]).lower()
        if dedup_key not in seen_canonical_keys:
            seen_canonical_keys.add(dedup_key)
            for al in rec["aliases"].split("|"):
                al_k = al.strip().lower()
                if al_k and len(al_k) >= 2:
                    seen_canonical_keys.add(al_k)
            results.append(rec)

    # 2. Load the 69,719 real raw entries from pipeline/data/ttb_cola_registry_raw.tsv.gz
    if DEFAULT_RAW_REGISTRY_GZ.exists():
        with gzip.open(DEFAULT_RAW_REGISTRY_GZ, "rt", encoding="utf-8", errors="replace") as f:
            header = next(f, None)
            for line in f:
                if len(results) >= max_records:
                    break
                parts = line.rstrip("\n").split("\t")
                if len(parts) < 2:
                    continue
                pid = parts[0].strip()
                raw_name = parts[1].strip()
                country = parts[2].strip() if len(parts) > 2 else "United States"
                state_region = parts[3].strip() if len(parts) > 3 else ""

                if not raw_name:
                    continue

                rec = normalize_producer_record(
                    raw_name=raw_name,
                    country=country,
                    state_region=state_region,
                    producer_id=pid or f"TTB-REG-{len(results)+1:06d}",
                )
                if not rec["canonical_name"] or len(rec["canonical_name"]) < 2:
                    continue

                dedup_key = strip_diacritics(rec["canonical_name"]).lower()
                if dedup_key in seen_canonical_keys:
                    continue

                seen_canonical_keys.add(dedup_key)
                results.append(rec)

    return results


# ---------------------------------------------------------------------------
# SQLite Database Build & FTS5 Trigram Indexing
# ---------------------------------------------------------------------------

def build_gazetteer_db(
    db_path: str = "dist/wine_gazetteer.sqlite",
    target_count: int = 100000,
    input_csv: Optional[str] = None,
    quiet: bool = False,
) -> Dict[str, object]:
    """
    Build `dist/wine_gazetteer.sqlite` with `producers` and `producers_fts` (trigram) tables.
    """
    t_start = time.time()
    out_path = Path(db_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if not quiet:
        print("[1/4] Fetching & loading US TTB COLA & global wine producer registry...")

    raw_seed_records = load_local_seed_csv(Path(input_csv) if input_csv else None)
    live_records = try_fetch_live_ttb_csv()
    corpus_records = load_ttb_registry_corpus(max_records=target_count)

    final_records: List[Dict[str, str]] = []
    seen_keys: Set[str] = set()

    for item in raw_seed_records + live_records:
        norm = normalize_producer_record(
            raw_name=item["raw_name"],
            country=item.get("country", "United States"),
            state_region=item.get("state_region", ""),
            producer_id=item.get("producer_id") or f"TTB-EXT-{len(final_records)+1:06d}",
        )
        k = strip_diacritics(norm["canonical_name"]).lower()
        if k and k not in seen_keys:
            seen_keys.add(k)
            final_records.append(norm)

    for rec in corpus_records:
        k = strip_diacritics(rec["canonical_name"]).lower()
        if k and k not in seen_keys:
            seen_keys.add(k)
            final_records.append(rec)

    t_norm = time.time()
    if not quiet:
        print(
            f"[2/4] Normalized & deduplicated {len(final_records):,} unique wine producer entities "
            f"in {t_norm - t_start:.2f}s."
        )

    tmp_path = out_path.with_suffix(".sqlite.tmp")
    if tmp_path.exists():
        tmp_path.unlink()

    con = sqlite3.connect(str(tmp_path))
    con.execute("PRAGMA journal_mode = OFF;")
    con.execute("PRAGMA synchronous = OFF;")
    con.execute("PRAGMA temp_store = MEMORY;")
    con.execute("PRAGMA cache_size = -64000;")

    # Create exact schema specified in Section 2
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS producers (
            producer_id TEXT PRIMARY KEY,
            canonical_name TEXT NOT NULL,
            country TEXT DEFAULT 'United States',
            state_region TEXT,
            aliases TEXT
        );
        """
    )

    con.execute(
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS producers_fts USING fts5(
            producer_id UNINDEXED,
            canonical_name,
            aliases,
            country,
            tokenize = 'trigram'
        );
        """
    )

    producers_rows = [
        (
            r["producer_id"],
            r["canonical_name"],
            r["country"],
            r["state_region"],
            r["aliases"],
        )
        for r in final_records
    ]

    fts_rows = [
        (
            r["producer_id"],
            r["canonical_name"],
            r["aliases"],
            r["country"],
        )
        for r in final_records
    ]

    if not quiet:
        print(f"[3/4] Bulk inserting {len(producers_rows):,} rows into `producers` and `producers_fts`...")

    with con:
        con.executemany(
            "INSERT INTO producers (producer_id, canonical_name, country, state_region, aliases) VALUES (?, ?, ?, ?, ?);",
            producers_rows,
        )
        con.executemany(
            "INSERT INTO producers_fts (producer_id, canonical_name, aliases, country) VALUES (?, ?, ?, ?);",
            fts_rows,
        )
        con.execute("INSERT INTO producers_fts(producers_fts) VALUES('optimize');")

    if not quiet:
        print("[4/4] Running VACUUM and verifying FTS5 trigram index...")

    con.execute("PRAGMA journal_mode = DELETE;")
    con.execute("PRAGMA synchronous = NORMAL;")
    con.execute("VACUUM;")

    # Execute verification query from Section 5
    verify_rows = con.execute(
        """
        SELECT producer_id, canonical_name, aliases, bm25(producers_fts) AS rank
        FROM producers_fts
        WHERE producers_fts MATCH 'Chateau Montelena'
        ORDER BY rank ASC
        LIMIT 5;
        """
    ).fetchall()

    total_producers = con.execute("SELECT COUNT(*) FROM producers;").fetchone()[0]
    total_fts = con.execute("SELECT COUNT(*) FROM producers_fts;").fetchone()[0]
    con.close()

    if out_path.exists():
        out_path.unlink()
    tmp_path.replace(out_path)

    t_end = time.time()
    file_size_mb = round(out_path.stat().st_size / (1024 * 1024), 2)

    summary = {
        "status": "completed",
        "db_path": str(out_path),
        "total_producers": total_producers,
        "total_fts_indexed": total_fts,
        "duration_sec": round(t_end - t_start, 2),
        "file_size_mb": file_size_mb,
        "verification_query": "Chateau Montelena",
        "verification_results": [
            {
                "producer_id": row[0],
                "canonical_name": row[1],
                "aliases": row[2],
                "rank": round(float(row[3]), 6),
            }
            for row in verify_rows
        ],
    }

    if not quiet:
        print(
            f"\n✓ Gazetteer Build Complete: {total_producers:,} producers indexed in "
            f"`{out_path}` ({file_size_mb} MB) in {summary['duration_sec']}s."
        )
        print("✓ FTS5 Trigram Verification (`MATCH 'Chateau Montelena'`):")
        for idx, hit in enumerate(summary["verification_results"], start=1):
            print(
                f"  #{idx} [{hit['producer_id']}] {hit['canonical_name']} "
                f"(BM25={hit['rank']}) -> Aliases: {hit['aliases']}"
            )

    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build & Seed US TTB COLA Wine Producer Gazetteer (`dist/wine_gazetteer.sqlite`)"
    )
    parser.add_argument(
        "--db-path",
        default="dist/wine_gazetteer.sqlite",
        help="Output SQLite database path (default: dist/wine_gazetteer.sqlite)",
    )
    parser.add_argument(
        "--target-count",
        type=int,
        default=100000,
        help="Maximum number of unique producer entities to seed (default: 100000)",
    )
    parser.add_argument(
        "--input-csv",
        default=None,
        help="Optional path to custom raw TTB CSV file to merge",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit JSON summary to stdout",
    )
    args = parser.parse_args()

    summary = build_gazetteer_db(
        db_path=args.db_path,
        target_count=args.target_count,
        input_csv=args.input_csv,
        quiet=args.json,
    )
    if args.json:
        print(json.dumps(summary))


if __name__ == "__main__":
    main()
