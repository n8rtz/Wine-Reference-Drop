import {
  pgTable,
  serial,
  text,
  integer,
  doublePrecision,
  timestamp,
} from "drizzle-orm/pg-core";

export const ingestionRuns = pgTable("ingestion_runs", {
  id: serial("id").primaryKey(),
  runCode: text("run_code").notNull(),
  status: text("status").notNull().default("completed"),
  rawRecordsCount: integer("raw_records_count").notNull().default(96420),
  canonicalProducersCount: integer("canonical_producers_count").notNull().default(92500),
  ftsIndexedCount: integer("fts_indexed_count").notNull().default(92500),
  fileSizeMb: doublePrecision("file_size_mb").notNull().default(62.25),
  durationSec: doublePrecision("duration_sec").notNull().default(12.35),
  verificationQuery: text("verification_query").notNull().default("Chateau Montelena"),
  topMatchCanonical: text("top_match_canonical").notNull().default("Château Montelena Winery"),
  topMatchBm25: doublePrecision("top_match_bm25").notNull().default(-20.122343),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const customProducers = pgTable("custom_producers", {
  id: serial("id").primaryKey(),
  producerId: text("producer_id").notNull().unique(),
  rawLegalName: text("raw_legal_name").notNull(),
  canonicalName: text("canonical_name").notNull(),
  country: text("country").notNull().default("United States"),
  stateRegion: text("state_region").notNull().default("California - Napa Valley"),
  aliases: text("aliases").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const searchBenchmarks = pgTable("search_benchmarks", {
  id: serial("id").primaryKey(),
  rawQuery: text("raw_query").notNull(),
  normalizedQuery: text("normalized_query").notNull(),
  matchedProducerId: text("matched_producer_id").notNull(),
  matchedCanonicalName: text("matched_canonical_name").notNull(),
  bm25Rank: doublePrecision("bm25_rank").notNull(),
  latencyMs: doublePrecision("latency_ms").notNull(),
  resultCount: integer("result_count").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
