import type { Metadata } from "next";
import type { ReactNode } from "react";
import {
  Cormorant_Garamond,
  Plus_Jakarta_Sans,
  JetBrains_Mono,
} from "next/font/google";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["600", "700"],
  variable: "--font-display",
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
});

export const metadata: Metadata = {
  title: "US TTB COLA Wine Producer Gazetteer | FTS5 Trigram Entity Resolution",
  description:
    "Imperial Cellar Ledger & Precision Registry: US TTB COLA permit holder & brand registry ingestion pipeline, corporate suffix stripping, diacritic normalization, alias expansion, and SQLite FTS5 trigram fuzzy search.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="en"
      className={`${cormorant.variable} ${jakarta.variable} ${jetbrains.variable}`}
    >
      <body className="min-h-screen bg-[#FBF9F5] text-[#1C1618] font-sans antialiased selection:bg-[#722F37]/15 selection:text-[#722F37]">
        {children}
      </body>
    </html>
  );
}
