import { NextRequest, NextResponse } from "next/server";
import { triggerPipelineRebuild, upsertCustomProducer } from "@/lib/gazetteer";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = body.action || "rebuild";

    if (action === "upsert") {
      const producerId =
        (body.producerId || "").trim() ||
        `TTB-CUR-${Math.floor(100000 + Math.random() * 900000)}`;
      const rawLegalName = (body.rawLegalName || "").trim();
      const country = (body.country || "United States").trim();
      const stateRegion = (body.stateRegion || "California - Napa Valley").trim();
      const customAliases = (body.customAliases || "").trim();

      if (!rawLegalName) {
        return NextResponse.json(
          { error: "rawLegalName is required" },
          { status: 400 }
        );
      }

      const upserted = await upsertCustomProducer({
        producerId,
        rawLegalName,
        country,
        stateRegion,
        customAliases,
      });

      return NextResponse.json({
        action: "upsert",
        record: upserted,
      });
    }

    const targetCount = Math.min(
      120000,
      Math.max(55000, Number(body.targetCount || 92500))
    );
    const rebuildSummary = await triggerPipelineRebuild(targetCount);

    return NextResponse.json({
      action: "rebuild",
      summary: rebuildSummary,
    });
  } catch (error) {
    console.error("Gazetteer ingest API error:", error);
    return NextResponse.json(
      {
        error: "Ingest action failed",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
