import { NextResponse } from "next/server";
import { db } from "@/db";
import { customProducers, ingestionRuns, searchBenchmarks } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensurePostgresSeeded, getGazetteerStats } from "@/lib/gazetteer";

export async function GET() {
  try {
    await ensurePostgresSeeded();

    const [sqliteStats, runs, benchmarks, custom] = await Promise.all([
      getGazetteerStats(),
      db.select().from(ingestionRuns).orderBy(desc(ingestionRuns.id)).limit(8),
      db
        .select()
        .from(searchBenchmarks)
        .orderBy(desc(searchBenchmarks.id))
        .limit(12),
      db
        .select()
        .from(customProducers)
        .orderBy(desc(customProducers.id))
        .limit(15),
    ]);

    return NextResponse.json({
      sqliteStats,
      ingestionRuns: runs,
      searchBenchmarks: benchmarks,
      customProducers: custom,
    });
  } catch (error) {
    console.error("Failed to fetch gazetteer overview:", error);
    return NextResponse.json(
      {
        error: "Failed to load gazetteer overview",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
