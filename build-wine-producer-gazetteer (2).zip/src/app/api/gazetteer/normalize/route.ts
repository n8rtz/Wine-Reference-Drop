import { NextRequest, NextResponse } from "next/server";
import { runNormalizationSandbox } from "@/lib/gazetteer";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const rawName = (body.rawName || "CHATEAU MONTELENA WINERY, LLC").trim();

    const result = await runNormalizationSandbox(rawName);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Normalization sandbox error:", error);
    return NextResponse.json(
      {
        error: "Normalization failed",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
