import { NextRequest, NextResponse } from "next/server";
import { runGazetteerSearch } from "@/lib/gazetteer";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q") || "Chateau Montelena";
    const country = searchParams.get("country") || "";
    const limit = Math.min(50, Math.max(1, Number(searchParams.get("limit") || 15)));
    const log = searchParams.get("log") === "1";

    const result = await runGazetteerSearch(query, country, limit, log);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Gazetteer FTS5 search error:", error);
    return NextResponse.json(
      {
        error: "FTS5 search failed",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const query = body.query || "Chateau Montelena";
    const country = body.country || "";
    const limit = Math.min(50, Math.max(1, Number(body.limit || 15)));
    const recordBenchmark = Boolean(body.recordBenchmark);

    const result = await runGazetteerSearch(query, country, limit, recordBenchmark);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Gazetteer FTS5 POST search error:", error);
    return NextResponse.json(
      {
        error: "FTS5 search failed",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
