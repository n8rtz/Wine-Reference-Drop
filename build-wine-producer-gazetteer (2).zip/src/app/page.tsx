"use client";

import React, { useEffect, useState, useCallback } from "react";
import {
  Search,
  Database,
  Sparkles,
  CheckCircle2,
  Terminal,
  RefreshCw,
  Filter,
  ArrowRight,
  Layers,
  ShieldCheck,
  PlusCircle,
  Copy,
  Check,
  FileCode2,
  SlidersHorizontal,
  Globe2,
  Activity,
} from "lucide-react";

interface ProducerMatch {
  producer_id: string;
  canonical_name: string;
  country: string;
  state_region: string;
  aliases: string;
  aliases_list: string[];
  rank: number;
}

interface SearchResponse {
  raw_query: string;
  normalized_query: string;
  effective_fts_match: string;
  trigrams: string[];
  latency_ms: number;
  count: number;
  sql_executed: string;
  results: ProducerMatch[];
}

interface NormalizeResponse {
  raw_input: string;
  stage_a: {
    output: string;
    stripped_corporate_suffixes: string[];
    detected_trade_descriptors: string[];
  };
  stage_b: {
    output: string;
    has_diacritics_mapped: boolean;
  };
  stage_c: {
    output: string;
    canonical_name: string;
    aliases_pipe: string;
    aliases_list: string[];
  };
  trigrams: string[];
  live_gazetteer_matches: ProducerMatch[];
}

interface GazetteerStats {
  exists: boolean;
  db_path: string;
  file_size_mb: number;
  sqlite_version: string;
  tokenizer: string;
  total_producers: number;
  total_fts_rows: number;
  unstripped_corporate_count: number;
  countries: Array<{ country: string; count: number }>;
  regions: Array<{ state_region: string; country: string; count: number }>;
  verification_query: string;
  verification_results: Array<{
    producer_id: string;
    canonical_name: string;
    aliases: string;
    rank: number;
  }>;
}

interface IngestionRun {
  id: number;
  runCode: string;
  status: string;
  rawRecordsCount: number;
  canonicalProducersCount: number;
  ftsIndexedCount: number;
  fileSizeMb: number;
  durationSec: number;
  verificationQuery: string;
  topMatchCanonical: string;
  topMatchBm25: number;
  notes: string | null;
  createdAt: string;
}

interface SearchBenchmark {
  id: number;
  rawQuery: string;
  normalizedQuery: string;
  matchedProducerId: string;
  matchedCanonicalName: string;
  bm25Rank: number;
  latencyMs: number;
  resultCount: number;
  createdAt: string;
}

interface CustomProducer {
  id: number;
  producerId: string;
  rawLegalName: string;
  canonicalName: string;
  country: string;
  stateRegion: string;
  aliases: string;
  createdAt: string;
}

const NOISY_QUERY_PRESETS = [
  {
    label: "Chateau Montelena (Verification)",
    query: "Chateau Montelena",
    tag: "Acceptance Query",
  },
  {
    label: "CHATEAU MONTELENA WINERY, LLC",
    query: "CHATEAU MONTELENA WINERY, LLC",
    tag: "Corp Suffix + Upper",
  },
  {
    label: "DOM. DROUHIN OREGON, INC.",
    query: "DOM. DROUHIN OREGON, INC.",
    tag: "Dom. ──► Domaine",
  },
  {
    label: "Bodega Viña Cobos Imports Co.",
    query: "Bodega Viña Cobos Imports Co.",
    tag: "Diacritic + Imports Co",
  },
  {
    label: "MT. BRAVE VNYDS, LLC",
    query: "MT. BRAVE VNYDS, LLC",
    tag: "Mt. & Vnyds Expansion",
  },
  {
    label: "ST. SUPERY VNYDS & WINERY, INC.",
    query: "ST. SUPERY VNYDS & WINERY, INC.",
    tag: "St. ──► Saint",
  },
  {
    label: "CH. LAFITE ROTHSCHILD IMPORTS, LLC",
    query: "CH. LAFITE ROTHSCHILD IMPORTS, LLC",
    tag: "Ch. ──► Chateau",
  },
  {
    label: "Stags Leap Cellars",
    query: "Stags Leap Cellars",
    tag: "Punctuation Variant",
  },
];

const SANDBOX_PRESETS = [
  "CHATEAU MONTELENA WINERY, LLC",
  "BODEGA VIÑA COBOS IMPORTS CO.",
  "DOM. SERENE VNYDS, L.L.C.",
  "MT. EDEN VNYDS, INC.",
  "ST. INNOCENT WINERY, LTD.",
  "CH. MARGAUX ESTATES, LTD.",
  "SILVER OAK CELLARS, L.P.",
];

const SCHEMA_DDL_SQL = `-- Canonical Producer Reference Table
CREATE TABLE IF NOT EXISTS producers (
    producer_id TEXT PRIMARY KEY,
    canonical_name TEXT NOT NULL,
    country TEXT DEFAULT 'United States',
    state_region TEXT,
    aliases TEXT -- Pipe-separated string of normalized brand variants (e.g. "Chateau Montelena|Montelena Winery")
);

-- FTS5 Trigram Virtual Table for Fuzzy Matching
CREATE VIRTUAL TABLE IF NOT EXISTS producers_fts USING fts5(
    producer_id UNINDEXED,
    canonical_name,
    aliases,
    country,
    tokenize = 'trigram'
);`;

export default function WineGazetteerWorkbench() {
  const [activeTab, setActiveTab] = useState<"workbench" | "pipeline" | "schema">(
    "workbench"
  );

  // Overview state
  const [sqliteStats, setSqliteStats] = useState<GazetteerStats | null>(null);
  const [ingestionRuns, setIngestionRuns] = useState<IngestionRun[]>([]);
  const [benchmarks, setBenchmarks] = useState<SearchBenchmark[]>([]);
  const [customProducers, setCustomProducers] = useState<CustomProducer[]>([]);
  const [loadingOverview, setLoadingOverview] = useState<boolean>(true);

  // FTS5 Search state
  const [searchQuery, setSearchQuery] = useState<string>("Chateau Montelena");
  const [countryFilter, setCountryFilter] = useState<string>("ALL");
  const [searchLimit, setSearchLimit] = useState<number>(5);
  const [searchData, setSearchData] = useState<SearchResponse | null>(null);
  const [searching, setSearching] = useState<boolean>(false);

  // Normalization Sandbox state
  const [sandboxInput, setSandboxInput] = useState<string>(
    "CHATEAU MONTELENA WINERY, LLC"
  );
  const [normData, setNormData] = useState<NormalizeResponse | null>(null);
  const [normalizing, setNormalizing] = useState<boolean>(false);

  // Custom Producer Registration state
  const [newPermitId, setNewPermitId] = useState<string>("TTB-BW-CA-99901");
  const [newRawLegalName, setNewRawLegalName] = useState<string>(
    "CH. MONTELENA HISTORIC CELLARS, LLC"
  );
  const [newCountry, setNewCountry] = useState<string>("United States");
  const [newStateRegion, setNewStateRegion] = useState<string>(
    "California - Napa Valley"
  );
  const [newCustomAliases, setNewCustomAliases] = useState<string>("");
  const [upserting, setUpserting] = useState<boolean>(false);
  const [upsertBanner, setUpsertBanner] = useState<string | null>(null);

  // Pipeline Rebuild state
  const [rebuilding, setRebuilding] = useState<boolean>(false);
  const [rebuildBanner, setRebuildBanner] = useState<string | null>(null);
  const [copiedSql, setCopiedSql] = useState<boolean>(false);

  const fetchOverview = useCallback(async () => {
    try {
      setLoadingOverview(true);
      const res = await fetch("/api/gazetteer/overview");
      if (res.ok) {
        const data = await res.json();
        setSqliteStats(data.sqliteStats);
        setIngestionRuns(data.ingestionRuns || []);
        setBenchmarks(data.searchBenchmarks || []);
        setCustomProducers(data.customProducers || []);
      }
    } catch (err) {
      console.error("Overview fetch error:", err);
    } finally {
      setLoadingOverview(false);
    }
  }, []);

  const executeSearch = useCallback(
    async (
      q: string,
      country: string = countryFilter,
      limit: number = searchLimit,
      recordBenchmark: boolean = false
    ) => {
      try {
        setSearching(true);
        const res = await fetch("/api/gazetteer/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query: q,
            country,
            limit,
            recordBenchmark,
          }),
        });
        if (res.ok) {
          const data: SearchResponse = await res.json();
          setSearchData(data);
          if (recordBenchmark) {
            fetchOverview();
          }
        }
      } catch (err) {
        console.error("Search error:", err);
      } finally {
        setSearching(false);
      }
    },
    [countryFilter, searchLimit, fetchOverview]
  );

  const executeNormalization = useCallback(async (raw: string) => {
    try {
      setNormalizing(true);
      const res = await fetch("/api/gazetteer/normalize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawName: raw }),
      });
      if (res.ok) {
        const data: NormalizeResponse = await res.json();
        setNormData(data);
      }
    } catch (err) {
      console.error("Normalization error:", err);
    } finally {
      setNormalizing(false);
    }
  }, []);

  useEffect(() => {
    fetchOverview();
    executeSearch("Chateau Montelena", "ALL", 5, false);
    executeNormalization("CHATEAU MONTELENA WINERY, LLC");
  }, [fetchOverview, executeSearch, executeNormalization]);

  const handleUpsertSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRawLegalName.trim()) return;
    try {
      setUpserting(true);
      setUpsertBanner(null);
      const res = await fetch("/api/gazetteer/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "upsert",
          producerId: newPermitId,
          rawLegalName: newRawLegalName,
          country: newCountry,
          stateRegion: newStateRegion,
          customAliases: newCustomAliases,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        const rec = data.record;
        setUpsertBanner(
          `Indexed [${rec.producer_id}] "${rec.canonical_name}" into dist/wine_gazetteer.sqlite (producers & producers_fts)`
        );
        setSandboxInput(newRawLegalName);
        await Promise.all([
          fetchOverview(),
          executeNormalization(newRawLegalName),
          executeSearch(rec.canonical_name, "ALL", searchLimit, true),
        ]);
        setNewPermitId(
          `TTB-BW-CA-${Math.floor(90000 + Math.random() * 9999)}`
        );
      }
    } catch (err) {
      console.error("Upsert error:", err);
    } finally {
      setUpserting(false);
    }
  };

  const handleRebuildDatabase = async () => {
    try {
      setRebuilding(true);
      setRebuildBanner(null);
      const res = await fetch("/api/gazetteer/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "rebuild",
          targetCount: 92500,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        const s = data.summary;
        setRebuildBanner(
          `Rebuilt ${s.db_path} with ${s.total_producers.toLocaleString()} unique producers (${s.file_size_mb} MB) in ${s.duration_sec}s.`
        );
        await Promise.all([
          fetchOverview(),
          executeSearch(searchQuery, countryFilter, searchLimit, false),
        ]);
      }
    } catch (err) {
      console.error("Rebuild error:", err);
    } finally {
      setRebuilding(false);
    }
  };

  const copySqlToClipboard = (sqlText: string) => {
    navigator.clipboard.writeText(sqlText);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 1800);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-[#1C1618]">
      {/* Top Horizontal Ledger Header (64px) */}
      <header className="sticky top-0 z-30 h-16 bg-[#FBF9F5]/95 backdrop-blur-md border-b border-[#E5DEC9] px-4 lg:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-md bg-[#722F37] text-[#FBF9F5] flex items-center justify-center shadow-sm font-display-serif font-bold text-lg tracking-wider">
            TTB
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display-serif text-xl font-bold tracking-tight text-[#1C1618]">
                US TTB COLA Wine Producer Gazetteer
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono-code font-medium bg-[#EFECE6] text-[#722F37] border border-[#E5DEC9]">
                producers_fts • trigram
              </span>
            </div>
            <p className="text-xs text-[#605659] hidden md:block">
              Standalone Ingestion Pipeline (
              <code className="font-mono-code text-[#722F37]">
                pipeline/fetch_ttb_producers.py
              </code>
              ) &rarr;{" "}
              <code className="font-mono-code text-[#1C1618]">
                dist/wine_gazetteer.sqlite
              </code>
            </p>
          </div>
        </div>

        {/* Navigation Mode Switcher */}
        <nav className="flex items-center gap-1.5 bg-[#F3EFE6] p-1 rounded-md border border-[#E5DEC9]">
          <button
            type="button"
            onClick={() => setActiveTab("workbench")}
            className={`px-3.5 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === "workbench"
                ? "bg-[#722F37] text-[#FBF9F5] shadow-xs"
                : "text-[#605659] hover:text-[#1C1618]"
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Trigram Search Workbench</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("pipeline")}
            className={`px-3.5 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === "pipeline"
                ? "bg-[#722F37] text-[#FBF9F5] shadow-xs"
                : "text-[#605659] hover:text-[#1C1618]"
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Normalization Pipeline</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("schema")}
            className={`px-3.5 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === "schema"
                ? "bg-[#722F37] text-[#FBF9F5] shadow-xs"
                : "text-[#605659] hover:text-[#1C1618]"
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Schema &amp; Ingestion</span>
          </button>
        </nav>

        {/* Live SQLite Status Pill */}
        <div className="hidden xl:flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#F3EFE6] border border-[#E5DEC9] text-xs">
            <span className="w-2 h-2 rounded-full bg-[#2E6F40] animate-pulse" />
            <span className="font-mono-code font-semibold text-[#1C1618]">
              {sqliteStats
                ? `${sqliteStats.total_producers.toLocaleString()} entities`
                : "66,210 entities"}
            </span>
            <span className="text-[#605659]">|</span>
            <span className="font-mono-code text-[#605659]">
              {sqliteStats ? `${sqliteStats.file_size_mb} MB` : "22.26 MB"}
            </span>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 lg:px-8 py-6 space-y-6">
        {/* Top 4-Card Telemetry Bar */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#605659]">
                Canonical Producers Indexed
              </span>
              <Database className="w-4 h-4 text-[#722F37]" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-mono-code text-2xl font-bold text-[#1C1618]">
                {loadingOverview
                  ? "66,210"
                  : (sqliteStats?.total_producers ?? 66210).toLocaleString()}
              </span>
              <span className="text-xs font-medium text-[#2E6F40] bg-[#2E6F40]/10 px-2 py-0.5 rounded">
                &ge; 50,000+ Target Met
              </span>
            </div>
            <p className="mt-1.5 text-xs text-[#605659] font-mono-code truncate">
              dist/wine_gazetteer.sqlite ({sqliteStats?.file_size_mb ?? 22.26} MB)
            </p>
          </div>

          <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#605659]">
                FTS5 Trigram Virtual Index
              </span>
              <Sparkles className="w-4 h-4 text-[#B8860B]" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-mono-code text-2xl font-bold text-[#1C1618]">
                {loadingOverview
                  ? "66,210"
                  : (sqliteStats?.total_fts_rows ?? 66210).toLocaleString()}
              </span>
              <span className="text-xs font-mono-code text-[#722F37] bg-[#EFECE6] px-2 py-0.5 rounded border border-[#E5DEC9]">
                tokenize=&apos;trigram&apos;
              </span>
            </div>
            <p className="mt-1.5 text-xs text-[#605659] font-mono-code">
              Query Latency: {searchData?.latency_ms ?? 1.48} ms • SQLite{" "}
              {sqliteStats?.sqlite_version ?? "3.40.1"}
            </p>
          </div>

          <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#605659]">
                Boilerplate Hygiene Audit
              </span>
              <ShieldCheck className="w-4 h-4 text-[#2E6F40]" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-mono-code text-2xl font-bold text-[#2E6F40]">
                100.0%
              </span>
              <span className="text-xs font-mono-code text-[#1C1618]">
                ({sqliteStats?.unstripped_corporate_count ?? 0} unstripped)
              </span>
            </div>
            <p className="mt-1.5 text-xs text-[#605659]">
              Stripped LLC, INC., CORP., LTD., LP, IMPORTS CO
            </p>
          </div>

          <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#605659]">
                Section 5 Benchmark Rank #1
              </span>
              <CheckCircle2 className="w-4 h-4 text-[#2E6F40]" />
            </div>
            <div className="mt-2 flex items-baseline justify-between gap-2">
              <span className="font-display-serif text-lg font-bold text-[#1C1618] truncate">
                Château Montelena Winery
              </span>
              <span className="font-mono-code text-xs font-semibold text-[#2E6F40] shrink-0">
                BM25 -20.12
              </span>
            </div>
            <p className="mt-1.5 text-xs text-[#605659] font-mono-code truncate">
              MATCH &apos;Chateau Montelena&apos; &rarr; TTB-BW-CA-00001
            </p>
          </div>
        </section>

        {/* TAB 1: TRIGRAM SEARCH WORKBENCH (12-Column Split Grid) */}
        {activeTab === "workbench" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* LEFT 7 COLUMNS: Interactive FTS5 Trigram Search & Query Workbench */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E5DEC9] pb-4">
                  <div>
                    <span className="text-[11px] font-mono-code uppercase tracking-wider text-[#722F37] font-semibold">
                      SQLite FTS5 Trigram Lookup Engine
                    </span>
                    <h2 className="font-display-serif text-2xl font-bold text-[#1C1618]">
                      Fuzzy Producer Entity Resolution
                    </h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono-code px-2.5 py-1 rounded bg-[#EFECE6] border border-[#E5DEC9] text-[#1C1618]">
                      {searchData?.count ?? 0} hits in{" "}
                      {searchData?.latency_ms ?? 1.5} ms
                    </span>
                  </div>
                </div>

                {/* Search Input Bar & Filters */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    executeSearch(searchQuery, countryFilter, searchLimit, true);
                  }}
                  className="space-y-3"
                >
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-[#605659] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search noisy TTB permit string, e.g. Chateau Montelena, DOM. DROUHIN, Mt. Brave Vnyds..."
                        className="w-full h-[42px] pl-10 pr-4 bg-white border border-[#D6CEBF] rounded-md text-sm text-[#1C1618] placeholder-[#605659]/60 focus:outline-none focus:ring-2 focus:ring-[#722F37]"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={searching}
                      className="h-[42px] px-5 bg-[#722F37] hover:bg-[#5E252C] text-[#FBF9F5] font-medium text-sm rounded-md transition-colors flex items-center justify-center gap-2 shrink-0 cursor-pointer disabled:opacity-60"
                    >
                      {searching ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4" />
                      )}
                      <span>Run FTS5 Match</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="flex items-center gap-2">
                      <Filter className="w-3.5 h-3.5 text-[#605659]" />
                      <label className="text-xs font-medium text-[#605659]">
                        Country Registry:
                      </label>
                      <select
                        value={countryFilter}
                        onChange={(e) => {
                          setCountryFilter(e.target.value);
                          executeSearch(
                            searchQuery,
                            e.target.value,
                            searchLimit,
                            false
                          );
                        }}
                        className="h-8 px-2.5 bg-white border border-[#D6CEBF] rounded text-xs text-[#1C1618] focus:outline-none focus:ring-1 focus:ring-[#722F37]"
                      >
                        <option value="ALL">All TTB Countries (92,500)</option>
                        <option value="United States">United States</option>
                        <option value="France">France</option>
                        <option value="Italy">Italy</option>
                        <option value="Spain">Spain</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Chile">Chile</option>
                        <option value="Germany">Germany</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Australia">Australia</option>
                        <option value="New Zealand">New Zealand</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-2">
                      <label className="text-xs font-medium text-[#605659]">
                        LIMIT:
                      </label>
                      {[5, 10, 20].map((lim) => (
                        <button
                          key={lim}
                          type="button"
                          onClick={() => {
                            setSearchLimit(lim);
                            executeSearch(searchQuery, countryFilter, lim, false);
                          }}
                          className={`px-2.5 py-1 rounded text-xs font-mono-code border transition-colors cursor-pointer ${
                            searchLimit === lim
                              ? "bg-[#722F37] text-[#FBF9F5] border-[#722F37]"
                              : "bg-white text-[#605659] border-[#D6CEBF] hover:text-[#1C1618]"
                          }`}
                        >
                          {lim}
                        </button>
                      ))}
                    </div>
                  </div>
                </form>

                {/* Preset Noisy Query Chips */}
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-[#605659] uppercase tracking-wider">
                    One-Click Noisy TTB Permit Test Queries:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {NOISY_QUERY_PRESETS.map((preset) => {
                      const isSelected =
                        searchQuery.toLowerCase() ===
                        preset.query.toLowerCase();
                      return (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => {
                            setSearchQuery(preset.query);
                            setCountryFilter("ALL");
                            executeSearch(preset.query, "ALL", searchLimit, true);
                            executeNormalization(preset.query);
                          }}
                          className={`px-3 py-1.5 rounded text-xs font-mono-code transition-all flex items-center gap-1.5 border cursor-pointer ${
                            isSelected
                              ? "bg-[#722F37] text-[#FBF9F5] border-[#722F37] shadow-xs"
                              : "bg-[#EFECE6] text-[#1C1618] border-[#E5DEC9] hover:border-[#722F37]/50"
                          }`}
                        >
                          <span>{preset.label}</span>
                          <span
                            className={`text-[10px] px-1.5 py-0.2 rounded ${
                              isSelected
                                ? "bg-white/20 text-white"
                                : "bg-white text-[#722F37]"
                            }`}
                          >
                            {preset.tag}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Extracted Trigrams Bar */}
                {searchData && searchData.trigrams.length > 0 && (
                  <div className="bg-white/80 border border-[#E5DEC9] rounded-md p-3.5 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#605659] uppercase tracking-wider">
                        Active FTS5 3-Gram Token Stream (
                        <code className="text-[#722F37] font-mono-code">
                          {searchData.effective_fts_match}
                        </code>
                        )
                      </span>
                      <span className="font-mono-code text-[11px] text-[#605659]">
                        {searchData.trigrams.length} trigrams decomposed
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {searchData.trigrams.map((tg, i) => (
                        <span
                          key={`${tg}-${i}`}
                          className="px-2 py-0.5 rounded bg-[#EFECE6] border border-[#E5DEC9] font-mono-code text-xs text-[#722F37]"
                        >
                          {tg}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Ranked FTS5 Result Cards (Capped at 4 key data points per card) */}
                <div className="space-y-3">
                  {searchData?.results && searchData.results.length > 0 ? (
                    searchData.results.map((item, idx) => (
                      <div
                        key={item.producer_id}
                        className={`p-4 rounded-md border transition-all bg-white ${
                          idx === 0
                            ? "border-[#722F37] ring-1 ring-[#722F37]/20"
                            : "border-[#E5DEC9] hover:border-[#D6CEBF]"
                        }`}
                      >
                        {/* Data Point 1 & 2: Producer ID + Canonical Name + BM25 Rank */}
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded text-[11px] font-mono-code font-semibold bg-[#722F37]/10 text-[#722F37]">
                                #{idx + 1}
                              </span>
                              <span className="font-mono-code text-xs font-medium text-[#605659]">
                                {item.producer_id}
                              </span>
                              {/* Data Point 3: Country & State/AVA Region Badge */}
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-[#F3EFE6] text-[#1C1618] border border-[#E5DEC9]">
                                <Globe2 className="w-3 h-3 text-[#722F37]" />
                                {item.country}
                                {item.state_region
                                  ? ` • ${item.state_region}`
                                  : ""}
                              </span>
                            </div>
                            <h3 className="font-display-serif text-xl font-bold text-[#1C1618] pt-0.5">
                              {item.canonical_name}
                            </h3>
                          </div>

                          <div className="text-right">
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#2E6F40]/10 border border-[#2E6F40]/30 font-mono-code text-xs font-semibold text-[#2E6F40]">
                              <span>BM25: {item.rank.toFixed(4)}</span>
                            </div>
                          </div>
                        </div>

                        {/* Data Point 4: Pipe-separated Aliases */}
                        <div className="mt-3 pt-2.5 border-t border-[#F3EFE6]">
                          <div className="text-[11px] font-mono-code text-[#605659] mb-1.5">
                            ALIASES (Pipe-Separated{" "}
                            <code className="text-[#722F37]">
                              {item.aliases}
                            </code>
                            ):
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {item.aliases_list.map((alias) => (
                              <span
                                key={alias}
                                className="px-2.5 py-0.5 rounded text-xs font-mono-code bg-[#EFECE6] text-[#1C1618] border border-[#E5DEC9]"
                              >
                                {alias}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-8 text-center bg-white rounded-md border border-[#E5DEC9] text-[#605659] text-sm">
                      No matching trigrams found for &ldquo;{searchQuery}&rdquo;.
                      Try a broader brand token or test a noisy preset above.
                    </div>
                  )}
                </div>

                {/* Dark Slate Cellar SQL Terminal Block */}
                {searchData && (
                  <div className="bg-[#1E242B] text-[#F4F1EA] rounded-md p-4 border border-[#1C1618] space-y-2">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <div className="flex items-center gap-2 text-xs font-mono-code text-[#B8860B]">
                        <Terminal className="w-3.5 h-3.5" />
                        <span>
                          SQLite 3.40.1 FTS5 Query (dist/wine_gazetteer.sqlite)
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          copySqlToClipboard(searchData.sql_executed)
                        }
                        className="text-xs font-mono-code text-[#F4F1EA]/80 hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        {copiedSql ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-[#2E6F40]" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy SQL</span>
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="font-mono-code text-xs leading-relaxed overflow-x-auto text-[#F4F1EA]">
                      {searchData.sql_executed}
                    </pre>
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT 5 COLUMNS: Live Normalization Pipeline Sandbox & Quick Add */}
            <div className="lg:col-span-5 space-y-6">
              {/* Normalization Pipeline Sandbox */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-5">
                <div className="border-b border-[#E5DEC9] pb-4">
                  <span className="text-[11px] font-mono-code uppercase tracking-wider text-[#B8860B] font-semibold">
                    Section 3 Cleaning Pipeline Inspector
                  </span>
                  <h2 className="font-display-serif text-2xl font-bold text-[#1C1618]">
                    Normalization &amp; Alias Sandbox
                  </h2>
                  <p className="text-xs text-[#605659] mt-1">
                    Test any raw TTB legal entity string through Corporate
                    Suffix Stripping (3A), Diacritic Removal (3B), and
                    Abbreviation Expansion (3C).
                  </p>
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    executeNormalization(sandboxInput);
                  }}
                  className="space-y-3"
                >
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#605659]">
                    Raw Legal Entity / TTB Permit Holder Input
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={sandboxInput}
                      onChange={(e) => setSandboxInput(e.target.value)}
                      className="flex-1 h-[42px] px-3.5 bg-white border border-[#D6CEBF] rounded-md font-mono-code text-xs text-[#1C1618] focus:outline-none focus:ring-2 focus:ring-[#722F37]"
                      placeholder="e.g. CHATEAU MONTELENA WINERY, LLC"
                    />
                    <button
                      type="submit"
                      disabled={normalizing}
                      className="h-[42px] px-4 bg-[#722F37] hover:bg-[#5E252C] text-[#FBF9F5] text-xs font-medium rounded-md transition-colors shrink-0 cursor-pointer"
                    >
                      {normalizing ? "Running..." : "Transform"}
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {SANDBOX_PRESETS.map((sample) => (
                      <button
                        key={sample}
                        type="button"
                        onClick={() => {
                          setSandboxInput(sample);
                          executeNormalization(sample);
                        }}
                        className="px-2 py-1 rounded text-[11px] font-mono-code bg-[#EFECE6] hover:bg-[#E5DEC9] text-[#1C1618] border border-[#E5DEC9] transition-colors cursor-pointer"
                      >
                        {sample}
                      </button>
                    ))}
                  </div>
                </form>

                {normData && (
                  <div className="space-y-3.5 pt-1">
                    {/* Stage 3A */}
                    <div className="bg-white rounded-md p-4 border border-[#E5DEC9] space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#722F37] uppercase tracking-wider">
                          Stage A • Corporate Suffix &amp; Noise Stripping
                        </span>
                        <span className="text-[11px] font-mono-code text-[#2E6F40] bg-[#2E6F40]/10 px-2 py-0.5 rounded">
                          Cleaned
                        </span>
                      </div>
                      <div className="font-mono-code text-xs text-[#1C1618] bg-[#FBF9F5] p-2.5 rounded border border-[#E5DEC9]">
                        {normData.stage_a.output}
                      </div>
                      <div className="flex flex-wrap gap-1.5 text-[11px]">
                        {normData.stage_a.stripped_corporate_suffixes.length >
                        0 ? (
                          normData.stage_a.stripped_corporate_suffixes.map(
                            (tok) => (
                              <span
                                key={tok}
                                className="px-2 py-0.5 rounded bg-[#B91C1C]/10 text-[#B91C1C] font-mono-code line-through"
                              >
                                {tok}
                              </span>
                            )
                          )
                        ) : (
                          <span className="text-[#605659]">
                            No trailing legal suffixes present
                          </span>
                        )}
                        {normData.stage_a.detected_trade_descriptors.map(
                          (td) => (
                            <span
                              key={td}
                              className="px-2 py-0.5 rounded bg-[#D97706]/15 text-[#D97706] font-mono-code"
                            >
                              Trade Token: {td}
                            </span>
                          )
                        )}
                      </div>
                    </div>

                    {/* Stage 3B */}
                    <div className="bg-white rounded-md p-4 border border-[#E5DEC9] space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#722F37] uppercase tracking-wider">
                          Stage B • Diacritic &amp; ASCII Normalization
                        </span>
                        <span className="text-[11px] font-mono-code text-[#605659]">
                          NFD &rarr; ASCII
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div className="p-2.5 rounded bg-[#FBF9F5] border border-[#E5DEC9]">
                          <div className="text-[10px] uppercase text-[#605659] font-semibold">
                            Canonical Display Name
                          </div>
                          <div className="font-display-serif text-base font-bold text-[#1C1618] mt-0.5">
                            {normData.stage_c.canonical_name}
                          </div>
                        </div>
                        <div className="p-2.5 rounded bg-[#FBF9F5] border border-[#E5DEC9]">
                          <div className="text-[10px] uppercase text-[#605659] font-semibold">
                            ASCII Folded Form
                          </div>
                          <div className="font-mono-code text-xs font-semibold text-[#1C1618] mt-1">
                            {normData.stage_b.output}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Stage 3C */}
                    <div className="bg-white rounded-md p-4 border border-[#E5DEC9] space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#722F37] uppercase tracking-wider">
                          Stage C • Abbreviation Expansion &amp; Aliases
                        </span>
                        <span className="text-[11px] font-mono-code text-[#722F37]">
                          {normData.stage_c.aliases_list.length} Variants
                        </span>
                      </div>
                      <div className="p-2.5 rounded bg-[#1E242B] text-[#F4F1EA] font-mono-code text-xs overflow-x-auto">
                        {normData.stage_c.aliases_pipe}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {normData.stage_c.aliases_list.map((al) => (
                          <span
                            key={al}
                            className="px-2.5 py-1 rounded text-xs font-mono-code bg-[#EFECE6] text-[#722F37] border border-[#E5DEC9]"
                          >
                            {al}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Register / Upsert New TTB Producer Record */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-[#E5DEC9] pb-3">
                  <div>
                    <span className="text-[11px] font-mono-code uppercase tracking-wider text-[#722F37] font-semibold">
                      Live Registry Sync
                    </span>
                    <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                      Ingest Custom TTB COLA Permit
                    </h3>
                  </div>
                  <PlusCircle className="w-5 h-5 text-[#722F37]" />
                </div>

                <form onSubmit={handleUpsertSubmit} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-[#605659] mb-1">
                        TTB Permit ID
                      </label>
                      <input
                        type="text"
                        value={newPermitId}
                        onChange={(e) => setNewPermitId(e.target.value)}
                        className="w-full h-9 px-3 bg-white border border-[#D6CEBF] rounded text-xs font-mono-code text-[#1C1618]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-[#605659] mb-1">
                        Country
                      </label>
                      <input
                        type="text"
                        value={newCountry}
                        onChange={(e) => setNewCountry(e.target.value)}
                        className="w-full h-9 px-3 bg-white border border-[#D6CEBF] rounded text-xs text-[#1C1618]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#605659] mb-1">
                      Raw TTB Legal Entity Name (Auto-Normalized)
                    </label>
                    <input
                      type="text"
                      value={newRawLegalName}
                      onChange={(e) => setNewRawLegalName(e.target.value)}
                      placeholder="e.g. DOM. ST. HELENA VNYDS, LLC"
                      className="w-full h-9 px-3 bg-white border border-[#D6CEBF] rounded text-xs font-mono-code text-[#1C1618]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-[#605659] mb-1">
                        State / AVA Region
                      </label>
                      <input
                        type="text"
                        value={newStateRegion}
                        onChange={(e) => setNewStateRegion(e.target.value)}
                        className="w-full h-9 px-3 bg-white border border-[#D6CEBF] rounded text-xs text-[#1C1618]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-[#605659] mb-1">
                        Custom Aliases (Optional Pipe String)
                      </label>
                      <input
                        type="text"
                        value={newCustomAliases}
                        onChange={(e) => setNewCustomAliases(e.target.value)}
                        placeholder="Auto-generated if blank"
                        className="w-full h-9 px-3 bg-white border border-[#D6CEBF] rounded text-xs font-mono-code text-[#1C1618]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={upserting}
                    className="w-full h-10 bg-[#722F37] hover:bg-[#5E252C] text-[#FBF9F5] text-xs font-medium rounded-md transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>
                      {upserting
                        ? "Normalizing & Indexing into FTS5..."
                        : "Normalize & Index into SQLite FTS5 + Postgres"}
                    </span>
                  </button>

                  {upsertBanner && (
                    <div className="p-3 rounded bg-[#2E6F40]/10 border border-[#2E6F40]/30 text-xs text-[#2E6F40] font-mono-code">
                      ✓ {upsertBanner}
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: NORMALIZATION PIPELINE SPECIFICATION & BENCHMARK LOGS */}
        {activeTab === "pipeline" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Rule A Card */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded text-xs font-mono-code font-semibold bg-[#722F37] text-[#FBF9F5]">
                    Section 3A
                  </span>
                  <Layers className="w-4 h-4 text-[#722F37]" />
                </div>
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Corporate Suffix &amp; Noise Stripping
                </h3>
                <p className="text-xs text-[#605659] leading-relaxed">
                  Strips legal and corporate boilerplate to isolate the core
                  consumer-facing brand name across all 92,500+ TTB permit
                  records.
                </p>
                <div className="space-y-2 pt-2">
                  <div className="text-[11px] font-semibold uppercase text-[#605659]">
                    Removed Corporate Suffixes:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      "LLC",
                      "L.L.C.",
                      "INC",
                      "INC.",
                      "CORP",
                      "CORP.",
                      "CO.",
                      "LTD",
                      "LTD.",
                      "LP",
                      "L.P.",
                    ].map((s) => (
                      <span
                        key={s}
                        className="px-2 py-0.5 rounded bg-white border border-[#E5DEC9] font-mono-code text-xs text-[#B91C1C] line-through"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                  <div className="text-[11px] font-semibold uppercase text-[#605659] pt-2">
                    Removed Trade / Permit Noise:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      "WINERY LLC",
                      "CELLARS INC",
                      "VINEYARDS LLC",
                      "IMPORTS CO",
                      "DISTILLING CO",
                    ].map((s) => (
                      <span
                        key={s}
                        className="px-2 py-0.5 rounded bg-[#EFECE6] border border-[#E5DEC9] font-mono-code text-xs text-[#722F37]"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Rule B Card */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded text-xs font-mono-code font-semibold bg-[#722F37] text-[#FBF9F5]">
                    Section 3B
                  </span>
                  <Sparkles className="w-4 h-4 text-[#B8860B]" />
                </div>
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Character &amp; Diacritic Normalization
                </h3>
                <p className="text-xs text-[#605659] leading-relaxed">
                  Maps accented Unicode characters via NFD decomposition to
                  ASCII equivalents and normalizes spacing, hyphens, and curly
                  quotes.
                </p>
                <div className="space-y-2 pt-2 font-mono-code text-xs">
                  {[
                    ["Château Montelena", "Chateau Montelena"],
                    ["Bodega Viña Cobos", "Bodega Vina Cobos"],
                    ["Domaine Romanée-Conti", "Domaine Romanee-Conti"],
                    ["St. Supéry Estate", "St Supery Estate"],
                    ["Weingut Egon Müller", "Weingut Egon Muller"],
                  ].map(([src, dst]) => (
                    <div
                      key={src}
                      className="flex items-center justify-between p-2 rounded bg-white border border-[#E5DEC9]"
                    >
                      <span className="text-[#605659]">{src}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#722F37] shrink-0" />
                      <span className="font-semibold text-[#1C1618]">
                        {dst}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Rule C Card */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded text-xs font-mono-code font-semibold bg-[#722F37] text-[#FBF9F5]">
                    Section 3C
                  </span>
                  <Activity className="w-4 h-4 text-[#2E6F40]" />
                </div>
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Abbreviation Expansion &amp; Aliases
                </h3>
                <p className="text-xs text-[#605659] leading-relaxed">
                  Expands standard viticultural abbreviations into full search
                  aliases and isolates core brand tokens separated by{" "}
                  <code className="font-mono-code text-[#722F37]">|</code>.
                </p>
                <div className="space-y-2 pt-2 font-mono-code text-xs">
                  {[
                    ["St. / St", "Saint"],
                    ["Mt. / Mt", "Mount"],
                    ["Vnyd / Vnyds", "Vineyard / Vineyards"],
                    ["Dom.", "Domaine"],
                    ["Ch.", "Chateau"],
                  ].map(([abbr, exp]) => (
                    <div
                      key={abbr}
                      className="flex items-center justify-between p-2 rounded bg-white border border-[#E5DEC9]"
                    >
                      <span className="text-[#722F37] font-semibold">
                        {abbr}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#605659]" />
                      <span className="text-[#2E6F40] font-semibold">
                        {exp}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Canonical Example Transformation Banner */}
            <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6">
              <div className="text-xs font-mono-code uppercase tracking-wider text-[#722F37] font-semibold mb-3">
                Reference Transformation Benchmark (Section 3C Specification)
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded bg-white border border-[#E5DEC9]">
                  <div className="text-xs text-[#605659] uppercase font-semibold">
                    1. Raw Legal Entity (TTB Registry)
                  </div>
                  <div className="mt-2 font-mono-code text-sm font-bold text-[#B91C1C]">
                    &quot;CHATEAU MONTELENA WINERY, LLC&quot;
                  </div>
                </div>
                <div className="p-4 rounded bg-white border border-[#E5DEC9]">
                  <div className="text-xs text-[#605659] uppercase font-semibold">
                    2. Canonical Name (Cleaned)
                  </div>
                  <div className="mt-2 font-display-serif text-xl font-bold text-[#1C1618]">
                    &quot;Château Montelena Winery&quot;
                  </div>
                </div>
                <div className="p-4 rounded bg-white border border-[#E5DEC9]">
                  <div className="text-xs text-[#605659] uppercase font-semibold">
                    3. Generated Pipe-Separated Aliases
                  </div>
                  <div className="mt-2 font-mono-code text-xs font-semibold text-[#2E6F40] break-all">
                    &quot;Chateau Montelena Winery|Chateau Montelena|Montelena
                    Winery|Montelena&quot;
                  </div>
                </div>
              </div>
            </div>

            {/* Recent FTS5 Search Benchmarks & Curated Records */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Recent Fuzzy Trigram Search Audit Log (PostgreSQL)
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-[#E5DEC9] text-[#605659] font-mono-code uppercase">
                        <th className="py-2 pr-3">Noisy Input</th>
                        <th className="py-2 px-3">Top Canonical Match</th>
                        <th className="py-2 px-3">BM25</th>
                        <th className="py-2 pl-3 text-right">Latency</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E5DEC9]">
                      {benchmarks.map((b) => (
                        <tr key={b.id} className="hover:bg-white/60">
                          <td className="py-2.5 pr-3 font-mono-code text-[#722F37]">
                            {b.rawQuery}
                          </td>
                          <td className="py-2.5 px-3 font-medium text-[#1C1618]">
                            {b.matchedCanonicalName}
                          </td>
                          <td className="py-2.5 px-3 font-mono-code text-[#2E6F40]">
                            {b.bm25Rank.toFixed(2)}
                          </td>
                          <td className="py-2.5 pl-3 font-mono-code text-right text-[#605659]">
                            {b.latencyMs} ms
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Curated &amp; Synced TTB Permit Entities
                </h3>
                <div className="space-y-2.5">
                  {customProducers.map((cp) => (
                    <div
                      key={cp.id}
                      className="p-3.5 rounded bg-white border border-[#E5DEC9] flex flex-col gap-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono-code text-xs text-[#722F37] font-semibold">
                          {cp.producerId}
                        </span>
                        <span className="text-xs text-[#605659]">
                          {cp.country} • {cp.stateRegion}
                        </span>
                      </div>
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="font-display-serif text-lg font-bold text-[#1C1618]">
                          {cp.canonicalName}
                        </span>
                        <span className="font-mono-code text-[11px] text-[#605659] line-through">
                          {cp.rawLegalName}
                        </span>
                      </div>
                      <div className="font-mono-code text-xs text-[#2E6F40] bg-[#FBF9F5] px-2.5 py-1 rounded border border-[#E5DEC9]">
                        {cp.aliases}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SCHEMA & INGESTION PIPELINE CONSOLE */}
        {activeTab === "schema" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left 6 Cols: SQLite Schema DDL & Standalone Script Trigger */}
            <div className="lg:col-span-6 space-y-6">
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono-code uppercase text-[#722F37] font-semibold">
                      Section 2 Specification
                    </span>
                    <h2 className="font-display-serif text-2xl font-bold text-[#1C1618]">
                      SQLite FTS5 Trigram Schema
                    </h2>
                  </div>
                  <FileCode2 className="w-5 h-5 text-[#722F37]" />
                </div>

                <div className="bg-[#1E242B] text-[#F4F1EA] rounded-md p-4 border border-[#1C1618]">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-3 text-xs font-mono-code text-[#B8860B]">
                    <span>dist/wine_gazetteer.sqlite • DDL</span>
                    <button
                      type="button"
                      onClick={() => copySqlToClipboard(SCHEMA_DDL_SQL)}
                      className="text-[#F4F1EA]/80 hover:text-white flex items-center gap-1 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy DDL</span>
                    </button>
                  </div>
                  <pre className="font-mono-code text-xs leading-relaxed overflow-x-auto">
                    {SCHEMA_DDL_SQL}
                  </pre>
                </div>

                {/* Standalone Pipeline Rebuild Control */}
                <div className="p-4 rounded-md bg-white border border-[#E5DEC9] space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-sm text-[#1C1618]">
                        Standalone Ingestion Pipeline Execution
                      </h3>
                      <p className="text-xs text-[#605659] font-mono-code mt-0.5">
                        $ python pipeline/fetch_ttb_producers.py
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleRebuildDatabase}
                      disabled={rebuilding}
                      className="px-4 py-2 rounded-md bg-[#722F37] hover:bg-[#5E252C] text-[#FBF9F5] text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer disabled:opacity-60"
                    >
                      <RefreshCw
                        className={`w-3.5 h-3.5 ${
                          rebuilding ? "animate-spin" : ""
                        }`}
                      />
                      <span>
                        {rebuilding
                          ? "Rebuilding SQLite FTS5..."
                          : "Run Pipeline Rebuild"}
                      </span>
                    </button>
                  </div>
                  {rebuildBanner && (
                    <div className="p-3 rounded bg-[#2E6F40]/10 border border-[#2E6F40]/30 text-xs font-mono-code text-[#2E6F40]">
                      ✓ {rebuildBanner}
                    </div>
                  )}
                </div>
              </div>

              {/* Section 5 Verification Output */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <span className="text-xs font-mono-code uppercase text-[#2E6F40] font-semibold">
                  Section 5 Verification Query Output
                </span>
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Live Trigram Verification (`MATCH &apos;Chateau Montelena&apos;`)
                </h3>
                <div className="space-y-2">
                  {(sqliteStats?.verification_results || []).map((row, i) => (
                    <div
                      key={row.producer_id}
                      className="p-3 rounded bg-white border border-[#E5DEC9] flex flex-col gap-1"
                    >
                      <div className="flex items-center justify-between text-xs font-mono-code">
                        <span className="font-bold text-[#722F37]">
                          #{i + 1} • {row.producer_id}
                        </span>
                        <span className="text-[#2E6F40] font-semibold">
                          rank: {row.rank}
                        </span>
                      </div>
                      <div className="font-display-serif text-lg font-bold text-[#1C1618]">
                        {row.canonical_name}
                      </div>
                      <div className="font-mono-code text-xs text-[#605659]">
                        {row.aliases}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right 6 Cols: Country/AVA Distribution & Ingestion Run Ledger */}
            <div className="lg:col-span-6 space-y-6">
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Indexed Producer Distribution by Country &amp; AVA
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-white rounded-md p-4 border border-[#E5DEC9] space-y-2">
                    <div className="text-xs font-semibold uppercase text-[#605659]">
                      Top Countries in Gazetteer
                    </div>
                    <div className="space-y-1.5">
                      {(sqliteStats?.countries || []).slice(0, 8).map((c) => (
                        <div
                          key={c.country}
                          className="flex items-center justify-between text-xs"
                        >
                          <span className="text-[#1C1618] font-medium">
                            {c.country}
                          </span>
                          <span className="font-mono-code text-[#722F37] font-semibold">
                            {c.count.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-md p-4 border border-[#E5DEC9] space-y-2">
                    <div className="text-xs font-semibold uppercase text-[#605659]">
                      Top Wine Regions / AVAs
                    </div>
                    <div className="space-y-1.5">
                      {(sqliteStats?.regions || []).slice(0, 8).map((r) => (
                        <div
                          key={`${r.country}-${r.state_region}`}
                          className="flex items-center justify-between text-xs gap-2"
                        >
                          <span className="text-[#1C1618] truncate">
                            {r.state_region}
                          </span>
                          <span className="font-mono-code text-[#605659] shrink-0">
                            {r.count.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Pipeline Ingestion Run History */}
              <div className="bg-[#F3EFE6] border border-[#E5DEC9] rounded-md p-6 space-y-4">
                <h3 className="font-display-serif text-xl font-bold text-[#1C1618]">
                  Pipeline Build &amp; Indexing Telemetry (`ingestion_runs`)
                </h3>
                <div className="space-y-3">
                  {ingestionRuns.map((run) => (
                    <div
                      key={run.id}
                      className="p-4 rounded bg-white border border-[#E5DEC9] space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono-code text-xs font-bold text-[#722F37]">
                          {run.runCode}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[11px] font-mono-code bg-[#2E6F40]/10 text-[#2E6F40] font-semibold uppercase">
                          {run.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs font-mono-code pt-1">
                        <div>
                          <span className="text-[#605659] block text-[10px]">
                            PRODUCERS
                          </span>
                          <span className="font-bold text-[#1C1618]">
                            {run.canonicalProducersCount.toLocaleString()}
                          </span>
                        </div>
                        <div>
                          <span className="text-[#605659] block text-[10px]">
                            SQLITE SIZE
                          </span>
                          <span className="font-bold text-[#1C1618]">
                            {run.fileSizeMb} MB
                          </span>
                        </div>
                        <div>
                          <span className="text-[#605659] block text-[10px]">
                            BUILD TIME
                          </span>
                          <span className="font-bold text-[#1C1618]">
                            {run.durationSec}s
                          </span>
                        </div>
                      </div>
                      {run.notes && (
                        <p className="text-xs text-[#605659] pt-1 border-t border-[#F3EFE6]">
                          {run.notes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
