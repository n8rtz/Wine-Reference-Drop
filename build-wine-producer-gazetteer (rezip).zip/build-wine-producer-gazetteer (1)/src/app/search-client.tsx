"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Hit = {
  producer_id: string;
  canonical_name: string;
  aliases: string[];
  country: string;
  state_region: string | null;
  rank: number;
  score: number;
};

const EXAMPLES = [
  "Chateau Montelena",
  "chateau montalena winery llc",
  "Ridge Vnyds",
  "St Supery",
  "Mt Veeder",
  "Bodega Viña",
];

export default function SearchClient() {
  const [query, setQuery] = useState("Chateau Montelena");
  const [hits, setHits] = useState<Hit[]>([]);
  const [normalized, setNormalized] = useState("");
  const [tookMs, setTookMs] = useState(0);
  const [loading, setLoading] = useState(false);
  const seq = useRef(0);

  const run = useCallback(async (value: string) => {
    const id = ++seq.current;
    if (value.trim().length < 3) {
      setHits([]);
      setNormalized("");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/gazetteer/search?q=${encodeURIComponent(value)}&limit=10`);
      const data = await res.json();
      if (id !== seq.current) return;
      setHits(data.hits ?? []);
      setNormalized(data.normalized ?? "");
      setTookMs(data.tookMs ?? 0);
    } catch {
      if (id === seq.current) setHits([]);
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => void run(query), 220);
    return () => clearTimeout(t);
  }, [query, run]);

  return (
    <div className="w-full">
      <div className="relative">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type a noisy producer / brand string…"
          className="w-full rounded-2xl border border-rose-200 bg-white/90 px-5 py-4 text-lg text-slate-900 shadow-sm outline-none ring-rose-300 transition focus:ring-2"
        />
        <span className="pointer-events-none absolute right-5 top-1/2 -translate-y-1/2 text-sm text-slate-400">
          {loading ? "searching…" : hits.length ? `${hits.length} hits · ${tookMs}ms` : ""}
        </span>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        {EXAMPLES.map((ex) => (
          <button
            key={ex}
            onClick={() => setQuery(ex)}
            className="rounded-full border border-rose-200 bg-white px-3 py-1 text-xs font-medium text-rose-800 transition hover:bg-rose-50"
          >
            {ex}
          </button>
        ))}
      </div>

      {normalized ? (
        <p className="mt-3 font-mono text-xs text-slate-500">
          trigram query → <span className="text-rose-700">{normalized}</span>
        </p>
      ) : null}

      <ul className="mt-6 space-y-3">
        {hits.map((hit) => (
          <li
            key={hit.producer_id}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_8px_24px_rgba(16,24,40,0.06)]"
          >
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h3 className="text-lg font-semibold text-slate-900">{hit.canonical_name}</h3>
              <div className="flex items-center gap-3 font-mono text-xs text-slate-500">
                <span>score {hit.score.toFixed(3)}</span>
                <span>bm25 {hit.rank.toFixed(2)}</span>
              </div>
            </div>
            <p className="mt-1 text-sm text-slate-600">
              {[hit.state_region, hit.country].filter(Boolean).join(" · ")}
              <span className="ml-2 font-mono text-xs text-slate-400">{hit.producer_id}</span>
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {hit.aliases.map((a) => (
                <span
                  key={a}
                  className="rounded-md bg-rose-50 px-2 py-1 text-xs text-rose-900"
                >
                  {a}
                </span>
              ))}
            </div>
          </li>
        ))}
      </ul>

      {!loading && query.trim().length >= 3 && hits.length === 0 ? (
        <p className="mt-6 rounded-2xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
          No trigram matches. Try a longer fragment of the brand name.
        </p>
      ) : null}
    </div>
  );
}
