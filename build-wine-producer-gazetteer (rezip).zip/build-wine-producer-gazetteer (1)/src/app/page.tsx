import { getStats } from "@/lib/gazetteer";
import SearchClient from "./search-client";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const stats = getStats();

  return (
    <main className="min-h-screen bg-gradient-to-b from-rose-50 via-white to-amber-50 px-6 py-14">
      <div className="mx-auto w-full max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-700">
          TTB COLA / FOIA permit registry · public domain
        </p>
        <h1 className="mt-3 text-[clamp(2rem,5vw,3rem)] font-semibold leading-tight text-slate-950">
          US Wine Producer Gazetteer
        </h1>
        <p className="mt-3 max-w-2xl text-slate-700">
          Fuzzy lookup over an FTS5 <span className="font-mono text-sm">trigram</span> index of
          cleaned TTB permit holders and brand names. Legal boilerplate is stripped, diacritics are
          folded, and abbreviations (St → Saint, Vnyd → Vineyard, Ch. → Château) are expanded into
          searchable aliases.
        </p>

        <dl className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Producers" value={stats.producers.toLocaleString()} />
          <Stat label="Index" value="FTS5 trigram" />
          <Stat label="DB size" value={`${stats.sizeMb} MB`} />
          <Stat label="Built" value={stats.builtAt ? stats.builtAt.slice(0, 10) : "—"} />
        </dl>

        {!stats.available || stats.producers === 0 ? (
          <p className="mt-6 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">
            Gazetteer not found. Build it with{" "}
            <code className="font-mono">python pipeline/fetch_ttb_producers.py</code>.
          </p>
        ) : null}

        <section className="mt-10">
          <SearchClient />
        </section>

        <section className="mt-12 rounded-2xl border border-slate-200 bg-white/70 p-6 text-sm text-slate-700">
          <h2 className="text-base font-semibold text-slate-900">Reference query</h2>
          <pre className="mt-3 overflow-x-auto rounded-xl bg-slate-900 p-4 font-mono text-xs leading-relaxed text-slate-100">{`SELECT producer_id, canonical_name, aliases, bm25(producers_fts) AS rank
FROM producers_fts
WHERE producers_fts MATCH 'Chateau Montelena'
ORDER BY rank ASC
LIMIT 5;`}</pre>
          <p className="mt-3">
            Database: <code className="font-mono">dist/wine_gazetteer.sqlite</code> · Source:{" "}
            {stats.source ?? "TTB FOIA List of Permittees"}
          </p>
        </section>
      </div>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <dt className="text-[11px] uppercase tracking-wide text-slate-500">{label}</dt>
      <dd className="mt-1 text-lg font-semibold text-slate-900">{value}</dd>
    </div>
  );
}
