import { db } from "@/db";
import { searchLog } from "@/db/schema";
import { searchProducers, normalizeQuery } from "@/lib/gazetteer";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = (url.searchParams.get("q") ?? "").trim();
  const limit = Math.min(Number(url.searchParams.get("limit") ?? 10) || 10, 50);

  if (q.length < 3) {
    return Response.json({ query: q, normalized: "", tookMs: 0, hits: [] });
  }

  const started = Date.now();
  const hits = searchProducers(q, limit);
  const tookMs = Date.now() - started;

  try {
    await db.insert(searchLog).values({
      query: q,
      hits: hits.length,
      topMatch: hits[0]?.canonical_name ?? null,
      tookMs,
    });
  } catch {
    /* telemetry is best-effort */
  }

  return Response.json({
    query: q,
    normalized: normalizeQuery(q),
    tookMs,
    hits,
  });
}
