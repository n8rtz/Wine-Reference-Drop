import { desc } from "drizzle-orm";
import { db } from "@/db";
import { searchLog } from "@/db/schema";
import { getStats } from "@/lib/gazetteer";

export const dynamic = "force-dynamic";

export async function GET() {
  const stats = getStats();
  let recent: { query: string; hits: number; topMatch: string | null }[] = [];
  try {
    const rows = await db
      .select()
      .from(searchLog)
      .orderBy(desc(searchLog.createdAt))
      .limit(8);
    recent = rows.map((r) => ({ query: r.query, hits: r.hits, topMatch: r.topMatch }));
  } catch {
    recent = [];
  }
  return Response.json({ ...stats, recent });
}
