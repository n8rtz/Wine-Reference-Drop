import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

/**
 * Query telemetry for the gazetteer lookup service.
 * The producer gazetteer itself lives in dist/wine_gazetteer.sqlite (FTS5 trigram).
 */
export const searchLog = pgTable("search_log", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  hits: integer("hits").notNull().default(0),
  topMatch: text("top_match"),
  tookMs: integer("took_ms").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type SearchLogRow = typeof searchLog.$inferSelect;
