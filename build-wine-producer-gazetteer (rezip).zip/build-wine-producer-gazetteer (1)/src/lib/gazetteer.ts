import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import fs from "node:fs";

export const GAZETTEER_PATH =
  process.env.GAZETTEER_DB ?? path.join(process.cwd(), "dist", "wine_gazetteer.sqlite");

export type ProducerHit = {
  producer_id: string;
  canonical_name: string;
  aliases: string[];
  country: string;
  state_region: string | null;
  rank: number;
  score: number;
};

export type GazetteerStats = {
  available: boolean;
  producers: number;
  builtAt: string | null;
  source: string | null;
  sizeMb: number;
};

type RawRow = {
  producer_id: string;
  canonical_name: string;
  aliases: string | null;
  country: string | null;
  rank: number;
};

const globalForDb = globalThis as typeof globalThis & {
  __gazetteerDb?: DatabaseSync | null;
};

function open(): DatabaseSync | null {
  if (globalForDb.__gazetteerDb !== undefined) return globalForDb.__gazetteerDb;
  let handle: DatabaseSync | null = null;
  try {
    if (fs.existsSync(GAZETTEER_PATH)) {
      handle = new DatabaseSync(GAZETTEER_PATH, { readOnly: true });
    }
  } catch {
    handle = null;
  }
  globalForDb.__gazetteerDb = handle;
  return handle;
}

/** Fold accents + punctuation so noisy user input matches the ASCII index. */
export function foldAscii(input: string): string {
  return input
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[’‘`´]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[-–—]/g, " ")
    .replace(/&/g, " and ")
    .replace(/[^A-Za-z0-9' ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const STOP_SUFFIX =
  /\b(llc|l\.l\.c\.|inc|inc\.|corp|corp\.|co|co\.|ltd|ltd\.|lp|l\.p\.)\b/gi;

/** Query-side mirror of the pipeline abbreviation expansion. */
const ABBREV: Record<string, string> = {
  st: "saint", ste: "sainte", mt: "mount", mtn: "mountain",
  vnyd: "vineyard", vnyds: "vineyards", vyd: "vineyard", vyds: "vineyards",
  vnyrd: "vineyard", dom: "domaine", ch: "chateau", cht: "chateau",
  cllrs: "cellars", wnry: "winery", bros: "brothers", ft: "fort",
};

export function normalizeQuery(input: string): string {
  const folded = foldAscii(input.replace(STOP_SUFFIX, " ")).toLowerCase();
  return folded
    .split(" ")
    .filter(Boolean)
    .map((t) => ABBREV[t.replace(/[.']/g, "")] ?? t)
    .join(" ");
}

function ftsPhrase(term: string): string {
  return `"${term.replace(/"/g, " ")}"`;
}

/** Cheap normalized edit-distance-ish similarity for re-ranking. */
function similarity(a: string, b: string): number {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  if (!x || !y) return 0;
  if (x === y) return 1;
  const grams = (s: string) => {
    const out = new Set<string>();
    const padded = `  ${s} `;
    for (let i = 0; i < padded.length - 2; i++) out.add(padded.slice(i, i + 3));
    return out;
  };
  const gx = grams(x);
  const gy = grams(y);
  let shared = 0;
  for (const g of gx) if (gy.has(g)) shared++;
  return (2 * shared) / (gx.size + gy.size);
}

/**
 * Blend whole-string trigram Dice similarity with a length-weighted per-token
 * best match so distinctive tokens ("montelena") outweigh generic ones ("winery").
 */
function scoreMatch(queryTokens: string[], normalizedQuery: string, candidate: string): number {
  const whole = similarity(normalizedQuery, candidate);
  if (!queryTokens.length) return whole;
  const candTokens = candidate.toLowerCase().split(/\s+/).filter(Boolean);
  if (!candTokens.length) return whole;
  let weighted = 0;
  let weight = 0;
  for (const qt of queryTokens) {
    let best = 0;
    for (const ct of candTokens) best = Math.max(best, similarity(qt, ct));
    weighted += best * qt.length;
    weight += qt.length;
  }
  return 0.5 * whole + 0.5 * (weighted / Math.max(weight, 1));
}

export function searchProducers(query: string, limit = 10): ProducerHit[] {
  const db = open();
  const normalized = normalizeQuery(query);
  if (!db || normalized.length < 3) return [];

  const tokens = normalized.split(" ").filter((t) => t.length >= 3);
  const expressions: string[] = [ftsPhrase(normalized)];
  if (tokens.length > 1) {
    expressions.push(tokens.map(ftsPhrase).join(" AND "));
    expressions.push(tokens.map(ftsPhrase).join(" OR "));
  }

  // Typo-tolerant fallback: split long tokens into head/tail trigram chunks so a
  // single-character substitution ("montalena") still reaches "montelena".
  const chunked = tokens.map((t) =>
    t.length >= 6 ? `(${ftsPhrase(t.slice(0, 4))} AND ${ftsPhrase(t.slice(-4))})` : ftsPhrase(t),
  );
  if (chunked.length) {
    expressions.push(chunked.join(" AND "));
    if (chunked.length > 1) expressions.push(chunked.join(" OR "));
  }

  const seen = new Map<string, ProducerHit>();
  for (const expr of expressions) {
    let rows: RawRow[] = [];
    try {
      rows = db
        .prepare(
          `SELECT producer_id, canonical_name, aliases, country, bm25(producers_fts) AS rank
           FROM producers_fts
           WHERE producers_fts MATCH ?
           ORDER BY rank ASC
           LIMIT ?`,
        )
        .all(expr, limit * 6) as unknown as RawRow[];
    } catch {
      rows = [];
    }
    for (const row of rows) {
      if (seen.has(row.producer_id)) continue;
      const aliases = (row.aliases ?? "").split("|").filter(Boolean);
      const allNames = [row.canonical_name, ...aliases];
      const best = Math.max(
        ...allNames.map((n) => scoreMatch(tokens, normalized, foldAscii(n).toLowerCase())),
      );
      seen.set(row.producer_id, {
        producer_id: row.producer_id,
        canonical_name: row.canonical_name,
        aliases,
        country: row.country ?? "United States",
        state_region: null,
        rank: row.rank,
        score: Math.round(best * 1000) / 1000,
      });
    }
    const strong = [...seen.values()].some((h) => h.score >= 0.75);
    if (strong && seen.size >= limit) break;
  }

  const hits = [...seen.values()].sort((a, b) => b.score - a.score || a.rank - b.rank);
  const top = hits.slice(0, limit);

  if (top.length) {
    const placeholders = top.map(() => "?").join(",");
    try {
      const meta = db
        .prepare(
          `SELECT producer_id, state_region FROM producers WHERE producer_id IN (${placeholders})`,
        )
        .all(...top.map((h) => h.producer_id)) as unknown as {
        producer_id: string;
        state_region: string | null;
      }[];
      const byId = new Map(meta.map((m) => [m.producer_id, m.state_region]));
      for (const hit of top) hit.state_region = byId.get(hit.producer_id) ?? null;
    } catch {
      /* ignore */
    }
  }
  return top;
}

export function getStats(): GazetteerStats {
  const db = open();
  if (!db) {
    return { available: false, producers: 0, builtAt: null, source: null, sizeMb: 0 };
  }
  let producers = 0;
  let builtAt: string | null = null;
  let source: string | null = null;
  try {
    const row = db.prepare("SELECT COUNT(*) AS c FROM producers").get() as unknown as {
      c: number;
    };
    producers = Number(row?.c ?? 0);
    const meta = db.prepare("SELECT key, value FROM gazetteer_meta").all() as unknown as {
      key: string;
      value: string;
    }[];
    for (const m of meta) {
      if (m.key === "built_at") builtAt = m.value;
      if (m.key === "source") source = m.value;
    }
  } catch {
    /* ignore */
  }
  let sizeMb = 0;
  try {
    sizeMb = Math.round((fs.statSync(GAZETTEER_PATH).size / 1e6) * 10) / 10;
  } catch {
    /* ignore */
  }
  return { available: true, producers, builtAt, source, sizeMb };
}

export function sampleProducers(limit = 8): { producer_id: string; canonical_name: string }[] {
  const db = open();
  if (!db) return [];
  try {
    return db
      .prepare(
        `SELECT producer_id, canonical_name FROM producers
         WHERE canonical_name LIKE '%Vineyard%' OR canonical_name LIKE '%Cellars%'
         LIMIT ?`,
      )
      .all(limit) as unknown as { producer_id: string; canonical_name: string }[];
  } catch {
    return [];
  }
}
