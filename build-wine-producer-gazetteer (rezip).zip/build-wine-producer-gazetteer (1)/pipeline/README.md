# US TTB Wine Producer Gazetteer

`fetch_ttb_producers.py` is a **standalone, stdlib-only** ingestion script that builds
`dist/wine_gazetteer.sqlite`, a fuzzy-lookup reference database of US alcohol
permit holders / brands (wine producers & blenders, importers, wholesalers,
spirits producers, Puerto Rico permits).

## Run

```bash
python pipeline/fetch_ttb_producers.py                 # fetch + build + verify
python pipeline/fetch_ttb_producers.py --offline       # use pipeline/.cache only
python pipeline/fetch_ttb_producers.py --verify-only   # sample FTS queries
python pipeline/fetch_ttb_producers.py --min-entities 50000
```

Current build: **77,668 unique producer/brand entities** from 169,456 permit rows
(TTB FOIA "List of Permittees", public domain / CC0).

## Schema

```sql
CREATE TABLE producers (
    producer_id TEXT PRIMARY KEY,
    canonical_name TEXT NOT NULL,
    country TEXT DEFAULT 'United States',
    state_region TEXT,
    aliases TEXT            -- pipe separated normalized variants
);

CREATE VIRTUAL TABLE producers_fts USING fts5(
    producer_id UNINDEXED, canonical_name, aliases, country,
    tokenize = 'trigram'
);
```

`gazetteer_meta` stores the build timestamp, source URL and entity count.
The build runs `INSERT INTO producers_fts(producers_fts) VALUES('optimize')`,
`PRAGMA optimize` and `VACUUM`.

## Normalization

1. **Corporate suffix stripping** — `LLC, L.L.C., INC, INC., CORP, CORP., CO., LTD,
   LTD., LP, L.P.`, plus trade noise (`WINERY LLC`, `CELLARS INC`, `VINEYARDS LLC`,
   `IMPORTS CO`, `DISTILLING CO`, …) and dangling conjunctions.
2. **Character normalization** — NFKD diacritic folding (`Château → Chateau`,
   `Bodega Viña → Bodega Vina`), smart quote/hyphen/whitespace normalization,
   parenthetical removal, `DBA / AKA / T/A` splitting.
3. **Abbreviation expansion → aliases** — `St./St → Saint`, `Mt./Mt → Mount`,
   `Vnyd/Vnyds → Vineyard/Vineyards`, `Dom. → Domaine`, `Ch. → Chateau`,
   plus short-brand forms with trade descriptors dropped.

Example: `"CHATEAU MONTELENA WINERY, LLC"` →
canonical `Château Montelena Winery`, aliases
`Chateau Montelena Winery|Chateau Montelena|Montelena Winery|Montelena`.

Deduplication key = alphanumeric, abbreviation-expanded, suffix-stripped name.

## Verify

```sql
SELECT producer_id, canonical_name, aliases, bm25(producers_fts) AS rank
FROM producers_fts
WHERE producers_fts MATCH 'Chateau Montelena'
ORDER BY rank ASC LIMIT 5;
```

The Next.js app (`/` and `/api/gazetteer/search`) reads this SQLite file through
`node:sqlite` and re-ranks trigram hits with a trigram-Dice similarity score.
