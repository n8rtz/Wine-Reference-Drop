#!/usr/bin/env python3
"""
fetch_ttb_producers.py
======================

Standalone ingestion script that builds a **US TTB Wine Producer Gazetteer**
(`dist/wine_gazetteer.sqlite`) for fuzzy producer / brand lookup.

Data source (public domain, CC0):
    TTB "List of Permittees" (Frequently Requested FOIA Listings)
    https://www.ttb.gov/public-information/foia/list-of-permittees

The script:
  1. Discovers + downloads the current TTB permittee registry
     (FRL_All_Permits.json, plus the per-industry CSV fallbacks).
  2. Normalizes every legal entity / operating (DBA) brand name:
       - corporate suffix stripping  (LLC, INC., CORP, LTD, LP ...)
       - trade / permit noise stripping (WINERY LLC, CELLARS INC ...)
       - diacritic folding + character / spacing normalization
       - abbreviation expansion (St -> Saint, Mt -> Mount, Vnyd -> Vineyard,
         Dom. -> Domaine, Ch. -> Chateau) producing search aliases
  3. Deduplicates on the normalized brand key.
  4. Builds `producers` + the FTS5 **trigram** virtual table `producers_fts`,
     then runs `optimize` and `VACUUM`.

Zero third-party dependencies - standard library only.

Usage:
    python pipeline/fetch_ttb_producers.py
    python pipeline/fetch_ttb_producers.py --offline          # use cache only
    python pipeline/fetch_ttb_producers.py --out dist/x.sqlite
    python pipeline/fetch_ttb_producers.py --verify-only
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import sys
import time
import unicodedata
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Iterable, Iterator

# --------------------------------------------------------------------------
# Paths / constants
# --------------------------------------------------------------------------

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_OUT = os.path.join(ROOT, "dist", "wine_gazetteer.sqlite")
CACHE_DIR = os.path.join(ROOT, "pipeline", ".cache")

TTB_LANDING = "https://www.ttb.gov/public-information/foia/list-of-permittees"
TTB_BASE = "https://www.ttb.gov"

# Known-good snapshot paths used when the landing page cannot be parsed.
FALLBACK_PATHS = [
    "/system/files/2025-04/FRL_All_Permits.json",
    "/system/files/2025-04/FRL_Wine_Producer_and_Blender_Permit_List.csv",
    "/system/files/2025-04/FRL_Alcohol_Importer_Permit_List.csv",
    "/system/files/2025-04/FRL_Alcohol_Wholesaler_Permit_List.csv",
    "/system/files/2025-04/FRL_Spirits_Producers_and_Bottlers_List.csv",
    "/system/files/2025-04/FRL_Puerto_Rico_Basic_Permit_List.csv",
]

USER_AGENT = "wine-gazetteer-builder/1.0 (+public TTB FOIA data)"

STATE_NAMES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas",
    "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware",
    "DC": "District of Columbia", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana",
    "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana",
    "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan",
    "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana",
    "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey",
    "NM": "New Mexico", "NY": "New York", "NC": "North Carolina",
    "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon",
    "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah",
    "VT": "Vermont", "VA": "Virginia", "WA": "Washington",
    "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
    "PR": "Puerto Rico", "VI": "U.S. Virgin Islands", "GU": "Guam",
    "AS": "American Samoa", "MP": "Northern Mariana Islands",
}

# --------------------------------------------------------------------------
# 3A. Corporate suffix / trade noise definitions
# --------------------------------------------------------------------------

# Multi-word trade/permit noise removed from the *tail* of a name first.
TRADE_NOISE = [
    "WINERY LLC", "WINERY INC", "WINERY CO", "CELLARS INC", "CELLARS LLC",
    "VINEYARDS LLC", "VINEYARDS INC", "VINEYARD LLC", "VINEYARD INC",
    "IMPORTS CO", "IMPORTS LLC", "IMPORTS INC", "IMPORTERS LLC",
    "DISTILLING CO", "DISTILLING LLC", "DISTILLERY LLC", "DISTILLERY INC",
    "WINE CO LLC", "WINE COMPANY LLC", "BREWING CO LLC",
]

# Single-token legal suffixes stripped repeatedly from the tail.
LEGAL_SUFFIXES = {
    "LLC", "L.L.C.", "LLC.", "L L C", "INC", "INC.", "INCORPORATED",
    "CORP", "CORP.", "CORPORATION", "CO", "CO.", "COMPANY",
    "LTD", "LTD.", "LIMITED", "LP", "L.P.", "LLP", "L.L.P.", "LLLP",
    "PLLC", "PC", "P.C.", "PLC", "GMBH", "SA", "S.A.", "SRL", "BV", "NV",
    "PTY", "AG", "KG", "SPA", "S.P.A.", "CV", "DBA", "THE",
}

# Descriptor words that are dropped to form the *short brand* alias.
DESCRIPTORS = [
    "WINERY", "WINERIES", "WINE CELLARS", "CELLARS", "CELLAR",
    "VINEYARDS", "VINEYARD", "WINES", "WINE", "ESTATE WINERY", "ESTATES",
    "ESTATE", "VINTNERS", "VINTNER", "WINE GROUP", "WINE COMPANY",
    "WINE CO", "WINEGROWERS", "WINE ESTATES", "FAMILY WINERY",
    "FAMILY VINEYARDS", "FAMILY WINES", "FARM WINERY", "MEADERY",
    "DISTILLERY", "DISTILLERIES", "DISTILLING", "BREWERY", "BREWING",
    "IMPORTS", "IMPORTERS", "IMPORTING", "IMPORT", "EXPORTS",
    "BEVERAGE GROUP", "BEVERAGES", "BEVERAGE", "BRANDS", "BRAND",
    "SPIRITS", "TRADING", "SELECTIONS", "HOLDINGS", "GROUP",
    "ENTERPRISES", "VENTURES", "PARTNERS", "PRODUCTIONS", "PRODUCTS",
]

# 3C. Abbreviation expansion map (token level).
ABBREVIATIONS = {
    "ST": "SAINT", "ST.": "SAINT", "STE": "SAINTE", "STE.": "SAINTE",
    "MT": "MOUNT", "MT.": "MOUNT", "MTN": "MOUNTAIN", "MTN.": "MOUNTAIN",
    "VNYD": "VINEYARD", "VNYDS": "VINEYARDS", "VYD": "VINEYARD",
    "VYDS": "VINEYARDS", "VNYRD": "VINEYARD", "VY": "VINEYARD",
    "DOM": "DOMAINE", "DOM.": "DOMAINE", "DOMS": "DOMAINES",
    "CH": "CHATEAU", "CH.": "CHATEAU", "CHT": "CHATEAU",
    "CLLRS": "CELLARS", "WNRY": "WINERY", "VYRD": "VINEYARD",
    "BROS": "BROTHERS", "BROS.": "BROTHERS",
    "FT": "FORT", "FT.": "FORT", "N": "NORTH", "S": "SOUTH",
}
# Reverse (contraction) map used to add a second alias form.
CONTRACTIONS = {
    "SAINT": "ST", "SAINTE": "STE", "MOUNT": "MT", "MOUNTAIN": "MTN",
    "DOMAINE": "DOM", "CHATEAU": "CH", "BROTHERS": "BROS",
}

# Diacritic restoration for canonical display names (ASCII source data).
DIACRITIC_RESTORE = {
    "Chateau": "Château", "Chateaux": "Châteaux", "Cotes": "Côtes",
    "Cote": "Côte", "Vina": "Viña", "Vinas": "Viñas", "Nunez": "Núñez",
    "Rhone": "Rhône", "Crepe": "Crêpe", "Reserva": "Reserva",
    "Cuvee": "Cuvée", "Rose": "Rosé", "Perle": "Perle", "Jose": "José",
    "Senor": "Señor", "Senora": "Señora", "Pina": "Piña",
    "Aperitif": "Apéritif", "Cafe": "Café", "Creme": "Crème",
    "Elevage": "Élevage", "Pinata": "Piñata",
}

LOWERCASE_WORDS = {
    "a", "an", "and", "at", "by", "de", "del", "della", "di", "du", "for",
    "in", "la", "le", "les", "of", "on", "or", "the", "to", "van", "von", "y",
}
FORCE_UPPER = {
    "USA", "US", "LLC", "II", "III", "IV", "VI", "VII", "NY", "CA", "TX",
    "JR", "SR", "BC", "DC", "AVA", "SLO",
}

# --------------------------------------------------------------------------
# Download helpers
# --------------------------------------------------------------------------


def log(msg: str) -> None:
    print(f"[gazetteer] {msg}", flush=True)


def http_get(url: str, timeout: int = 180) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def cached_download(url: str, offline: bool = False) -> bytes | None:
    """Download `url`, caching the payload under pipeline/.cache."""
    os.makedirs(CACHE_DIR, exist_ok=True)
    key = hashlib.sha1(url.encode()).hexdigest()[:16]
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", url.rsplit("/", 1)[-1])[:80]
    path = os.path.join(CACHE_DIR, f"{key}_{name}")
    if os.path.exists(path) and os.path.getsize(path) > 0:
        log(f"cache hit  {os.path.basename(path)}")
        with open(path, "rb") as fh:
            return fh.read()
    if offline:
        return None
    try:
        log(f"downloading {url}")
        data = http_get(url)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError) as exc:
        log(f"  !! download failed: {exc}")
        return None
    with open(path, "wb") as fh:
        fh.write(data)
    log(f"  -> {len(data):,} bytes")
    return data


def discover_dataset_urls(offline: bool) -> list[str]:
    """Scrape the TTB landing page for current CSV/JSON dataset links."""
    urls: list[str] = []
    page = cached_download(TTB_LANDING, offline=offline)
    if page:
        html = page.decode("utf-8", "replace")
        for href in re.findall(r'href="([^"]+\.(?:csv|json))"', html, re.I):
            if "FRL" not in href.upper():
                continue
            urls.append(href if href.startswith("http") else TTB_BASE + href)
    for p in FALLBACK_PATHS:
        u = TTB_BASE + p
        if u not in urls:
            urls.append(u)
    # JSON (all permits) first - it is the superset.
    urls.sort(key=lambda u: (0 if u.lower().endswith(".json") else 1, u))
    return urls


# --------------------------------------------------------------------------
# Raw record parsing
# --------------------------------------------------------------------------

FIELDS = ("permit", "owner", "operating", "city", "state", "industry")


@dataclass
class RawRecord:
    permit: str = ""
    owner: str = ""
    operating: str = ""
    city: str = ""
    state: str = ""
    industry: str = ""


def _row_from_list(row: list) -> RawRecord | None:
    # [permit, owner, operating, street, city, state, zip, county, type, flag]
    if len(row) < 9:
        return None
    return RawRecord(
        permit=str(row[0] or "").strip(),
        owner=str(row[1] or "").strip(),
        operating=str(row[2] or "").strip(),
        city=str(row[4] or "").strip(),
        state=str(row[5] or "").strip(),
        industry=str(row[8] or "").strip(),
    )


def parse_json_permits(data: bytes) -> Iterator[RawRecord]:
    payload = json.loads(data.decode("utf-8-sig", "replace"))
    rows = payload.get("Permit Data", []) if isinstance(payload, dict) else payload
    for row in rows:
        if isinstance(row, dict):
            rec = RawRecord(
                permit=str(row.get("Permit_Number") or "").strip(),
                owner=str(row.get("Owner_Name") or "").strip(),
                operating=str(row.get("Operating_Name") or "").strip(),
                city=str(row.get("City") or "").strip(),
                state=str(row.get("State") or "").strip(),
                industry=str(row.get("Industry_Type") or "").strip(),
            )
        else:
            rec = _row_from_list(list(row))  # type: ignore[arg-type]
        if rec and (rec.owner or rec.operating):
            yield rec


def parse_csv_permits(data: bytes) -> Iterator[RawRecord]:
    text = data.decode("utf-8-sig", "replace")
    reader = csv.DictReader(io.StringIO(text))
    for row in reader:
        clean = { (k or "").strip(): (v or "").strip() for k, v in row.items() }
        rec = RawRecord(
            permit=clean.get("Permit_Number", ""),
            owner=clean.get("Owner_Name", ""),
            operating=clean.get("Operating_Name", ""),
            city=clean.get("City", ""),
            state=clean.get("State", ""),
            industry=clean.get("Industry_Type", ""),
        )
        if rec.owner or rec.operating:
            yield rec


OFFLINE_SEED = [
    # permit, owner, operating, city, state, industry
    ("CA-W-21961", "STANDING JOURNEY LLC", "CHATEAU MONTELENA WINERY, LLC", "CALISTOGA", "CA", "Wine Producer"),
    ("CA-W-15001", "ROBERT MONDAVI WINERY INC", "ROBERT MONDAVI", "OAKVILLE", "CA", "Wine Producer"),
    ("CA-W-15002", "RIDGE VINEYARDS, INC.", "RIDGE VINEYARDS", "CUPERTINO", "CA", "Wine Producer"),
    ("CA-W-15003", "OPUS ONE WINERY LLC", "OPUS ONE", "OAKVILLE", "CA", "Wine Producer"),
    ("OR-W-15004", "DOM. DROUHIN OREGON LLC", "DOMAINE DROUHIN", "DAYTON", "OR", "Wine Producer"),
    ("WA-W-15005", "CH. STE MICHELLE VNYDS LLC", "CHATEAU STE MICHELLE", "WOODINVILLE", "WA", "Wine Producer"),
    ("NY-W-15006", "DR KONSTANTIN FRANK VNYDS INC", "DR FRANK WINES", "HAMMONDSPORT", "NY", "Wine Producer"),
    ("CA-W-15007", "ST. SUPERY VINEYARDS LLC", "ST SUPERY ESTATE", "RUTHERFORD", "CA", "Wine Producer"),
    ("CA-W-15008", "MT. VEEDER WINERY LLC", "MOUNT VEEDER WINERY", "NAPA", "CA", "Wine Producer"),
    ("TX-I-15009", "BODEGA VINA IMPORTS CO", "BODEGA VINA SELECTIONS", "AUSTIN", "TX", "Importer (Alcohol)"),
]


def load_raw_records(offline: bool, limit: int | None) -> list[RawRecord]:
    records: list[RawRecord] = []
    for url in discover_dataset_urls(offline):
        data = cached_download(url, offline=offline)
        if not data:
            continue
        try:
            if url.lower().endswith(".json"):
                batch = list(parse_json_permits(data))
            else:
                batch = list(parse_csv_permits(data))
        except Exception as exc:  # pragma: no cover - defensive
            log(f"  !! parse failed for {url}: {exc}")
            continue
        log(f"  parsed {len(batch):,} permit rows from {url.rsplit('/', 1)[-1]}")
        records.extend(batch)
        if limit and len(records) >= limit:
            break
    if not records:
        log("no remote data available - falling back to embedded offline seed")
        records = [RawRecord(*r) for r in OFFLINE_SEED]
    if limit:
        records = records[:limit]
    return records


# --------------------------------------------------------------------------
# 3B. Character normalization / diacritic folding
# --------------------------------------------------------------------------

PUNCT_MAP = {
    "\u2018": "'", "\u2019": "'", "\u201a": "'", "\u201b": "'",
    "\u201c": '"', "\u201d": '"', "\u2032": "'", "\u00b4": "'", "`": "'",
    "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
    "\u2014": "-", "\u2015": "-", "\u2212": "-",
    "\u00a0": " ", "\u2026": " ", "\u00ad": "",
    "\u00c6": "AE", "\u00e6": "ae", "\u0152": "OE", "\u0153": "oe",
    "\u00d8": "O", "\u00f8": "o", "\u00df": "ss", "\u0110": "D", "\u0111": "d",
    "&": " and ",
}


def fold_ascii(text: str) -> str:
    """Map accented characters + typographic punctuation to plain ASCII."""
    for src, dst in PUNCT_MAP.items():
        text = text.replace(src, dst)
    decomposed = unicodedata.normalize("NFKD", text)
    ascii_text = "".join(c for c in decomposed if not unicodedata.combining(c))
    return ascii_text.encode("ascii", "ignore").decode("ascii")


def normalize_raw(name: str) -> str:
    """Upper-cased, ASCII, punctuation-tamed working form of a raw name."""
    text = fold_ascii(name).upper()
    text = re.sub(r"\(.*?\)", " ", text)          # drop parentheticals
    text = text.replace("/", " ").replace("\\", " ")
    text = re.sub(r"[^A-Z0-9'&.\- ]+", " ", text)
    text = re.sub(r"\s*-\s*", "-", text)
    text = re.sub(r"\s+", " ", text).strip(" -.,'")
    return text


DBA_SPLIT = re.compile(r"\b(?:D ?B ?A|DOING BUSINESS AS|T ?/ ?A|AKA)\b")


def split_dba(name: str) -> list[str]:
    parts = [p.strip(" -.,") for p in DBA_SPLIT.split(name)]
    return [p for p in parts if p]


# --------------------------------------------------------------------------
# 3A. Suffix stripping
# --------------------------------------------------------------------------


def strip_trade_noise(name: str) -> str:
    changed = True
    while changed:
        changed = False
        for noise in TRADE_NOISE:
            if name.endswith(" " + noise):
                name = name[: -(len(noise) + 1)].strip(" ,.-")
                changed = True
    return name


def strip_legal_suffixes(name: str) -> str:
    """Remove trailing corporate boilerplate (LLC, INC., CORP, LTD, LP ...)."""
    name = strip_trade_noise(name)
    tokens = name.split()
    while tokens:
        tail = tokens[-1].strip(",.")
        if tail.upper() in {s.strip(",.") for s in LEGAL_SUFFIXES} and len(tokens) > 1:
            tokens.pop()
            continue
        break
    out = " ".join(tokens).strip(" ,.-")
    # Dangling conjunctions left behind by suffix removal ("... VINEYARDS AND")
    out = re.sub(r"\s+(?:AND|&|OF|THE|A)$", "", out, flags=re.I).strip(" ,.-")
    # Leading article
    if out.upper().startswith("THE ") and len(out.split()) > 2:
        out = out[4:]
    return out or name


def strip_descriptors(name: str) -> str:
    """Drop a trailing trade descriptor to obtain the short brand form."""
    upper = name.upper()
    for desc in sorted(DESCRIPTORS, key=len, reverse=True):
        if upper.endswith(" " + desc):
            short = name[: -(len(desc) + 1)].strip(" ,.-")
            if len(short.split()) >= 1 and len(short) >= 3:
                return short
    return name


# --------------------------------------------------------------------------
# 3C. Abbreviation expansion & alias generation
# --------------------------------------------------------------------------


def expand_abbreviations(name: str) -> str:
    out = []
    for tok in name.split():
        key = tok.upper().strip(",")
        out.append(ABBREVIATIONS.get(key, tok))
    return " ".join(out)


def contract_abbreviations(name: str) -> str:
    out = []
    for tok in name.split():
        out.append(CONTRACTIONS.get(tok.upper(), tok))
    return " ".join(out)


def alias_key(name: str) -> str:
    """Comparison key: letters+digits only, abbreviations expanded."""
    return re.sub(r"[^A-Z0-9]+", "", expand_abbreviations(name.upper()))


def build_aliases(*names: str) -> list[str]:
    """Generate a deduplicated, ordered list of searchable name variants."""
    seen: dict[str, str] = {}
    ordered: list[str] = []

    def add(value: str) -> None:
        value = re.sub(r"\s+", " ", value).strip(" ,.-'")
        value = re.sub(r"\s+(?:and|&|of|the)$", "", value, flags=re.I).strip(" ,.-")
        if len(value) < 3 or not re.search(r"[A-Za-z]", value):
            return
        k = alias_key(value)
        if not k or k in seen:
            return
        seen[k] = value
        ordered.append(value)

    for raw in names:
        if not raw:
            continue
        base = strip_legal_suffixes(raw)
        variants = [base]
        variants.append(expand_abbreviations(base))
        variants.append(contract_abbreviations(expand_abbreviations(base)))
        short = strip_descriptors(expand_abbreviations(base))
        variants.append(short)
        variants.append(strip_descriptors(short))
        variants.append(base.replace("-", " "))
        variants.append(re.sub(r"\bAND\b", "&", expand_abbreviations(base)))
        for v in variants:
            add(titlecase(v))
    return ordered[:12]


# --------------------------------------------------------------------------
# Display formatting
# --------------------------------------------------------------------------


def titlecase(name: str) -> str:
    words = name.split()
    out: list[str] = []
    for i, w in enumerate(words):
        bare = re.sub(r"[^A-Za-z]", "", w)
        if not bare:
            out.append(w)
            continue
        if bare.upper() in FORCE_UPPER:
            out.append(w.upper())
            continue
        lowered = bare.lower()
        if i > 0 and lowered in LOWERCASE_WORDS and i != len(words) - 1:
            out.append(w.lower())
            continue
        parts = re.split(r"([-'])", w.lower())
        rebuilt = ""
        for part in parts:
            if part in {"-", "'"}:
                rebuilt += part
            elif part:
                rebuilt += part[0].upper() + part[1:]
        # Keep McX / O'X patterns tidy
        rebuilt = re.sub(r"\bMc([a-z])", lambda m: "Mc" + m.group(1).upper(), rebuilt)
        out.append(rebuilt)
    return " ".join(out)


def restore_diacritics(name: str) -> str:
    return " ".join(DIACRITIC_RESTORE.get(w, w) for w in name.split())


# --------------------------------------------------------------------------
# Entity assembly
# --------------------------------------------------------------------------


@dataclass
class Producer:
    producer_id: str
    canonical_name: str
    country: str
    state_region: str
    aliases: list[str] = field(default_factory=list)
    permits: set[str] = field(default_factory=set)
    industries: set[str] = field(default_factory=set)

    def alias_string(self) -> str:
        return "|".join(self.aliases)


def make_id(key: str) -> str:
    return "TTB-" + hashlib.sha1(key.encode("utf-8")).hexdigest()[:12].upper()


def build_producers(records: Iterable[RawRecord]) -> list[Producer]:
    by_key: dict[str, Producer] = {}
    count_rows = 0

    for rec in records:
        count_rows += 1
        state = (rec.state or "").upper()[:2]
        region = STATE_NAMES.get(state, state or None) or ""
        country = "United States"

        owner_names = split_dba(normalize_raw(rec.owner)) if rec.owner else []
        op_names = split_dba(normalize_raw(rec.operating)) if rec.operating else []

        groups: list[tuple[str, list[str]]] = []
        if owner_names:
            groups.append((owner_names[0], owner_names + op_names))
        for extra in owner_names[1:]:
            groups.append((extra, [extra]))
        for op in op_names:
            if not owner_names or alias_key(strip_legal_suffixes(op)) != alias_key(
                strip_legal_suffixes(owner_names[0])
            ):
                groups.append((op, [op] + owner_names[:1]))

        for primary, alias_sources in groups:
            cleaned = strip_legal_suffixes(primary)
            key = alias_key(cleaned)
            if not key or len(key) < 3:
                continue
            aliases = build_aliases(*alias_sources)
            if not aliases:
                continue
            canonical = restore_diacritics(titlecase(cleaned))
            existing = by_key.get(key)
            if existing is None:
                existing = Producer(
                    producer_id=make_id(key),
                    canonical_name=canonical,
                    country=country,
                    state_region=region,
                    aliases=list(aliases),
                )
                by_key[key] = existing
            else:
                known = {alias_key(a) for a in existing.aliases}
                for a in aliases:
                    if alias_key(a) not in known and len(existing.aliases) < 14:
                        existing.aliases.append(a)
                        known.add(alias_key(a))
                if not existing.state_region and region:
                    existing.state_region = region
            if rec.permit:
                existing.permits.add(rec.permit)
            if rec.industry:
                existing.industries.add(rec.industry)

    log(f"processed {count_rows:,} permit rows -> {len(by_key):,} unique entities")
    return list(by_key.values())


# --------------------------------------------------------------------------
# Database build
# --------------------------------------------------------------------------

SCHEMA = """
PRAGMA journal_mode = OFF;
PRAGMA synchronous = OFF;

DROP TABLE IF EXISTS producers_fts;
DROP TABLE IF EXISTS producers;

CREATE TABLE IF NOT EXISTS producers (
    producer_id TEXT PRIMARY KEY,
    canonical_name TEXT NOT NULL,
    country TEXT DEFAULT 'United States',
    state_region TEXT,
    aliases TEXT
);

CREATE VIRTUAL TABLE IF NOT EXISTS producers_fts USING fts5(
    producer_id UNINDEXED,
    canonical_name,
    aliases,
    country,
    tokenize = 'trigram'
);

CREATE INDEX IF NOT EXISTS idx_producers_name ON producers(canonical_name);
CREATE INDEX IF NOT EXISTS idx_producers_state ON producers(state_region);

CREATE TABLE IF NOT EXISTS gazetteer_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


def write_database(path: str, producers: list[Producer]) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    conn = sqlite3.connect(path)
    try:
        conn.executescript(SCHEMA)
        rows = [
            (
                p.producer_id,
                p.canonical_name,
                p.country,
                p.state_region or None,
                p.alias_string(),
            )
            for p in producers
        ]
        conn.executemany(
            "INSERT OR REPLACE INTO producers "
            "(producer_id, canonical_name, country, state_region, aliases) "
            "VALUES (?, ?, ?, ?, ?)",
            rows,
        )
        conn.executemany(
            "INSERT INTO producers_fts (producer_id, canonical_name, aliases, country) "
            "VALUES (?, ?, ?, ?)",
            [(r[0], r[1], r[4], r[2]) for r in rows],
        )
        conn.executemany(
            "INSERT OR REPLACE INTO gazetteer_meta (key, value) VALUES (?, ?)",
            [
                ("source", "TTB FOIA List of Permittees (public domain / CC0)"),
                ("source_url", TTB_LANDING),
                ("built_at", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
                ("producer_count", str(len(rows))),
            ],
        )
        conn.commit()
        log("optimizing FTS index ...")
        conn.execute("INSERT INTO producers_fts(producers_fts) VALUES('optimize')")
        conn.commit()
        conn.execute("PRAGMA optimize")
        log("vacuuming ...")
        conn.isolation_level = None
        conn.execute("VACUUM")
    finally:
        conn.close()
    size = os.path.getsize(path)
    log(f"wrote {len(producers):,} producers to {path} ({size / 1e6:.1f} MB)")


# --------------------------------------------------------------------------
# Verification
# --------------------------------------------------------------------------


def fts_query_string(text: str) -> str:
    cleaned = re.sub(r'["\']', " ", fold_ascii(text)).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    return f'"{cleaned}"' if cleaned else '""'


def verify(path: str, samples: list[str]) -> bool:
    if not os.path.exists(path):
        log(f"!! database missing: {path}")
        return False
    conn = sqlite3.connect(path)
    try:
        total = conn.execute("SELECT COUNT(*) FROM producers").fetchone()[0]
        fts_total = conn.execute("SELECT COUNT(*) FROM producers_fts").fetchone()[0]
        log(f"verification: producers={total:,} producers_fts={fts_total:,}")
        for sample in samples:
            rows = conn.execute(
                "SELECT producer_id, canonical_name, aliases, bm25(producers_fts) AS rank "
                "FROM producers_fts WHERE producers_fts MATCH ? "
                "ORDER BY rank ASC LIMIT 5",
                (fts_query_string(sample),),
            ).fetchall()
            log(f"  MATCH {sample!r} -> {len(rows)} hits")
            for r in rows[:3]:
                log(f"     {r[0]}  {r[1]}  [{r[2][:70]}]  rank={r[3]:.3f}")
        boiler = conn.execute(
            "SELECT COUNT(*) FROM producers WHERE canonical_name LIKE '% LLC' "
            "OR canonical_name LIKE '% Inc%' OR canonical_name LIKE '% Corp' "
            "OR canonical_name LIKE '% Ltd'"
        ).fetchone()[0]
        log(f"  canonical names still containing legal boilerplate: {boiler}")
        return total > 0
    finally:
        conn.close()


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Build the US TTB wine producer gazetteer.")
    ap.add_argument("--out", default=DEFAULT_OUT, help="output SQLite path")
    ap.add_argument("--offline", action="store_true", help="use cached downloads only")
    ap.add_argument("--limit", type=int, default=None, help="limit raw permit rows")
    ap.add_argument("--verify-only", action="store_true", help="only run verification")
    ap.add_argument(
        "--min-entities", type=int, default=0,
        help="fail if fewer than N unique producers were built",
    )
    args = ap.parse_args(argv)

    samples = ["Chateau Montelena", "Ridge Vineyards", "Saint Supery"]

    if args.verify_only:
        return 0 if verify(args.out, samples) else 1

    t0 = time.time()
    records = load_raw_records(offline=args.offline, limit=args.limit)
    log(f"loaded {len(records):,} raw permit records")
    producers = build_producers(records)
    producers.sort(key=lambda p: p.canonical_name)
    write_database(args.out, producers)
    ok = verify(args.out, samples)
    log(f"done in {time.time() - t0:.1f}s")
    if args.min_entities and len(producers) < args.min_entities:
        log(f"!! only {len(producers)} entities (< {args.min_entities})")
        return 2
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
